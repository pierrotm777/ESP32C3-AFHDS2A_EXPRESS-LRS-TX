/*
 * PCF8574_SW8.ino
 * --------------------------------------------------------------------------
 * Eight physical ON/OFF inputs for XANY1 SW8 through PCF8574A / PCF8574.
 *
 * Wiring convention:
 *   P0..P7 -> SW1..SW8
 *   switch closed to GND = ON
 *
 * PCF8574 ports are quasi-bidirectional. Writing 0xFF releases all eight
 * ports HIGH so they can be read as inputs. The byte is inverted before being
 * passed to XANY1, therefore P0 LOW sets SW8 bit0, ... P7 LOW sets bit7.
 *
 * The shared bus starts at 100 kHz for maximum compatibility. Reading one byte
 * every 5 ms is already faster than the 20 ms RCUL symbol period at the current
 * AFHDS2A 50 Hz receiver servo setting.
 */

static constexpr uint32_t PCF_SW8_POLL_US = 5000UL;
static constexpr uint32_t PCF_SW8_DEBOUNCE_US = 10000UL;

static uint8_t PcfSw8Addr = 0;
static bool PcfSw8Ok = false;
static uint8_t PcfSw8Raw = 0xFF;
static uint8_t PcfSw8Candidate = 0x00;
static uint8_t PcfSw8Stable = 0x00;
static uint32_t PcfSw8LastPollUs = 0;
static uint32_t PcfSw8CandidateSinceUs = 0;
static uint32_t PcfSw8ReadCount = 0;
static uint32_t PcfSw8ErrorCount = 0;

static bool pcfSw8AddressReserved(uint8_t Addr)
{
  // SSD1306 modules normally use 0x3C or 0x3D. Never claim these during the
  // PCF8574A scan, even while OLED is disabled.
  return Addr == 0x3C || Addr == 0x3D;
}

static bool pcfSw8Ping(uint8_t Addr)
{
  if(pcfSw8AddressReserved(Addr))
    return false;

  Wire.beginTransmission(Addr);
  return Wire.endTransmission() == 0;
}

static uint8_t pcfSw8ProbeAddress(void)
{
  // User hardware is expected to be PCF8574A: probe its 0x38..0x3F range first.
  for(uint8_t addr = 0x38; addr <= 0x3F; addr++)
    if(pcfSw8Ping(addr))
      return addr;

  // Also accept the non-A PCF8574 range for convenience.
  for(uint8_t addr = 0x20; addr <= 0x27; addr++)
    if(pcfSw8Ping(addr))
      return addr;

  return 0;
}

static bool pcfSw8ReleaseInputs(void)
{
  if(PcfSw8Addr == 0)
    return false;

  Wire.beginTransmission(PcfSw8Addr);
  Wire.write(0xFF); // release all quasi-bidirectional ports for input use
  return Wire.endTransmission() == 0;
}

static bool pcfSw8ReadByte(uint8_t &Raw)
{
  if(!PcfSw8Ok || PcfSw8Addr == 0)
    return false;

  const uint8_t n = Wire.requestFrom((int)PcfSw8Addr, 1);
  if(n != 1 || !Wire.available())
  {
    PcfSw8ErrorCount++;
    while(Wire.available()) (void)Wire.read();
    return false;
  }

  Raw = (uint8_t)Wire.read();
  PcfSw8ReadCount++;
  return true;
}

static void pcfSw8AcceptImmediate(uint8_t Logical)
{
  PcfSw8Candidate = Logical;
  PcfSw8Stable = Logical;
  PcfSw8CandidateSinceUs = micros();
  xany1SetSw8(PcfSw8Stable);
}

static void pcfSw8Scan(void)
{
  Wire.setClock(I2C_BUS_HZ);
  PcfSw8Addr = pcfSw8ProbeAddress();
  PcfSw8Ok = false;

  if(PcfSw8Addr == 0)
  {
    Serial.println("[PCF] NOT FOUND (8574A: 0x38..0x3F, 8574: 0x20..0x27; 0x3C/0x3D reserved OLED)");
    return;
  }

  if(!pcfSw8ReleaseInputs())
  {
    Serial.printf("[PCF] found 0x%02X but input release write FAILED\r\n", PcfSw8Addr);
    return;
  }

  PcfSw8Ok = true;
  uint8_t raw = 0xFF;
  if(pcfSw8ReadByte(raw))
  {
    PcfSw8Raw = raw;
    pcfSw8AcceptImmediate((uint8_t)~raw); // active LOW switches
  }

  Serial.printf("[PCF] OK addr=0x%02X I2C=%luHz raw=0x%02X SW8=0x%02X active-LOW\r\n",
                PcfSw8Addr,
                (unsigned long)I2C_BUS_HZ,
                PcfSw8Raw,
                PcfSw8Stable);
}

static void pcfSw8Begin(void)
{
  PcfSw8ReadCount = 0;
  PcfSw8ErrorCount = 0;
  PcfSw8LastPollUs = micros();
  pcfSw8Scan();
}

static void pcfSw8Process(void)
{
  if(!PcfSw8Ok)
    return;

  const uint32_t now = micros();
  if((uint32_t)(now - PcfSw8LastPollUs) < PCF_SW8_POLL_US)
    return;
  PcfSw8LastPollUs = now;

  uint8_t raw;
  if(!pcfSw8ReadByte(raw))
    return;

  PcfSw8Raw = raw;
  const uint8_t logical = (uint8_t)~raw; // closed-to-GND = ON

  if(logical != PcfSw8Candidate)
  {
    PcfSw8Candidate = logical;
    PcfSw8CandidateSinceUs = now;
    return;
  }

  if(logical == PcfSw8Stable)
    return;

  if((uint32_t)(now - PcfSw8CandidateSinceUs) < PCF_SW8_DEBOUNCE_US)
    return;

  PcfSw8Stable = logical;
  xany1SetSw8(PcfSw8Stable);

  if(DebugIsOn)
    Serial.printf("[PCF] raw=0x%02X -> SW8=0x%02X\r\n", PcfSw8Raw, PcfSw8Stable);
}

static void pcfSw8PrintStatus(void)
{
  if(!PcfSw8Ok)
  {
    Serial.printf("PCF SW8     : NOT FOUND I2C=%luHz\r\n", (unsigned long)I2C_BUS_HZ);
    return;
  }

  Serial.printf("PCF SW8     : 0x%02X raw=0x%02X sw=0x%02X poll=5ms debounce=10ms reads=%lu err=%lu\r\n",
                PcfSw8Addr,
                PcfSw8Raw,
                PcfSw8Stable,
                (unsigned long)PcfSw8ReadCount,
                (unsigned long)PcfSw8ErrorCount);
}
