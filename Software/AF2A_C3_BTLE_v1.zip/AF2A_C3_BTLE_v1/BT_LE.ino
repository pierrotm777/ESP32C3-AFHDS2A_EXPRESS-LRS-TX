/*
  Bluetooth LE telemetry bridge for ESP32-C3.

  This tab is intentionally self-contained. The existing AFHDS2A RF, PPM,
  XANY, OLED and tlog code stays unchanged except for small hook calls from
  AF2A_C3.ino / Telemetry_AFHDS2A.ino.

  BLE wire format expected by the Android telemetry application:
    'M' 'P' TYPE LENGTH PAYLOAD...

    TYPE 0x06 = AFHDS2A normal telemetry (0xAA)
    TYPE 0x0C = AFHDS2A extended telemetry (0xAC)

  PAYLOAD[0] is MULTI TX_RSSI (0..255), followed by the AFHDS2A sensor bytes
  normally found at RF packet offsets 9..36. TX/RX IDs are omitted exactly as
  in the original MPM AFHDS2A FW telemetry forwarding path.

  Console commands are handled by AF2A_C3.ino:
    bt / bt on / bt off
    btsimu / btsimu on / btsimu off / btsimu reset

  btsimu affects the BLE output only. Real RF telemetry acquisition and tlog
  continue normally in the background.
*/

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <math.h>

static const char* BTLE_DEVICE_NAME = "AF2A-C3";

// Nordic-UART-style UUIDs are used only as a convenient, well-known BLE
// container. The Android application scans all NOTIFY characteristics, so it
// does not depend on these UUIDs.
static const char* BTLE_SERVICE_UUID = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E";
static const char* BTLE_TX_UUID      = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E";

static constexpr uint8_t BTLE_QUEUE_SIZE = 4;
static constexpr uint8_t BTLE_MP_MAX_PAYLOAD = 29; // TX_RSSI + RF bytes 9..36
static constexpr uint8_t BTLE_NOTIFY_CHUNK = 20;   // safe even with MTU=23

struct BtLeFrame
{
  uint8_t type;                       // 0x06 AA, 0x0C AC
  uint8_t len;                        // payload bytes
  uint8_t payload[BTLE_MP_MAX_PAYLOAD];
};

static BLEServer* BtLeServer = nullptr;
static BLECharacteristic* BtLeTx = nullptr;
static volatile bool BtLeConnected = false;
static bool BtLeEnabled = false;
static bool BtLeStackStarted = false;
static bool BtLeSimuEnabled = false;

static BtLeFrame BtLeQueue[BTLE_QUEUE_SIZE];
static volatile uint8_t BtLeQueueRead = 0;
static volatile uint8_t BtLeQueueWrite = 0;
static volatile uint8_t BtLeQueueCount = 0;
static portMUX_TYPE BtLeQueueMux = portMUX_INITIALIZER_UNLOCKED;

static uint32_t BtLeFramesCaptured = 0;
static uint32_t BtLeFramesSent = 0;
static uint32_t BtLeFramesDropped = 0;
static uint32_t BtLeSimFramesSent = 0;

// ---------------------------------------------------------------------------
// GPS / battery simulator state.
// The GPS route contains 20 regularly spaced positions between point A and
// point B. It is read forward, then backward, continuously (A -> B -> A).
// The two end points are about 95 m apart, so one point per second gives an
// actual displacement close to the simulated 5 m/s (18 km/h).
// ---------------------------------------------------------------------------
static constexpr double BT_SIM_POINT_A_LAT = 48.8566000;
static constexpr double BT_SIM_POINT_A_LON = 2.3522000;
static constexpr double BT_SIM_POINT_B_LAT = 48.8571390;
static constexpr double BT_SIM_POINT_B_LON = 2.3532110;
static constexpr uint8_t BT_SIM_POINT_COUNT = 20;
static constexpr double BT_SIM_SPEED_MS = 5.0;
static constexpr uint32_t BT_SIM_PERIOD_MS = 1000UL;
static constexpr uint16_t BT_SIM_VOLTAGE_START_X100 = 1260; // 12.60 V
static constexpr uint16_t BT_SIM_VOLTAGE_END_X100   = 1080; // 10.80 V

static uint8_t BtSimPointIndex = 0;
static int8_t BtSimPointDirection = 1;
static uint16_t BtSimVoltageX100 = BT_SIM_VOLTAGE_START_X100;
static uint32_t BtSimLastMs = 0;
static uint32_t BtSimLastVoltageMs = 0;

class BtLeServerCallbacks : public BLEServerCallbacks
{
  void onConnect(BLEServer* server) override
  {
    (void)server;
    BtLeConnected = true;
  }

  void onDisconnect(BLEServer* server) override
  {
    (void)server;
    BtLeConnected = false;
    if(BtLeEnabled && BtLeStackStarted)
      BLEDevice::startAdvertising();
  }
};

static BtLeServerCallbacks BtLeCallbacks;

static void btQueueClear()
{
  portENTER_CRITICAL(&BtLeQueueMux);
  BtLeQueueRead = 0;
  BtLeQueueWrite = 0;
  BtLeQueueCount = 0;
  portEXIT_CRITICAL(&BtLeQueueMux);
}

static void btLoadPreference()
{
  BtLeEnabled = prefs.getBool("btle", false);
}

static bool btIsEnabled()
{
  return BtLeEnabled;
}

static bool btSimuIsEnabled()
{
  return BtLeSimuEnabled;
}

static void btStartStack()
{
  if(BtLeStackStarted || !BtLeEnabled)
    return;

  BLEDevice::init(BTLE_DEVICE_NAME);
  BtLeServer = BLEDevice::createServer();
  BtLeServer->setCallbacks(&BtLeCallbacks);

  BLEService* service = BtLeServer->createService(BTLE_SERVICE_UUID);
  BtLeTx = service->createCharacteristic(
      BTLE_TX_UUID,
      BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
  BtLeTx->setValue((uint8_t*)"", 0);

  service->start();

  BLEAdvertising* advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(BTLE_SERVICE_UUID);
  advertising->setScanResponse(true);
  advertising->start();

  BtLeStackStarted = true;
  BtLeConnected = false;
  Serial.printf("[BTLE] ON - advertising as %s\r\n", BTLE_DEVICE_NAME);
}

static void btStopStack()
{
  BtLeSimuEnabled = false;
  btQueueClear();

  if(BtLeStackStarted)
  {
    BLEDevice::stopAdvertising();
    BLEDevice::deinit(false);
  }

  BtLeTx = nullptr;
  BtLeServer = nullptr;
  BtLeConnected = false;
  BtLeStackStarted = false;
}

static void btBegin()
{
  // Preference is loaded separately in setup() so it can be shown in the
  // common [PREFS] startup line before the BLE stack is started.
  if(BtLeEnabled)
    btStartStack();
  else
    Serial.println("[BTLE] OFF (saved preference)");
}

static void btSetEnabled(bool enabled)
{
  if(BtLeEnabled == enabled)
  {
    Serial.printf("[BTLE] already %s\r\n", enabled ? "ON" : "OFF");
    return;
  }

  BtLeEnabled = enabled;
  prefs.putBool("btle", BtLeEnabled);

  if(BtLeEnabled)
  {
    btStartStack();
    Serial.println("[BTLE] ON saved");
  }
  else
  {
    btStopStack();
    Serial.println("[BTLE] OFF saved");
  }
}

static void btSimuReset()
{
  BtSimPointIndex = 0;
  BtSimPointDirection = 1;
  BtSimVoltageX100 = BT_SIM_VOLTAGE_START_X100;
  BtSimLastMs = 0;
  BtSimLastVoltageMs = millis();
  btQueueClear();
  Serial.printf("[BTSIMU] reset GPS=%.7f,%.7f route=%upts A<->B VBAT=%.2fV\r\n",
                BT_SIM_POINT_A_LAT, BT_SIM_POINT_A_LON,
                (unsigned)BT_SIM_POINT_COUNT,
                (double)BtSimVoltageX100 / 100.0);
}

static void btSimuSet(bool enabled)
{
  if(enabled && !BtLeEnabled)
  {
    Serial.println("[BTSIMU] BT LE is OFF - use 'bt on' first");
    return;
  }

  if(BtLeSimuEnabled == enabled)
  {
    Serial.printf("[BTSIMU] already %s\r\n", enabled ? "ON" : "OFF");
    return;
  }

  BtLeSimuEnabled = enabled;
  btQueueClear();

  if(BtLeSimuEnabled)
  {
    btSimuReset();
    Serial.println("[BTSIMU] ON - BLE output uses simulated GPS + model battery");
  }
  else
  {
    Serial.println("[BTSIMU] OFF - BLE output returned to live AFHDS2A telemetry");
  }
}

static void btPrintStatus()
{
  Serial.printf("Bluetooth LE: %s stack=%s link=%s name=%s simu=%s queue=%u captured=%lu sent=%lu drop=%lu sim=%lu\r\n",
                BtLeEnabled ? "ON" : "OFF",
                BtLeStackStarted ? "UP" : "DOWN",
                BtLeConnected ? "CONNECTED" : "WAIT",
                BTLE_DEVICE_NAME,
                BtLeSimuEnabled ? "ON" : "OFF",
                (unsigned)BtLeQueueCount,
                (unsigned long)BtLeFramesCaptured,
                (unsigned long)BtLeFramesSent,
                (unsigned long)BtLeFramesDropped,
                (unsigned long)BtLeSimFramesSent);
}

// Called from Telemetry_AFHDS2A.ino after a valid addressed RF packet has been
// accepted and decoded. This function only copies bytes into RAM; it never
// calls the BLE stack from the high-priority RF timer task.
static void btTelemetryCapture(const uint8_t* p, uint8_t len)
{
  if(!BtLeEnabled || !BtLeConnected || BtLeSimuEnabled || !p || len < 37)
    return;

  uint8_t mpType;
  if(p[0] == 0xAA)
    mpType = 0x06;
  else if(p[0] == 0xAC)
    mpType = 0x0C;
  else
    return;

  BtLeFrame frame;
  frame.type = mpType;
  frame.len = BTLE_MP_MAX_PAYLOAD;
  frame.payload[0] = TX_RSSI;
  memcpy(&frame.payload[1], &p[9], 28);

  portENTER_CRITICAL(&BtLeQueueMux);
  if(BtLeQueueCount >= BTLE_QUEUE_SIZE)
  {
    // Keep the freshest telemetry. Drop the oldest queued frame.
    BtLeQueueRead = (uint8_t)((BtLeQueueRead + 1) % BTLE_QUEUE_SIZE);
    BtLeQueueCount = (uint8_t)(BtLeQueueCount - 1);
    BtLeFramesDropped++;
  }
  BtLeQueue[BtLeQueueWrite] = frame;
  BtLeQueueWrite = (uint8_t)((BtLeQueueWrite + 1) % BTLE_QUEUE_SIZE);
  BtLeQueueCount = (uint8_t)(BtLeQueueCount + 1);
  BtLeFramesCaptured++;
  portEXIT_CRITICAL(&BtLeQueueMux);
}

// Do not use BtLeFrame in this function signature. Arduino IDE 1.8.x
// auto-generates function prototypes before local struct declarations and would
// otherwise generate an invalid prototype for BtLeFrame. Primitive pointer
// arguments keep the tab compatible with the classic Arduino preprocessor.
static bool btQueuePop(uint8_t* type, uint8_t* len, uint8_t* payload)
{
  bool haveFrame = false;

  if(!type || !len || !payload)
    return false;

  portENTER_CRITICAL(&BtLeQueueMux);
  if(BtLeQueueCount)
  {
    const BtLeFrame& frame = BtLeQueue[BtLeQueueRead];
    *type = frame.type;
    *len = frame.len;
    memcpy(payload, frame.payload, frame.len);
    BtLeQueueRead = (uint8_t)((BtLeQueueRead + 1) % BTLE_QUEUE_SIZE);
    BtLeQueueCount = (uint8_t)(BtLeQueueCount - 1);
    haveFrame = true;
  }
  portEXIT_CRITICAL(&BtLeQueueMux);

  return haveFrame;
}

static bool btNotifyBytes(const uint8_t* data, uint8_t len)
{
  if(!BtLeConnected || !BtLeTx || !data || !len)
    return false;

  uint8_t offset = 0;
  while(offset < len)
  {
    const uint8_t chunk = (uint8_t)min((int)BTLE_NOTIFY_CHUNK, (int)(len - offset));
    BtLeTx->setValue((uint8_t*)&data[offset], chunk);
    BtLeTx->notify();
    offset = (uint8_t)(offset + chunk);

    // Keep notifications ordered on peers that remain at the default MTU=23.
    if(offset < len)
      delay(1);
  }
  return true;
}

static bool btSendMpFrame(uint8_t type, const uint8_t* payload, uint8_t payloadLen)
{
  if(!payload || payloadLen == 0 || payloadLen > BTLE_MP_MAX_PAYLOAD)
    return false;

  uint8_t frame[4 + BTLE_MP_MAX_PAYLOAD];
  frame[0] = 'M';
  frame[1] = 'P';
  frame[2] = type;
  frame[3] = payloadLen;
  memcpy(&frame[4], payload, payloadLen);

  if(!btNotifyBytes(frame, (uint8_t)(payloadLen + 4)))
    return false;

  BtLeFramesSent++;
  return true;
}

static void btWriteU16LE(uint8_t* p, uint16_t value)
{
  p[0] = (uint8_t)(value & 0xFF);
  p[1] = (uint8_t)(value >> 8);
}

static void btWriteS32LE(uint8_t* p, int32_t value)
{
  const uint32_t u = (uint32_t)value;
  p[0] = (uint8_t)(u & 0xFF);
  p[1] = (uint8_t)((u >> 8) & 0xFF);
  p[2] = (uint8_t)((u >> 16) & 0xFF);
  p[3] = (uint8_t)((u >> 24) & 0xFF);
}

static void btSendSimulation()
{
  if(!BtLeSimuEnabled || !BtLeConnected)
    return;

  const uint32_t now = millis();
  if(BtSimLastMs && (uint32_t)(now - BtSimLastMs) < BT_SIM_PERIOD_MS)
    return;
  BtSimLastMs = now;

  // Battery: 12.60 V -> 10.80 V in 0.01 V steps, then restart.
  if(!BtSimLastVoltageMs)
    BtSimLastVoltageMs = now;
  if((uint32_t)(now - BtSimLastVoltageMs) >= 1000UL)
  {
    BtSimLastVoltageMs = now;
    if(BtSimVoltageX100 > BT_SIM_VOLTAGE_END_X100)
      BtSimVoltageX100--;
    else
      BtSimVoltageX100 = BT_SIM_VOLTAGE_START_X100;
  }

  // Twenty GPS positions between A and B. The index is played forward then
  // backward so there is no discontinuous GPS jump when the route loops.
  const double routeT = (double)BtSimPointIndex / (double)(BT_SIM_POINT_COUNT - 1);
  const double lat = BT_SIM_POINT_A_LAT
                   + (BT_SIM_POINT_B_LAT - BT_SIM_POINT_A_LAT) * routeT;
  const double lon = BT_SIM_POINT_A_LON
                   + (BT_SIM_POINT_B_LON - BT_SIM_POINT_A_LON) * routeT;
  const double altM = 25.0 + 5.0 * sin(routeT * PI);

  // Heading follows the route direction. Equirectangular approximation is
  // more than sufficient for this ~95 m simulator path.
  const double meanLatRad = ((BT_SIM_POINT_A_LAT + BT_SIM_POINT_B_LAT) * 0.5) * DEG_TO_RAD;
  const double north = BT_SIM_POINT_B_LAT - BT_SIM_POINT_A_LAT;
  const double east = (BT_SIM_POINT_B_LON - BT_SIM_POINT_A_LON) * cos(meanLatRad);
  double headingDeg = atan2(east, north) * RAD_TO_DEG;
  if(headingDeg < 0.0)
    headingDeg += 360.0;
  if(BtSimPointDirection < 0)
  {
    headingDeg += 180.0;
    if(headingDeg >= 360.0)
      headingDeg -= 360.0;
  }

  // Normal telemetry frame: model battery, LQ and RSSI.
  uint8_t aa[13];
  uint8_t i = 0;
  aa[i++] = 220; // MULTI TX_RSSI
  aa[i++] = 0x03; aa[i++] = 0x00;
  btWriteU16LE(&aa[i], BtSimVoltageX100); i += 2;
  aa[i++] = 0xFE; aa[i++] = 0x00;
  btWriteU16LE(&aa[i], 5); i += 2;       // 5% error -> 95% LQ
  aa[i++] = 0xFC; aa[i++] = 0x00;
  btWriteU16LE(&aa[i], 45); i += 2;      // -45 dBm
  btSendMpFrame(0x06, aa, i);

  // Extended telemetry frame: GPS_FULL + COG + ground speed.
  uint8_t ac[28];
  i = 0;
  ac[i++] = 220; // MULTI TX_RSSI

  ac[i++] = 0xFD; // GPS_FULL
  ac[i++] = 0x00; // instance
  ac[i++] = 14;   // payload size
  ac[i++] = 1;    // GPS fix
  ac[i++] = 10;   // satellites
  btWriteS32LE(&ac[i], (int32_t)llround(lat * 10000000.0)); i += 4;
  btWriteS32LE(&ac[i], (int32_t)llround(lon * 10000000.0)); i += 4;
  btWriteS32LE(&ac[i], (int32_t)llround(altM * 100.0)); i += 4;

  ac[i++] = 0x0A; // GPS COG x100
  ac[i++] = 0x00;
  ac[i++] = 2;
  btWriteU16LE(&ac[i], (uint16_t)lround(headingDeg * 100.0)); i += 2;

  ac[i++] = 0x13; // GPS ground speed, m/s x100
  ac[i++] = 0x00;
  ac[i++] = 2;
  btWriteU16LE(&ac[i], (uint16_t)lround(BT_SIM_SPEED_MS * 100.0)); i += 2;

  btSendMpFrame(0x0C, ac, i);
  BtLeSimFramesSent += 2;

  // Move to the next route point for the next simulator period.
  if(BtSimPointDirection > 0)
  {
    if(BtSimPointIndex + 1 >= BT_SIM_POINT_COUNT)
    {
      BtSimPointDirection = -1;
      if(BtSimPointIndex > 0)
        BtSimPointIndex--;
    }
    else
      BtSimPointIndex++;
  }
  else
  {
    if(BtSimPointIndex == 0)
    {
      BtSimPointDirection = 1;
      if(BT_SIM_POINT_COUNT > 1)
        BtSimPointIndex++;
    }
    else
      BtSimPointIndex--;
  }
}

static void btProcess()
{
  if(!BtLeEnabled || !BtLeStackStarted)
    return;

  if(BtLeSimuEnabled)
  {
    btSendSimulation();
    return;
  }

  if(!BtLeConnected)
  {
    btQueueClear();
    return;
  }

  // Send at most one real telemetry frame per loop pass. The RF acquisition
  // itself remains fully independent in the ESP timer task.
  uint8_t type = 0;
  uint8_t len = 0;
  uint8_t payload[BTLE_MP_MAX_PAYLOAD];
  if(btQueuePop(&type, &len, payload))
    btSendMpFrame(type, payload, len);
}
