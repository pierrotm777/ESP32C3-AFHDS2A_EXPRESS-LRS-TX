package juricabi.com.telemetry.protocol

import juricabi.com.telemetry.protocol.decoder.DataDecoder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Afhds2aProtocolTest {

    private class Captor : DataDecoder.Companion.DefaultDecodeListener() {
        var voltage = Float.NaN
        var rssi = -1
        var channels = IntArray(0)
        var decodes = 0

        override fun onVBATOrCellData(voltage: Float) { this.voltage = voltage }
        override fun onRSSIData(rssi: Int) { this.rssi = rssi }
        override fun onRCChannels(rcChannels: IntArray) { channels = rcChannels.copyOf() }
        override fun onSuccessDecode() { decodes++ }
    }

    private fun feed(protocol: Protocol, bytes: IntArray) {
        bytes.forEach { protocol.process(it and 0xff) }
    }

    @Test
    fun normalMultiTelemetryDecodes() {
        val captor = Captor()
        val protocol = Afhds2aProtocol(captor)

        // MP 06, payload: TX RSSI=255 + external voltage sensor 0x03 = 1260 (12.60 V).
        feed(protocol, intArrayOf(
            0x4d, 0x50, 0x06, 0x05,
            0xff,
            0x03, 0x00, 0xec, 0x04
        ))

        assertEquals(100, captor.rssi)
        assertEquals(12.60f, captor.voltage, 0.001f)
        assertTrue(captor.decodes >= 2)
    }

    @Test
    fun multiRcFrameFeedsExistingRcWidgetPath() {
        val captor = Captor()
        val protocol = Afhds2aProtocol(captor)
        val raw = intArrayOf(224, 624, 1024, 1424, 1824, 1024, 1024, 1024)
        val packed = pack11(raw)
        val payload = intArrayOf(50, 200, 0, raw.size, *packed)
        val frame = intArrayOf(0x4d, 0x50, 0x0d, payload.size, *payload)

        feed(protocol, frame)

        assertTrue(captor.channels.size >= 8)
        assertEquals(1000, captor.channels[0])
        assertEquals(1250, captor.channels[1])
        assertEquals(1500, captor.channels[2])
        assertEquals(1750, captor.channels[3])
        assertEquals(2000, captor.channels[4])
    }

    @Test
    fun detectorRecognizesAfhds2a() {
        var detected: Protocol? = null
        val detector = ProtocolDetector(object : ProtocolDetector.Callback {
            override fun onProtocolDetected(protocol: Protocol?) { detected = protocol }
        })
        val frame = intArrayOf(
            0x4d, 0x50, 0x06, 0x05,
            0xff,
            0x03, 0x00, 0xec, 0x04
        )
        frame.forEach { detector.feedData(it) }
        assertTrue(detected is Afhds2aProtocol)
    }

    private fun pack11(values: IntArray): IntArray {
        val out = ArrayList<Int>()
        var scratch = 0L
        var bits = 0
        for (value in values) {
            scratch = scratch or ((value.toLong() and 0x7ffL) shl bits)
            bits += 11
            while (bits >= 8) {
                out.add((scratch and 0xffL).toInt())
                scratch = scratch ushr 8
                bits -= 8
            }
        }
        if (bits > 0) out.add((scratch and 0xffL).toInt())
        return out.toIntArray()
    }
}
