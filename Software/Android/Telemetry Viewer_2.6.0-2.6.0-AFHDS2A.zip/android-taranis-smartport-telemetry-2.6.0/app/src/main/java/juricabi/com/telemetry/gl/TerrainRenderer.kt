package juricabi.com.telemetry.gl

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Draws the scene: ground, the aerial view draped over it, and the flight.
 *
 * The camera orbits a point — an angle round, an angle up, and a distance —
 * which is what a finger on a screen naturally controls, and what keeps the
 * flight in view however the ground is shaped.
 */
class TerrainRenderer : GLSurfaceView.Renderer {

    companion object {
        private const val TERRAIN_VERTEX = """
            uniform mat4 uMvp;
            attribute vec4 aPosition;
            attribute vec2 aTexture;
            attribute vec2 aShades;
            attribute float aParentY;
            attribute float aGrandY;
            attribute float aEdge;
            uniform float uUvScale;
            uniform vec2 uUvOff;
            uniform vec3 uEye;
            uniform vec2 uMorph;
            uniform float uForce[5];
            varying vec2 vTexture;
            varying float vShade;
            void main() {
                // The vertex slides onto its parent level's line as its
                // distance nears the band where the pager would draw the
                // parent instead — so by the time a coarser neighbour can
                // stand beside this tile, the shared edge already IS the
                // coarser line. And the target is the parent AS DRAWN: the
                // parent is itself sliding toward the grandparent inside
                // its own band (twice this tile's distances), so the slide
                // aims at that moving line — aimed at the parent's raw
                // data, every swap heaved the far half of the square.
                //
                // The stitch: on an edge that faces a coarser DRAWN
                // neighbour, the slide is forced to completion whatever the
                // distance — boundaries born of hysteresis, of the behind
                // economy, or of tiles still building all put a coarser
                // tile beside a barely-morphed fine one, and the step
                // between them stood as the wall. An edge lying fully on
                // the neighbour's own line has nothing to step over.
                //
                float fa = uForce[int(floor(aEdge / 5.0))];
                float fb = uForce[int(mod(aEdge, 5.0))];
                float f = max(fa, fb);
                float d = distance(aPosition.xyz, uEye);
                float m = clamp((d - uMorph.x) * uMorph.y, 0.0, 1.0);
                m = max(m, min(f, 1.0));
                float m2 = clamp((d - 2.0 * uMorph.x) * uMorph.y * 0.5, 0.0, 1.0);
                m2 = max(m2, clamp(f - 1.0, 0.0, 1.0));
                gl_Position = uMvp * vec4(aPosition.x,
                    mix(aPosition.y, mix(aParentY, aGrandY, m2), m),
                    aPosition.z, 1.0);
                // A tile whose own picture has not arrived borrows an
                // ancestor's, reading only its own quarter of a quarter of it:
                // fine ground with a soft photograph beats grey, and the sharp
                // one replaces it in place when it lands.
                vTexture = aTexture * uUvScale + uUvOff;
                // Shade is baked per vertex against the fixed light — and it
                // morphs with the heights, so fine relief no longer rides on
                // geometry that has already flattened to the coarse line.
                vShade = mix(aShades.x, aShades.y, m);
            }
        """

        private const val TERRAIN_FRAGMENT = """
            precision mediump float;
            uniform sampler2D uTexture;
            uniform float uHasTexture;
            uniform vec3 uBase;
            uniform float uAlpha;
            varying vec2 vTexture;
            varying float vShade;
            void main() {
                vec3 base = mix(uBase, texture2D(uTexture, vTexture).rgb, uHasTexture);
                gl_FragColor = vec4(base * vShade, uAlpha);
            }
        """

        /** The model: shaded, with its own edges drawn in the same pass. */
        private const val MODEL_VERTEX = """
            uniform mat4 uMvp;
            attribute vec4 aPosition;
            attribute vec3 aCorner;
            attribute vec3 aNormal;
            varying vec3 vCorner;
            varying float vShade;
            void main() {
                gl_Position = uMvp * aPosition;
                vCorner = aCorner;
                // How much a face lies across the light, not which way it faces
                // it. A solid built from boxes and posts does not wind every
                // triangle alike, and a signed dot leaves whichever came out
                // backwards flat black; this cannot, and still tells a top from
                // a side from an end.
                vec3 light = normalize(vec3(-0.5, 0.8, -0.4));
                vShade = 0.82 + 0.18 * abs(dot(normalize(aNormal), light));
            }
        """

        /**
         * Screen space edges: how fast a corner weight changes across a pixel
         * says how wide a line of even thickness has to be, whatever the size or
         * angle of the triangle. Without it a long thin face gets a hairline
         * down its side and a fat band across its end.
         */
        private const val MODEL_FRAGMENT_EVEN = """
            #extension GL_OES_standard_derivatives : enable
            precision mediump float;
            uniform vec3 uBase;
            uniform float uInk;
            varying vec3 vCorner;
            varying float vShade;
            void main() {
                vec3 wide = fwidth(vCorner) * uInk;
                vec3 near = smoothstep(vec3(0.0), wide, vCorner);
                float ink = min(min(near.x, near.y), near.z);
                vec3 colour = mix(vec3(0.13, 0.13, 0.16), uBase * vShade, ink);
                gl_FragColor = vec4(colour, 1.0);
            }
        """

        /** The same, for anything without derivatives: a line of even share. */
        private const val MODEL_FRAGMENT = """
            precision mediump float;
            uniform vec3 uBase;
            uniform float uInk;
            varying vec3 vCorner;
            varying float vShade;
            void main() {
                float edge = min(min(vCorner.x, vCorner.y), vCorner.z);
                float ink = smoothstep(0.0, uInk * 0.028, edge);
                vec3 colour = mix(vec3(0.13, 0.13, 0.16), uBase * vShade, ink);
                gl_FragColor = vec4(colour, 1.0);
            }
        """

        private const val LINE_VERTEX = """
            uniform mat4 uMvp;
            attribute vec4 aPosition;
            void main() {
                gl_Position = uMvp * aPosition;
                gl_PointSize = 8.0;
            }
        """

        private const val LINE_FRAGMENT = """
            precision mediump float;
            uniform vec4 uColor;
            void main() { gl_FragColor = uColor; }
        """

        /** How much of the way to what it has been told, each frame. */
        private const val SMOOTHING = 0.18f

        /** The vertical field of view; the pager's screen-error maths uses it too. */
        const val FOV_Y = 50f

        /**
         * Meshes sent to the card per frame, at most. Eight is still several
         * hundred a second — far past the build rate — and small enough that
         * a burst never steals visible milliseconds from a replay's frame.
         */
        private const val UPLOADS_PER_FRAME = 8

        /** How many fixes can arrive between two rebuilds of the flight. */
        private const val SPARE_POINTS = 600

        private const val FLOATS_PER_VERTEX = 10

        /** The model layout: position, corner weights, normal. */
        private const val MODEL_FLOATS = 9

        /** The dissolve, both ways: a picture change reads as light, not a cut. */
        private const val FADE_MS = 250f

        /**
         * Dissolves in flight at once, at most. A sharpening front swaps a
         * picture a frame; unbounded, a quarter second of that holds tens of
         * yesterdays' textures — most of the budget — so past this many the
         * oldest simply snaps to its new picture, which in a storm of swaps
         * no eye singles out.
         */
        private const val MAX_FADES = 12
    }

    /**
     * A tile living on the graphics card.
     *
     * Its geometry is uploaded once. Drawing from a FloatBuffer instead meant
     * handing the driver every vertex of every tile on every frame — a third of
     * a million vertices, ten megabytes, sixty times a second — which is what
     * made the ground feel heavy.
     */
    private class Tile(
        val key: Long,
        val vertexBuffer: Int,
        val indexBuffer: Int,
        val count: Int,
        /** Indices per quadrant run, skirts after; 0 when ungrouped. */
        val quadCount: Int,
        var textureId: Int,
        /** The tile's box in world metres, for the frustum test. */
        val minX: Float, val maxX: Float,
        val minY: Float, val maxY: Float,
        val minZ: Float, val maxZ: Float
    ) {
        /** The picture this one replaced, kept while the new one dissolves in. */
        var prevTextureId = 0
        var swappedAt = 0L

    }

    /** By key, so a tile without its own picture can find an ancestor's. */
    private val tiles = HashMap<Long, Tile>()
    private val pending = ArrayList<TerrainScene.TileMesh>()

    /**
     * Pictures for tiles whose shape is already up, in their own queue.
     *
     * They used to share [pending], whose emptiness is what lets a new draw
     * set apply — so a burst of pictures, throttled to a couple per frame,
     * held the draw set stale for seconds while evictions applied instantly:
     * tiles vanished from under the stale list and left holes with the
     * neighbours' skirts hanging into them.
     */
    private val pendingPictures = ArrayList<TerrainScene.TileMesh>()

    /** Tiles whose pictures the pager reclaimed; the GL objects die here. */
    private val pendingStrips = ArrayList<Long>()

    /**
     * Drop a tile's picture but keep its mesh: the pager reclaims texture
     * memory from covered-over ancestors this way. The GL deletes happen
     * on the GL thread with the other uploads.
     */
    @Synchronized
    fun strip(key: Long) {
        pendingStrips.add(key)
    }

    /** Pictures stitched but not yet on the card, for the dress workers'
     * backpressure: each can be eight megabytes of heap, and stitching
     * faster than one-per-frame uploads drain simply piles them up —
     * chase cam over Velebit piled the heap to death. */
    @Synchronized
    fun pictureBacklog(): Int = pendingPictures.size

    /**
     * Told when a new context arrives with nothing in it; runs on the GL
     * thread. The meshes used to be retained on the heap for this moment —
     * which at a few hundred resident tiles was hundreds of megabytes and an
     * OutOfMemory, kept against an event that rebuilds from warm disk caches
     * in a couple of seconds anyway. Now the pager just builds the world
     * again, the way it built it the first time.
     */
    @Volatile var onPicturesLost: (() -> Unit)? = null

    /** The tiles still wanted, once the scene has said. Null means all of them. */
    private var keep: HashSet<Long>? = null
    private var keepChanged = false

    /**
     * The tiles to actually draw — the pager's cover, a subset of what is
     * resident. Null means all of them, which is what the old window flow
     * still relies on. [drawSetWanted] waits until the upload queue drains,
     * so a set naming a tile still in the queue never draws a hole.
     */
    private var drawSet: HashSet<Long>? = null
    private var drawSetWanted: HashSet<Long>? = null
    private var quadMasks: HashMap<Long, Int> = HashMap()
    private var drawSetWantedMasks: HashMap<Long, Int> = HashMap()

    /**
     * The pixels-per-radian the pager selected this cut with. Applied in
     * the same locked step as the cut itself, so the morph bands always
     * belong to the cut they guard — computed live from the surface, a
     * rotation re-banded a standing world and every seam guarantee with it.
     */
    private var morphK = 0.0
    private var morphKWanted = 0.0

    /**
     * Tiles that just left the draw set with a picture on, and when: they
     * are drawn once more, dissolving out over the level that replaced
     * them, instead of cutting. Keyed by tile, read and written only under
     * the monitor; the tiles themselves outlive the entry because
     * [pruneLocked] will not delete a tile still saying goodbye.
     */
    private val retiring = HashMap<Long, Long>()

    /**
     * [masks]: for a tile drawn partially, which quadrants its standing
     * children cover — bit cy*2+cx set means that quarter is theirs.
     * Applied atomically with the draw set, or a quarter would double-draw
     * for a frame.
     */
    @Synchronized
    fun setDrawSet(keys: Set<Long>, masks: Map<Long, Int>, selectedK: Double) {
        drawSetWanted = HashSet(keys)
        drawSetWantedMasks = HashMap(masks)
        morphKWanted = selectedK
    }

    private var trackBuffer: FloatBuffer? = null
    private var trackCount = 0
    private var shadowBuffer: FloatBuffer? = null
    private var shadowCount = 0
    private var dropBuffer: FloatBuffer? = null

    /**
     * The flight is three things — a line in the air, its shadow on the ground
     * and the curtain hanging between them — and they have to agree about where
     * it ends, or the joins between them tear.
     *
     * All three are rebuilt together twice a second and all three grow together
     * on every fix in between, so the last point of each is the newest fix. The
     * model is drawn a little behind that, easing towards it, so it is always
     * somewhere along that final stretch — and each of the three is drawn up to
     * the one before it and then on to the model. Nothing to decide per frame,
     * and nothing that can fall short, overshoot or disagree.
     */
    private var headGroundY = 0f
    private val headQuad = FloatArray(18)
    private val headQuadBuffer = floats(FloatArray(18))

    private val leaderPair = FloatArray(6)
    private val leaderPairBuffer = floats(FloatArray(6))

    @Volatile private var homeOn = false
    private var homeX = 0f
    private var homeY = 0f
    private var homeZ = 0f
    private var homeR = 1f
    private var homeG = 1f
    private var homeB = 1f
    private var homeA = 1f

    @Volatile private var operatorOn = false
    private var operatorX = 0f
    private var operatorY = 0f
    private var operatorZ = 0f
    private var operatorR = 1f
    private var operatorG = 1f
    private var operatorB = 1f
    private var operatorA = 1f

    @Volatile private var headingOn = false
    private var headR = 1f
    private var headG = 1f
    private var headB = 1f
    private var headA = 1f
    private var dropCount = 0

    /** How many points of flight each built quad of curtain spans. */
    private var curtainStep = 1

    /** And how many quads have been added a point at a time since. */
    private var appendedQuads = 0

    private var terrainProgram = 0
    private var modelProgram = 0

    /** One haze-grey texel for ground whose ancestry has no picture yet. */
    private var bareTex = 0
    private var lineProgram = 0

    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val mvp = FloatArray(16)
    private val liftMatrix = FloatArray(16)
    private val liftMvp = FloatArray(16)

    /** How much the camera is being held up off the ground, eased over frames. */
    private var floorLift = 0f

    /**
     * Where the camera and the model actually are this frame, as against where
     * they have been told to be.
     *
     * Telemetry lands a few times a second and the screen draws sixty: taken
     * literally, everything steps rather than moves. Both are eased at the same
     * rate, so the model does not wander around the middle of the screen while
     * the camera catches up with it.
     */
    private val shownTarget = FloatArray(3)
    private var shownX = 0f
    private var shownY = 0f
    private var shownZ = 0f
    private var shownHeading = 0f
    private var shownPitch = 0f
    private var shownRoll = 0f
    private var placed = false

    private fun ease(from: Float, to: Float): Float = from + (to - from) * SMOOTHING

    /** The short way round, so a turn through north is not a lap of the compass. */
    private fun easeAngle(from: Float, to: Float): Float =
        juricabi.com.telemetry.utils.GeoUtils.turnTowards(from, to, SMOOTHING)

    /**
     * Follow where things have been put, unless they have been put somewhere
     * else entirely — a jump to your own location, or the first position of
     * all, should arrive rather than glide.
     */
    /**
     * Put the model where it has been told, at once, without easing to it.
     *
     * Easing assumes the next place is a fix or so away. When a whole batch of
     * flight arrives together — which is how a replay delivers it — the model
     * would otherwise walk through it while the flight is already drawn to the
     * end of the batch, so the flight runs on past the model in front of it.
     */
    /** Nothing to show until the next point arrives. */
    @Synchronized
    fun hideModel() {
        modelVisible = false
    }

    @Synchronized
    fun snapToTarget() {
        placed = false
    }

    /**
     * Whether the camera has just been put somewhere rather than having glided
     * there, in which case the ground under it is taken at once as well.
     */
    private var liftsSnap = false
    private var targetLift = 0f

    private fun settle() {
        val t = target
        val far = Math.max(200f, distance * 0.5f)
        val dx = t[0] - shownTarget[0]
        val dy = t[1] - shownTarget[1]
        val dz = t[2] - shownTarget[2]
        if (!placed || dx * dx + dy * dy + dz * dz > far * far) {
            placed = true
            liftsSnap = true
            shownTarget[0] = t[0]; shownTarget[1] = t[1]; shownTarget[2] = t[2]
            shownX = modelX; shownY = modelY; shownZ = modelZ
            shownHeading = modelHeading; shownPitch = modelPitch; shownRoll = modelRoll
            return
        }
        shownTarget[0] = ease(shownTarget[0], t[0])
        shownTarget[1] = ease(shownTarget[1], t[1])
        shownTarget[2] = ease(shownTarget[2], t[2])
        shownX = ease(shownX, modelX)
        shownY = ease(shownY, modelY)
        shownZ = ease(shownZ, modelZ)
        shownHeading = easeAngle(shownHeading, modelHeading)
        shownPitch = easeAngle(shownPitch, modelPitch)
        shownRoll = easeAngle(shownRoll, modelRoll)
    }

    /** Orbit: degrees round, degrees up, and how far out. */
    @Volatile var azimuth = 30f
    @Volatile var elevation = 28f
    @Volatile var distance = 1500f

    /**
     * Where something else wants the camera to look from, eased into rather
     * than snapped to. An aircraft's heading arrives many times a second and
     * wanders by a degree or two on every one of them; taken literally the
     * camera shakes. Not a number when nothing is steering it.
     */
    @Volatile var azimuthWanted = Float.NaN

    /**
     * Riding behind the model: the camera keeps to the far side of the heading
     * the model is *drawn* at, not the one last reported.
     *
     * Those are different things — the model is eased between attitudes, so
     * aiming the camera at the raw heading had the two turning at their own
     * rates and the camera never quite square behind it.
     */
    @Volatile var chasingModel = false

    /** How far the camera has been leaned out of that, in degrees. */
    @Volatile var chaseYaw = 0f

    /** As far out as the ground goes; set from the flight, not guessed. */
    @Volatile var maxDistance = 3000f
    @Volatile var target = floatArrayOf(0f, 0f, 0f)

    /**
     * Where the camera actually stood last frame, in world metres, and how
     * tall the surface is. The pager's screen-error arithmetic reads these:
     * the eye rather than the target, because tile detail is a question of
     * how far the *viewer* is from the ground, wherever they are looking.
     */
    @Volatile var eyeX = 0f; private set
    @Volatile var eyeY = 0f; private set
    @Volatile var eyeZ = 0f; private set
    @Volatile var viewHeightPx = 1; private set
    @Volatile var viewWidthPx = 1; private set

    /** Which way the camera faces, so detail can chase the view. */
    @Volatile var viewDirX = 0f; private set
    @Volatile var viewDirY = 0f; private set
    @Volatile var viewDirZ = -1f; private set

    /**
     * No exaggeration. Heights were stretched by nearly half to make hills
     * read from above, which also made every flight look half again as high as
     * it was — and a height you cannot trust is worse than a flat looking hill.
     */


    @Volatile var trackColor = floatArrayOf(1f, 0.85f, 0.1f, 1f)

    /** The model's colour, from the same setting that tints the map marker. */
    @Volatile var modelColor = floatArrayOf(1f, 0.25f, 0.15f, 1f)

    /** Anything else worth drawing as lines: home, heading, plans, traffic. */
    class LineSet(
        val vertices: FloatArray,
        val red: Float, val green: Float, val blue: Float, val alpha: Float,
        val strip: Boolean,
        val width: Float,
        val onGround: Boolean
    )

    private class DrawnSet(val buffer: FloatBuffer, val count: Int, val set: LineSet)

    private var overlays: List<DrawnSet> = emptyList()

    @Synchronized
    /**
     * The flight plans, the traffic and the accuracy ring, as lines to draw.
     *
     * Refilled where the shape has not changed. This is called on every fix,
     * and a draped flight plan is thousands of floats: replacing every buffer
     * each time was megabytes a second of direct memory, which is freed only
     * when the collector gets round to it.
     */
    fun setOverlays(sets: List<LineSet>) {
        val standing = overlays
        val drawn = ArrayList<DrawnSet>()
        var i = 0
        for (set in sets) {
            if (set.vertices.size < 6) continue
            val count = set.vertices.size / 3
            val old = if (i < standing.size) standing[i] else null
            if (old != null && old.count == count && old.buffer.capacity() == set.vertices.size) {
                fill(old.buffer, set.vertices)
                drawn.add(DrawnSet(old.buffer, count, set))
            } else {
                drawn.add(DrawnSet(floats(set.vertices), count, set))
            }
            i++
        }
        overlays = drawn
    }


    private var modelBuffer: FloatBuffer? = null
    private var modelCount = 0
    private val modelMatrix = FloatArray(16)
    private val modelMvp = FloatArray(16)
    @Volatile private var modelVisible = false
    @Volatile private var modelX = 0f
    @Volatile private var modelY = 0f
    @Volatile private var modelZ = 0f
    @Volatile private var modelHeading = 0f
    @Volatile private var modelPitch = 0f
    @Volatile private var modelRoll = 0f
    @Volatile private var modelSize = 40f

    /**
     * Where the model is and which way it is going. Size is in metres, since a
     * dart drawn to scale would be a speck from any useful distance.
     */
    @Synchronized
    fun setModel(x: Float, y: Float, z: Float, headingDegrees: Float, size: Float,
                 pitchDegrees: Float = 0f, rollDegrees: Float = 0f) {
        modelX = x; modelY = y; modelZ = z
        modelHeading = headingDegrees
        modelPitch = pitchDegrees
        modelRoll = rollDegrees
        modelSize = size
        modelVisible = true
        if (modelBuffer == null || builtShape != modelShape) {
            val mesh = when (modelShape) {
                "plane" -> ModelMeshes.plane()
                "heli" -> ModelMeshes.heli()
                else -> ModelMeshes.quad()
            }
            modelBuffer = floats(mesh)
            // eight floats a vertex now, not three: dividing by three drew far
            // more triangles than the mesh has and read whatever lay past its
            // end, which is what tore the model apart
            modelCount = mesh.size / MODEL_FLOATS
            builtShape = modelShape
        }
    }

    /** "quad", "plane" or "heli": the same choice the map marker follows. */
    @Volatile var modelShape = "quad"
    private var builtShape = ""

    private var arrowBuffer: FloatBuffer? = null
    private var arrowCount = 0
    private var puckBuffer: FloatBuffer? = null
    private var puckCount = 0
    private val arrowMatrix = FloatArray(16)
    private val arrowMvp = FloatArray(16)
    /**
     * An arrow standing on the ground, with the ring of its accuracy round it.
     *
     * There are two: where this phone is, and — replaying a flight — where it
     * stood while that flight was recorded. They mean different things and are
     * drawn in different colours, and they can be a county apart.
     *
     * [heading] eases towards [headingTarget] as the thing it belongs to turns,
     * which is why each keeps its own: they turn independently.
     */
    private class Spot(val base: FloatArray, val ink: FloatArray) {
        @Volatile var visible = false

        /**
         * Whether direction is known and this is an arrow rather than a puck.
         *
         * A phone with no compass knows where it is and not which way it
         * faces. A puck keeps that known position visible without inventing a
         * north-facing arrow.
         */
        @Volatile var pointing = true
        @Volatile var x = 0f
        @Volatile var y = 0f
        @Volatile var z = 0f
        @Volatile var headingTarget = 0f
        var heading = 0f
        var ring: FloatBuffer? = null
        var ringCount = 0
    }

    private val me = Spot(
        floatArrayOf(0.42f, 0.76f, 1f), floatArrayOf(0.2f, 0.6f, 1f, 0.9f)
    )
    private val logged = Spot(
        floatArrayOf(1f, 0.62f, 0.13f), floatArrayOf(1f, 0.6f, 0.1f, 0.9f)
    )

    /**
     * The colours of the two arrows and the rings around them.
     *
     * Brighter than the same colour on the map, deliberately: satellite imagery
     * is dark greens and browns, and a colour that reads on a flat map sinks
     * into it.
     */
    fun setArrowColours(live: Int, logged: Int) {
        paint(me, live)
        paint(this.logged, logged)
    }

    private fun paint(spot: Spot, argb: Int) {
        val r = ((argb shr 16) and 0xFF) / 255f
        val g = ((argb shr 8) and 0xFF) / 255f
        val b = (argb and 0xFF) / 255f
        spot.base[0] = Math.min(1f, r * 1.15f + 0.06f)
        spot.base[1] = Math.min(1f, g * 1.15f + 0.06f)
        spot.base[2] = Math.min(1f, b * 1.15f + 0.06f)
        spot.ink[0] = r
        spot.ink[1] = g
        spot.ink[2] = b
        spot.ink[3] = 0.9f
    }

    /**
     * Where you are standing and which way you face.
     *
     * Position only: the size is worked out per frame from how far the camera
     * is, so the arrow holds its size on the screen the way a marker on a map
     * does. Fixed in metres it was a speck from high up and covered the hill
     * from close in.
     */
    @Synchronized
    /** Nothing known about this phone: the arrow goes, rather than moving. */
    fun hideMyLocation() {
        me.visible = false
    }

    fun setMyLocation(x: Float, y: Float, z: Float, headingDegrees: Float,
                      pointing: Boolean = true) {
        me.pointing = pointing
        place(me, x, y, z, headingDegrees)
    }

    /** Where the phone stood while the flight being replayed was recorded. */
    fun hideLoggedLocation() {
        logged.visible = false
    }

    fun setLoggedLocation(
        x: Float, y: Float, z: Float, headingDegrees: Float,
        pointing: Boolean = true
    ) {
        logged.pointing = pointing
        place(logged, x, y, z, headingDegrees)
    }

    /**
     * Under the lock for the mesh, which the two arrows share.
     *
     * One of them is placed by the compass, on the sensor thread, and the other
     * by a replay on the screen's — and the drawing thread reads the mesh under
     * this same lock. Built outside it, a buffer half-filled by one thread
     * could be handed to either of the others as though it were finished.
     */
    @Synchronized
    private fun place(spot: Spot, x: Float, y: Float, z: Float, headingDegrees: Float) {
        spot.x = x; spot.y = y; spot.z = z
        spot.headingTarget = headingDegrees
        spot.visible = true
        if (arrowBuffer == null) {
            val mesh = arrowMesh()
            arrowBuffer = floats(mesh)
            arrowCount = mesh.size / MODEL_FLOATS
        }
        if (puckBuffer == null) {
            val mesh = puckMesh()
            puckBuffer = floats(mesh)
            puckCount = mesh.size / MODEL_FLOATS
        }
    }

    /**
     * A unit arrow: nose along -z, swept corners, a raised spine.
     *
     * Built the way the model is, so the same shader lights it and inks in its
     * edges. Five corners and six faces, every edge of it a real one, so none
     * are marked as seams.
     */
    private fun arrowMesh(): FloatArray {
        val nose = floatArrayOf(0f, 0f, -1.6f)
        val left = floatArrayOf(-1f, 0f, 1f)
        val right = floatArrayOf(1f, 0f, 1f)
        val tail = floatArrayOf(0f, 0f, 0.4f)
        val spine = floatArrayOf(0f, 0.8f, 0.1f)
        val solid = ModelMeshes.Solid()
        solid.tri(nose, left, spine)
        solid.tri(nose, spine, right)
        solid.tri(left, tail, spine)
        solid.tri(tail, right, spine)
        solid.tri(nose, tail, left)
        solid.tri(nose, right, tail)
        return solid.build()
    }

    /** A low marker for a known place whose direction was not recorded. */
    private fun puckMesh(): FloatArray {
        val solid = ModelMeshes.Solid()
        solid.post(0f, 0f, 0.8f, 0f, 0.22f, 16)
        return solid.build()
    }

    /** The accuracy ring, already laid on the ground by whoever built it. */
    @Synchronized
    fun setAccuracyCircle(ring: FloatArray) {
        encircle(me, ring)
    }

    @Synchronized
    fun setLoggedCircle(ring: FloatArray) {
        encircle(logged, ring)
    }

    private fun encircle(spot: Spot, ring: FloatArray) {
        if (ring.size < 9) {
            spot.ring = null
            spot.ringCount = 0
            return
        }
        spot.ring = floats(ring)
        spot.ringCount = ring.size / 3
    }

    /** Ground height at a point in the local frame, so the camera can stay above it. */
    @Volatile var groundUnderCamera: ((Float, Float) -> Float?)? = null

    private var surfaceWidth = 1
    private var surfaceHeight = 1

    // ------------------------------------------------------------- feeding


    /**
     * One tile, as soon as it is built, without disturbing the others.
     *
     * The ground is built a tile at a time and shown as it arrives, so this is
     * how nearly all of it comes in. A tile offered twice — once for its shape
     * and again when its picture has been fetched — replaces the first.
     */
    @Synchronized
    fun offer(mesh: TerrainScene.TileMesh) {
        // A picture for a tile already standing rides its own queue; only a
        // new shape goes through pending, whose drain is what admits a new
        // draw set.
        if (tiles.containsKey(mesh.key) && mesh.texture != null) {
            pendingPictures.add(mesh)
        } else {
            pending.add(mesh)
        }
    }

    /**
     * Which tiles are still wanted; anything else is thrown away next frame.
     *
     * Handed an empty set, everything goes — which is what settling the
     * altitude reference needs, since that moves the whole world and the same
     * ground comes back with different heights under the same names.
     */
    @Synchronized
    fun keepOnly(keys: Set<Long>) {
        keep = HashSet(keys)
        keepChanged = true
        // and the pictures waiting for tiles that are no longer wanted —
        // theirs is the one heap copy, and this is its owner letting go
        var i = 0
        while (i < pendingPictures.size) {
            if (!keys.contains(pendingPictures[i].key)) {
                pendingPictures[i].texture?.let { if (!it.isRecycled) it.recycle() }
                pendingPictures.removeAt(i)
            } else {
                i++
            }
        }
    }

    /**
     * The newest fix, added to all three at once.
     *
     * Rebuilding the whole flight is the tick's work — it is thinned, smoothed,
     * and its curtain is built from scratch — but the line has to keep up with
     * the model, and one more point is a handful of floats.
     */
    @Synchronized
    fun appendFlightPoint(x: Float, y: Float, z: Float, groundY: Float) {
        val air = trackBuffer ?: return
        val ground = shadowBuffer ?: return
        if (trackCount < 1 || shadowCount != trackCount) return
        if ((trackCount + 1) * 3 > air.capacity()) return
        if ((shadowCount + 1) * 3 > ground.capacity()) return

        val previous = (trackCount - 1) * 3
        val ax = air.get(previous)
        val ay = air.get(previous + 1)
        val az = air.get(previous + 2)
        val sx = ground.get(previous)
        val sy = ground.get(previous + 1)
        val sz = ground.get(previous + 2)

        // Written where they belong, rather than by walking the buffer there.
        //
        // The drawing thread hands these very buffers to the driver, which
        // reads each from wherever its position happens to be standing. A fix
        // landing in that moment — between the drawing thread setting the
        // position to nought and the driver reading it — left the position in
        // the middle of the flight, and the flight, its shadow or the curtain
        // was drawn from the middle of itself: a line to nowhere, for a frame,
        // for no reason anybody could see. Writing at an index leaves the
        // position alone, so the drawing thread is the only one that moves it.
        var at = trackCount * 3
        air.put(at, x); air.put(at + 1, y); air.put(at + 2, z)
        ground.put(at, x); ground.put(at + 1, groundY); ground.put(at + 2, z)

        val curtain = dropBuffer
        if (curtain != null && (dropCount + 6) * 3 <= curtain.capacity()) {
            at = dropCount * 3
            curtain.put(at, ax); curtain.put(at + 1, ay); curtain.put(at + 2, az)
            curtain.put(at + 3, sx); curtain.put(at + 4, sy); curtain.put(at + 5, sz)
            curtain.put(at + 6, x); curtain.put(at + 7, y); curtain.put(at + 8, z)
            curtain.put(at + 9, x); curtain.put(at + 10, y); curtain.put(at + 11, z)
            curtain.put(at + 12, sx); curtain.put(at + 13, sy); curtain.put(at + 14, sz)
            curtain.put(at + 15, x); curtain.put(at + 16, groundY); curtain.put(at + 17, z)
            dropCount += 6
            appendedQuads++
        }

        // counts last, so the drawing thread never sees a point that has not
        // been written yet
        trackCount++
        shadowCount++
        headGroundY = groundY
    }

    /**
     * The line home and the line ahead, drawn from where the model is drawn.
     *
     * Both start at the model, so both belong here rather than among the
     * overlays: built there, out of the last fix, they jumped ahead of it and
     * waited for the next one while the model glided between them.
     */
    @Synchronized
    fun setHomeLine(on: Boolean, x: Float, y: Float, z: Float,
                    r: Float, g: Float, b: Float, a: Float) {
        homeOn = on
        homeX = x; homeY = y; homeZ = z
        homeR = r; homeG = g; homeB = b; homeA = a
    }

    /** The operator line, playback only: to where they stood, then. */
    @Synchronized
    fun setOperatorLine(on: Boolean, x: Float, y: Float, z: Float,
                        r: Float, g: Float, b: Float, a: Float) {
        operatorOn = on
        operatorX = x; operatorY = y; operatorZ = z
        operatorR = r; operatorG = g; operatorB = b; operatorA = a
    }

    @Synchronized
    fun setHeadingLine(on: Boolean, r: Float, g: Float, b: Float, a: Float) {
        headingOn = on
        headR = r; headG = g; headB = b; headA = a
    }

    private fun fill(buffer: FloatBuffer, data: FloatArray) {
        buffer.position(0)
        buffer.put(data)
        buffer.position(0)
    }

    @Synchronized
    fun setTrack(track: FloatArray, shadow: FloatArray) {
        // with room for the fixes that arrive before the next rebuild
        trackBuffer = floatsWithRoom(track, SPARE_POINTS * 3)
        trackCount = track.size / 3
        shadowBuffer = floatsWithRoom(shadow, SPARE_POINTS * 3)
        shadowCount = shadow.size / 3

        // A curtain hanging from the flight down to its shadow, rather than a
        // ladder of separate rungs: height reads as a surface where it only
        // ever read as a hint before, and a translucent one does not bury the
        // ground it stands on.
        if (track.size != shadow.size || trackCount <= 1) {
            // Nothing to hang a curtain from. Without this the last one stayed
            // exactly where it was: jumping a replay back to the start empties
            // the flight, and the curtain of the flight that was there before
            // went on hanging in the air over the new one.
            dropBuffer = null
            dropCount = 0
        }
        if (track.size == shadow.size && trackCount > 1) {
            // one quad per point is more than a screen can show; a couple of
            // thousand is plenty for a whole flight
            val step = Math.max(1, trackCount / 2000)
            curtainStep = step
            appendedQuads = 0
            // Straight into the array it is going to live in. Growing a list of
            // boxed floats made fifty thousand objects of a curtain that is
            // rebuilt every time the flight gains a point.
            val quads = (trackCount - 1) / step + 1
            val array = FloatArray(quads * 18)
            var at = 0
            var i = 0
            while (i + step < trackCount && at + 18 <= array.size) {
                val a = i * 3
                val b = (i + step) * 3
                // two triangles: flight to shadow, along one step of the path
                array[at++] = track[a]; array[at++] = track[a + 1]; array[at++] = track[a + 2]
                array[at++] = shadow[a]; array[at++] = shadow[a + 1]; array[at++] = shadow[a + 2]
                array[at++] = track[b]; array[at++] = track[b + 1]; array[at++] = track[b + 2]

                array[at++] = track[b]; array[at++] = track[b + 1]; array[at++] = track[b + 2]
                array[at++] = shadow[a]; array[at++] = shadow[a + 1]; array[at++] = shadow[a + 2]
                array[at++] = shadow[b]; array[at++] = shadow[b + 1]; array[at++] = shadow[b + 2]
                i += step
            }
            // and close it to the final point: the loop stops a step short of
            // the end, which on a long flight is a stretch of missing curtain
            // exactly where the model is
            if (i < trackCount - 1 && at + 18 <= array.size) {
                val a = i * 3
                val b = (trackCount - 1) * 3
                array[at++] = track[a]; array[at++] = track[a + 1]; array[at++] = track[a + 2]
                array[at++] = shadow[a]; array[at++] = shadow[a + 1]; array[at++] = shadow[a + 2]
                array[at++] = track[b]; array[at++] = track[b + 1]; array[at++] = track[b + 2]

                array[at++] = track[b]; array[at++] = track[b + 1]; array[at++] = track[b + 2]
                array[at++] = shadow[a]; array[at++] = shadow[a + 1]; array[at++] = shadow[a + 2]
                array[at++] = shadow[b]; array[at++] = shadow[b + 1]; array[at++] = shadow[b + 2]
            }
            dropBuffer = floatsWithRoom(array, SPARE_POINTS * 18)
            dropCount = at / 3
        }
    }

    private fun floatsWithRoom(data: FloatArray, spare: Int): FloatBuffer {
        val buffer = ByteBuffer.allocateDirect((data.size + spare) * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        buffer.put(data)
        buffer.position(0)
        return buffer
    }

    private fun floats(data: FloatArray): FloatBuffer {
        val buffer = ByteBuffer.allocateDirect(data.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        buffer.put(data).position(0)
        return buffer
    }

    private fun shorts(data: ShortArray): ShortBuffer {
        val buffer = ByteBuffer.allocateDirect(data.size * 2)
            .order(ByteOrder.nativeOrder()).asShortBuffer()
        buffer.put(data).position(0)
        return buffer
    }

    // ------------------------------------------------------------ renderer

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.09f, 0.11f, 0.14f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        // The context usually survives the surface: preserveEGLContextOnPause
        // keeps it across a screen-off or a fullscreen toggle, and everything
        // uploaded is still on the card. Wiping unconditionally here threw a
        // living world away and rebuilt it for fifteen seconds on every
        // unlock. Only a context whose old names have actually died gets the
        // rebuild.
        if (terrainProgram != 0 && GLES20.glIsProgram(terrainProgram)) {
            juricabi.com.telemetry.utils.DebugLog.note("TerrainRenderer",
                "surface recreated, context survived")
            return
        }
        juricabi.com.telemetry.utils.DebugLog.note("TerrainRenderer",
            "world rebuilt: fresh GL context")
        terrainProgram = program(TERRAIN_VERTEX, TERRAIN_FRAGMENT)
        // At a virgin region there is no ancestor picture to borrow, and a
        // tile drawn with texture 0 samples an incomplete texture: black
        // ground over a black void, seconds of a world that was standing
        // there invisibly. Bare ground wears the mosaics' own haze grey
        // instead, and the vertex shade carves the relief into it — the
        // mountains' shape shows the moment the first mesh stands.
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        bareTex = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bareTex)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,
            GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,
            GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST)
        val haze = ByteBuffer.allocateDirect(3).put(
            byteArrayOf(128.toByte(), 128.toByte(), 128.toByte()))
        haze.position(0)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGB, 1, 1, 0,
            GLES20.GL_RGB, GLES20.GL_UNSIGNED_BYTE, haze)
        // even lines where the driver can measure a pixel, plain ones where
        // it cannot; the extension is old and common, but not promised
        modelProgram = program(MODEL_VERTEX, MODEL_FRAGMENT_EVEN)
        if (modelProgram == 0) modelProgram = program(MODEL_VERTEX, MODEL_FRAGMENT)
        lineProgram = program(LINE_VERTEX, LINE_FRAGMENT)
        // A new context arrives with nothing in it: what was uploaded is
        // gone, and nothing on this side remembers it. The pager rebuilds
        // the world from its caches, the way it built it the first time.
        synchronized(this) {
            tiles.clear()
            tilesDirty = true
            pending.clear()
            for (m in pendingPictures) {
                m.texture?.let { if (!it.isRecycled) it.recycle() }
            }
            pendingPictures.clear()
            // and the mesh queue's pictures: a dressed rebuild waiting here
            // owns its bitmap the same way
            for (m in pending) {
                m.texture?.let { if (!it.isRecycled) it.recycle() }
            }
            pending.clear()
            drawSet = null
            drawSetWanted = null
            quadMasks = HashMap()
            drawSetWantedMasks = HashMap()
            retiring.clear()
        }
        onPicturesLost?.invoke()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = Math.max(1, width)
        surfaceHeight = Math.max(1, height)
        viewHeightPx = surfaceHeight
        viewWidthPx = surfaceWidth
        GLES20.glViewport(0, 0, surfaceWidth, surfaceHeight)
        // the projection is rebuilt per frame instead, from how far out we are
    }

    override fun onDrawFrame(gl: GL10?) {
        noteFrame()
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        uploadPending()

        // Depth resolution is spent between the near and far planes, so a near
        // plane fixed at a few metres with the far one kilometres away left
        // almost none of it for the ground — which is why the arrow flickered
        // against the terrain from far out. Both now follow the camera.
        val ratio = surfaceWidth.toFloat() / surfaceHeight
        val near = Math.max(1f, distance / 200f)
        val far = Math.max(4000f, distance * 8f)
        Matrix.perspectiveM(projection, 0, FOV_Y, ratio, near, far)

        settle()

        if (chasingModel) {
            azimuthWanted = ((-shownHeading + chaseYaw) % 360f + 360f) % 360f
        }

        val wanted = azimuthWanted
        if (!wanted.isNaN()) {
            azimuth = juricabi.com.telemetry.utils.GeoUtils.turnTowards(azimuth, wanted, 0.15f)
        }

        val az = Math.toRadians(azimuth.toDouble())
        val el = Math.toRadians(elevation.toDouble().coerceIn(3.0, 87.0))
        // The camera works in the same space the ground is drawn in, so the
        // live in that same stretched space. Placing it in unstretched metres
        // put it below hills it was supposed to clear — which is why it could
        // still end up inside them.
        // Eased, like the lift under the eye below, and for a stronger
        // reason: the ground under a point is not known until the tile holding
        // it is in memory, so during a load every tile that lands turns a "no
        // idea" into a height. Applied outright, the point the camera is
        // looking at jumped to each of them in a single frame — which is the
        // view lurching about over bare grey mesh while a log decodes.
        val targetFloorRaw = groundUnderCamera?.invoke(shownTarget[0], shownTarget[2])
        val wantTargetLift = if (targetFloorRaw == null) {
            0f
        } else {
            Math.max(0f, targetFloorRaw + 5f - shownTarget[1])
        }
        targetLift = if (liftsSnap) {
            wantTargetLift
        } else {
            targetLift + (wantTargetLift - targetLift) * 0.15f
        }
        val targetY = shownTarget[1] + targetLift

        val eyeX = shownTarget[0] + (distance * Math.cos(el) * Math.sin(az)).toFloat()
        var eyeY = targetY + (distance * Math.sin(el)).toFloat()
        val eyeZ = shownTarget[2] + (distance * Math.cos(el) * Math.cos(az)).toFloat()
        // never under the ground: it is opaque from below and the view becomes
        // a meaningless slab
        // Eased, not snapped. Riding behind the model puts the camera low,
        // where swinging it round the model runs it over ground of changing
        // height — and a lift applied the moment it is needed and dropped the
        // moment it is not is a camera that jumps every frame.
        val floorY = groundUnderCamera?.invoke(eyeX, eyeZ)
        val wantLift = if (floorY == null) 0f else {
            Math.max(0f, floorY + 40f - eyeY)
        }
        // and the same, so that arriving at a model does not then climb
        // slowly out of the hill it is standing behind
        floorLift = if (liftsSnap) wantLift else floorLift + (wantLift - floorLift) * 0.15f
        liftsSnap = false
        eyeY += floorLift
        // where the camera actually stood this frame, and which way it
        // faced, for the pager's distance-to-tile arithmetic
        this.eyeX = eyeX
        this.eyeY = eyeY
        this.eyeZ = eyeZ
        run {
            val dx = shownTarget[0] - eyeX
            val dy = targetY - eyeY
            val dz = shownTarget[2] - eyeZ
            val len = Math.sqrt((dx * dx + dy * dy + dz * dz).toDouble()).toFloat()
            if (len > 1f) {
                viewDirX = dx / len
                viewDirY = dy / len
                viewDirZ = dz / len
            }
        }
        Matrix.setLookAtM(view, 0, eyeX, eyeY, eyeZ,
            shownTarget[0], targetY, shownTarget[2], 0f, 1f, 0f)

        Matrix.multiplyMM(mvp, 0, projection, 0, view, 0)
        // this frame's projection, for the screen to pick against on a tap
        synchronized(this) { System.arraycopy(mvp, 0, pickMvp, 0, 16) }

        // The flight before the model, so the model is never painted over.
        //
        // Its curtain reaches all the way to where the model is drawn, which
        // means it passes through it; drawn afterwards, wherever that surface
        // was nearer to the eye than the model it covered it. Lines that really
        // are in front of the model still show, since they leave their depth
        // behind them and the model is drawn against it — only the curtain,
        // which deliberately leaves no depth, gives way.
        drawTerrain()
        drawLines()
        drawTraffic()
        drawModelLit()
        drawMyArrow()
    }

    /** The frame last drawn, so a tap on the screen can be asked in world terms. */
    private val pickMvp = FloatArray(16)
    private val pickVec = FloatArray(8)

    /**
     * A world point onto the screen, in pixels, against the frame last drawn.
     * False when the point is behind the camera and has no place on screen.
     */
    fun projectToScreen(x: Float, y: Float, z: Float, out: FloatArray): Boolean {
        synchronized(this) {
            pickVec[0] = x; pickVec[1] = y; pickVec[2] = z; pickVec[3] = 1f
            Matrix.multiplyMV(pickVec, 4, pickMvp, 0, pickVec, 0)
            val w = pickVec[7]
            if (w <= 0f) return false
            out[0] = (pickVec[4] / w * 0.5f + 0.5f) * viewWidthPx
            out[1] = (0.5f - pickVec[5] / w * 0.5f) * viewHeightPx
        }
        return true
    }

    /**
     * Upload what is new and throw away what has gone.
     *
     * Extending the ground hands back the tiles already on screen along with
     * the new one. Uploading the lot meant deleting and re-sending nine 8MB
     * textures in a single frame, which is a freeze of the better part of a
     * second — and it happened every time the flight neared the edge of what
     * was loaded.
     */
    private fun uploadPending() {
        val meshes: List<TerrainScene.TileMesh>
        val pictures: List<TerrainScene.TileMesh>
        synchronized(this) {
            // a change of mind about what to keep is reason enough to run,
            // even with nothing new to put up — and so is a draw set waiting
            // for the queue to drain
            if (pending.isEmpty() && pendingPictures.isEmpty() &&
                pendingStrips.isEmpty() && !keepChanged && drawSetWanted == null) {
                return
            }
            keepChanged = false
            pruneLocked()
            if (pendingStrips.isNotEmpty()) {
                val deferred = ArrayList<Long>()
                for (key in pendingStrips) {
                    // not what is drawn: the pager decided over a cover that
                    // may have moved on by the time this runs
                    if (drawSet?.contains(key) == true) continue
                    // and not mid-goodbye: a retiring tile stripped during
                    // its dissolve painted the flat base colour across the
                    // sky for the rest of its fade
                    if (retiring.containsKey(key)) {
                        deferred.add(key)
                        continue
                    }
                    val t = tiles[key] ?: continue
                    if (t.textureId != 0) {
                        GLES20.glDeleteTextures(1, intArrayOf(t.textureId), 0)
                    }
                    if (t.prevTextureId != 0) {
                        GLES20.glDeleteTextures(1, intArrayOf(t.prevTextureId), 0)
                    }
                    t.textureId = 0
                    t.prevTextureId = 0
                    t.swappedAt = 0
                }
                pendingStrips.clear()
                pendingStrips.addAll(deferred)
            }
            // A few at a time. A restored context queues every tile at once,
            // and sending them all in one frame is a visible freeze.
            val take = Math.min(pending.size, UPLOADS_PER_FRAME)
            meshes = ArrayList(pending.subList(0, take))
            pending.subList(0, take).clear()
            // One: a big picture with its mipmaps is most of a frame on its
            // own, and two of them in one frame is a stutter the eye catches
            // in a moving replay.
            val takePictures = Math.min(pendingPictures.size, 1)
            pictures = ArrayList(pendingPictures.subList(0, takePictures))
            pendingPictures.subList(0, takePictures).clear()
        }
        // Pictures are the heavy part of an upload — eight megabytes is tens
        // of milliseconds on this thread — so they go up a couple per frame
        // from their own queue, and never hold the mesh queue or the draw
        // set behind them.
        for (mesh in pictures) {
            val here = synchronized(this) { tiles[mesh.key] }
            if (here == null) {
                // its tile left between queueing and now; the picture is
                // ours to let go, or it lingers on the heap unowned
                mesh.texture?.let { if (!it.isRecycled) it.recycle() }
                continue
            }
            val bitmap = mesh.texture
            if (bitmap != null && !bitmap.isRecycled) {
                // A sharper picture replaces the one the tile wears — behind
                // a short dissolve, so a whole screen sharpening at once
                // reads as coming into focus, not as tiles popping. The old
                // picture is kept until the fade is done; an older fade
                // still unfinished yields its keepsake first.
                if (here.prevTextureId != 0) {
                    GLES20.glDeleteTextures(1, intArrayOf(here.prevTextureId), 0)
                }
                here.prevTextureId = here.textureId
                here.swappedAt = android.os.SystemClock.elapsedRealtime()
                here.textureId = uploadTexture(bitmap)
                var fades = 0
                var oldest: Tile? = null
                synchronized(this) {
                    for (t in tiles.values) {
                        if (t.prevTextureId == 0) continue
                        fades++
                        if (oldest == null || t.swappedAt < oldest!!.swappedAt) oldest = t
                    }
                }
                if (fades > MAX_FADES) {
                    oldest?.let {
                        GLES20.glDeleteTextures(1, intArrayOf(it.prevTextureId), 0)
                        it.prevTextureId = 0
                        it.swappedAt = 0L
                    }
                }
            }
        }
        for (mesh in meshes) {
            // The shape of this tile is already up: only its picture is new,
            // and the picture queue is what paces those.
            val here = synchronized(this) { tiles[mesh.key] }
            var inherited = 0
            if (here != null) {
                if (mesh.texture != null) {
                    synchronized(this) { pendingPictures.add(mesh) }
                    continue
                }
                // A bare mesh for a standing key is a REBUILT shape — a rim
                // mended, a datum moved — not a duplicate. Dropped here, the
                // corrected geometry never reached the card: the wall stayed
                // mended only in the pager's books, and a late datum left
                // the whole ground on the old one while the flight floated.
                GLES20.glDeleteBuffers(2,
                    intArrayOf(here.vertexBuffer, here.indexBuffer), 0)
                // The picture, though, is the same ground over the same
                // extent whatever the mesh under it looks like now. A mend
                // that threw it away faded the tile sharp-to-soft and made
                // it climb the whole ladder back up on every rim repair.
                inherited = here.textureId
                if (here.prevTextureId != 0) {
                    GLES20.glDeleteTextures(1, intArrayOf(here.prevTextureId), 0)
                }
                synchronized(this) {
                    tiles.remove(mesh.key)
                    tilesDirty = true
                }
            }
            val bitmap = mesh.texture
            val texture = if (bitmap != null && !bitmap.isRecycled) {
                uploadTexture(bitmap)
            } else {
                inherited
            }
            val vertexArray = mesh.vertices
            val indexArray = mesh.indices
            if (vertexArray == null || indexArray == null) {
                // a dressed copy has no geometry; its tile left between
                // queueing and now, so there is nothing to stand it on
                mesh.texture?.let { if (!it.isRecycled) it.recycle() }
                continue
            }
            val ids = IntArray(2)
            GLES20.glGenBuffers(2, ids, 0)
            val vertices = floats(vertexArray)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, vertexArray.size * 4, vertices,
                GLES20.GL_STATIC_DRAW)
            val indices = shorts(indexArray)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ids[1])
            GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, indexArray.size * 2, indices,
                GLES20.GL_STATIC_DRAW)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
            synchronized(this) {
                tiles[mesh.key] = Tile(mesh.key, ids[0], ids[1], indexArray.size,
                    mesh.quadCount, texture,
                    mesh.minX, mesh.maxX, mesh.minY, mesh.maxY, mesh.minZ, mesh.maxZ)
                // An offer is a keep. The keep list is the previous pass's
                // snapshot, so a tile built since then was uploaded here and
                // pruned within the frame — and nothing re-offers it. The
                // next draw set then waited on a key that could never come,
                // and the world applied only when building paused: sharp
                // ground everywhere, shown all at once at the end.
                keep?.add(mesh.key)
                tilesDirty = true
            }
        }
        synchronized(this) {
            // The moment every tile it names is on the card — not when the
            // whole queue drains. Waiting for the queue meant a busy stream
            // of new tiles held the draw list stale for seconds, while
            // deletions applied instantly: every eviction was a hole until
            // the queue happened to empty.
            val wanted = drawSetWanted
            if (wanted != null && wanted.all { tiles.containsKey(it) }) {
                // whoever leaves the list with a picture on gets a moment to
                // dissolve over their replacement instead of cutting out
                val old = drawSet
                if (old != null) {
                    val now = android.os.SystemClock.elapsedRealtime()
                    for (key in old) {
                        if (wanted.contains(key)) continue
                        val t = tiles[key] ?: continue
                        if (t.textureId != 0) retiring[key] = now
                    }
                }
                for (key in wanted) retiring.remove(key)
                drawSet = wanted
                drawSetWanted = null
                quadMasks = drawSetWantedMasks
                morphK = morphKWanted
                // what the old list was still showing can go now
                pruneLocked()
            }
        }
    }

    /**
     * Throw away what is neither wanted nor still on screen. Caller holds
     * the monitor. A tile the applied draw list names must outlive the
     * eviction that retired it, or the frames between eviction and the next
     * list swap flash black where it stood.
     */
    private fun pruneLocked() {
        val wanted = keep ?: return
        val drawnNow = drawSet
        // A handful per frame, under the monitor everything else queues on:
        // a whole zoom-out's worth of retirements deleted in one loop was a
        // stall every touch event could end up waiting behind. It is called
        // every frame; the queue drains in a blink either way.
        var deletes = 16
        var removed = false
        val now = android.os.SystemClock.elapsedRealtime()
        val gone = tiles.entries.iterator()
        while (gone.hasNext() && deletes > 0) {
            val t = gone.next().value
            if (wanted.contains(t.key)) continue
            if (drawnNow != null && drawnNow.contains(t.key)) continue
            // not while it is still dissolving out, or the goodbye is a cut
            val began = retiring[t.key]
            if (began != null && now - began < FADE_MS) continue
            retiring.remove(t.key)
            if (t.textureId != 0) GLES20.glDeleteTextures(1, intArrayOf(t.textureId), 0)
            if (t.prevTextureId != 0) GLES20.glDeleteTextures(1, intArrayOf(t.prevTextureId), 0)
            GLES20.glDeleteBuffers(2, intArrayOf(t.vertexBuffer, t.indexBuffer), 0)
            gone.remove()
            removed = true
            deletes--
        }
        // dirty only when something actually left, or this per-frame call
        // quietly cancelled the snapshot reuse it sits beside
        if (removed) tilesDirty = true
    }

    /**
     * The view is over: everything queued is let go of, so it can be
     * collected the moment the worker threads finish, instead of a dead
     * renderer holding a loading burst's worth of meshes and pictures for
     * as long as the slowest fetch takes to time out. References only — no
     * recycle here, since the dying GL thread may hold some of these in a
     * local list mid-upload; unreachable bitmaps free themselves.
     */
    @Synchronized
    fun shutdown() {
        pending.clear()
        pendingPictures.clear()
        tiles.clear()
        tilesSnapshot = HashMap()
        tilesDirty = true
        drawSet = null
        drawSetWanted = null
        quadMasks = HashMap()
        drawSetWantedMasks = HashMap()
        retiring.clear()
    }

    /** The map drawTerrain reads; rebuilt only when the tile set changes. */
    private var tilesSnapshot = HashMap<Long, Tile>()
    private var tilesDirty = true

    private var frameLastNs = 0L
    private var frameCount = 0
    private var frameSlow = 0
    private var frameWorstMs = 0f
    private var frameLogNs = 0L

    private fun noteFrame() {
        val now = System.nanoTime()
        if (frameLastNs != 0L) {
            val ms = (now - frameLastNs) / 1e6f
            // a gap of a second is the surface pausing, not a frame drawn
            // slowly; counting it made every view switch a false alarm
            if (ms > 1000f) {
                frameLastNs = now
                return
            }
            frameCount++
            if (ms > 25f) frameSlow++
            if (ms > frameWorstMs) frameWorstMs = ms
            if (now - frameLogNs > 5_000_000_000L) {
                juricabi.com.telemetry.utils.DebugLog.note("TerrainFrames",
                    "frames=$frameCount slow=$frameSlow worst=${frameWorstMs.toInt()}ms")
                frameLogNs = now
                frameCount = 0
                frameSlow = 0
                frameWorstMs = 0f
            }
        }
        frameLastNs = now
    }

    /** The six clip planes, four numbers each, pulled from the mvp per frame. */
    private val frustum = FloatArray(24)

    /** Gribb-Hartmann, unnormalised: a which-side test needs no unit lengths. */
    private fun extractFrustum() {
        val m = mvp
        for (p in 0 until 6) {
            val row = p / 2
            val sign = if (p % 2 == 0) 1f else -1f
            for (j in 0 until 4) {
                frustum[p * 4 + j] = m[j * 4 + 3] + sign * m[j * 4 + row]
            }
        }
    }

    /**
     * Whether any of the tile's box is inside the frustum: for each plane,
     * test the box corner farthest along the plane's normal — if even that
     * corner is behind the plane, the whole box is.
     */
    private fun boxVisible(t: Tile): Boolean {
        for (p in 0 until 6) {
            val a = frustum[p * 4]
            val b = frustum[p * 4 + 1]
            val c = frustum[p * 4 + 2]
            val d = frustum[p * 4 + 3]
            val x = if (a >= 0) t.maxX else t.minX
            val y = if (b >= 0) t.maxY else t.minY
            val z = if (c >= 0) t.maxZ else t.minZ
            if (a * x + b * y + c * z + d < 0) return false
        }
        return true
    }

    private fun uploadTexture(bitmap: android.graphics.Bitmap): Int {
        val startedNs = System.nanoTime()
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        // Zoomed out, a 2048px texture lands on a few hundred pixels of screen,
        // and without a chain of smaller copies every one of them reads a
        // different corner of it: slow, and it shimmers.
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER,
            GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER,
            GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S,
            GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T,
            GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0)
        // The picture now lives on the card, and the heap copy was held only
        // against a lost context — half the ground's memory, kept for a rare
        // event. Let it go; a lost context asks the disk cache instead.
        val side = bitmap.width
        bitmap.recycle()
        // name the cost when it eats frames, so tuning has a number to aim at
        val ms = (System.nanoTime() - startedNs) / 1_000_000
        if (ms > 20) {
            juricabi.com.telemetry.utils.DebugLog.note("TerrainFrames", "picture ${side}px took ${ms}ms")
        }
        return ids[0]
    }

    private fun drawTerrain() {
        if (terrainProgram == 0) return
        GLES20.glUseProgram(terrainProgram)
        val aPosition = GLES20.glGetAttribLocation(terrainProgram, "aPosition")
        val aTexture = GLES20.glGetAttribLocation(terrainProgram, "aTexture")
        val aShades = GLES20.glGetAttribLocation(terrainProgram, "aShades")
        val aEdge = GLES20.glGetAttribLocation(terrainProgram, "aEdge")
        val uMvp = GLES20.glGetUniformLocation(terrainProgram, "uMvp")
        val uHasTexture = GLES20.glGetUniformLocation(terrainProgram, "uHasTexture")
        val uBase = GLES20.glGetUniformLocation(terrainProgram, "uBase")
        val uUvScale = GLES20.glGetUniformLocation(terrainProgram, "uUvScale")
        val uUvOff = GLES20.glGetUniformLocation(terrainProgram, "uUvOff")
        val aParentY = GLES20.glGetAttribLocation(terrainProgram, "aParentY")
        val aGrandY = GLES20.glGetAttribLocation(terrainProgram, "aGrandY")
        val uEye = GLES20.glGetUniformLocation(terrainProgram, "uEye")
        val uMorph = GLES20.glGetUniformLocation(terrainProgram, "uMorph")
        val uAlpha = GLES20.glGetUniformLocation(terrainProgram, "uAlpha")
        // an array uniform is "uForce[0]" to some drivers and "uForce" to
        // others; ask both ways, or the stitch silently never engages
        var uForce = GLES20.glGetUniformLocation(terrainProgram, "uForce")
        if (uForce < 0) uForce = GLES20.glGetUniformLocation(terrainProgram, "uForce[0]")
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        // the ground's own colour, for a tile whose imagery has not arrived
        GLES20.glUniform3f(uBase, 0.45f, 0.44f, 0.40f)
        GLES20.glUniform3f(uEye, eyeX, eyeY, eyeZ)
        // solid until the dissolve passes at the end say otherwise
        GLES20.glUniform1f(uAlpha, 1f)

        // The proper answer to two surfaces at the same depth: push the ground
        // back by a hair, in depth only, so anything lying on it wins without
        // being moved off it. The bias is worked out per fragment from the
        // slope and the depth resolution to hand, which is why it holds at
        // every zoom where a fixed lift could not — and nothing floats.
        GLES20.glEnable(GLES20.GL_POLYGON_OFFSET_FILL)
        GLES20.glPolygonOffset(2.5f, 8f)

        // Copied only when the tile set actually changed: a fresh 400-entry
        // map every frame was steady garbage for the collector to sweep,
        // paid on the one thread that cannot pause for it.
        val snapshot: HashMap<Long, Tile>
        val drawn: HashSet<Long>?
        val masks: HashMap<Long, Int>
        val kApplied: Double
        val now = android.os.SystemClock.elapsedRealtime()
        val fadeOut = ArrayList<Pair<Tile, Long>>()
        synchronized(this) {
            if (tilesDirty) {
                tilesSnapshot = HashMap(tiles)
                tilesDirty = false
            }
            snapshot = tilesSnapshot
            drawn = drawSet
            masks = quadMasks
            kApplied = morphK
            // who is still dissolving out this frame; a finished goodbye
            // frees its entry, and pruneLocked may then take the tile
            if (retiring.isNotEmpty()) {
                val leaving = retiring.entries.iterator()
                while (leaving.hasNext()) {
                    val e = leaving.next()
                    val t = tiles[e.key]
                    if (t == null || t.textureId == 0 || now - e.value >= FADE_MS) {
                        leaving.remove()
                        continue
                    }
                    fadeOut.add(Pair(t, e.value))
                }
            }
        }
        // pixels per radian — the k the standing cut was selected with when
        // one has been applied, the surface's own only before the first cut
        val k = if (kApplied > 0.0) kApplied
            else viewHeightPx / (2.0 * Math.tan(Math.toRadians(FOV_Y / 2.0)))
        // The selection is deliberately all-round so turning the camera does
        // not churn tiles; the frustum is applied here instead, per frame,
        // which typically halves what is actually sent to the driver.
        extractFrustum()
        val stride = FLOATS_PER_VERTEX * 4

        // Which edges of this tile face a coarser tile the standing draw
        // list actually shows: 0 none, 1 the parent's level, 2 the
        // grandparent's. One scratch array — this runs per tile per frame,
        // and a fresh allocation each time is steady work for the collector
        // on the one thread that cannot pause for it.
        val force = FloatArray(5)
        fun fillForce(tile: Tile) {
            force[1] = 0f; force[2] = 0f; force[3] = 0f; force[4] = 0f
            val set = drawn ?: return
            val z = TerrainScene.zoomOf(tile.key)
            val x = TerrainScene.tileXOf(tile.key)
            val y = TerrainScene.tileYOf(tile.key)
            val side = 1 shl z
            for (e in 0..3) {
                val nx = x + when (e) { 0 -> -1; 2 -> 1; else -> 0 }
                val ny = y + when (e) { 1 -> -1; 3 -> 1; else -> 0 }
                if (nx < 0 || ny < 0 || nx >= side || ny >= side) continue
                val n = TerrainScene.tileKey(z, nx, ny)
                if (set.contains(n)) continue
                // However far up the drawn cover stands: a vertex only
                // carries the parent's and the grandparent's lines, so past
                // two levels the edge still lands on the grandparent's — a
                // step the size the data allows instead of the full cliff
                // that a still-loading region put beside fresh detail.
                var at = n
                var depth = 0
                while (depth < 8 && TerrainScene.zoomOf(at) > 0) {
                    at = TerrainScene.parentOf(at)
                    depth++
                    if (set.contains(at)) {
                        // A masked ancestor only counts if it actually draws
                        // the quarter this neighbour lies in. Partial cover
                        // put parents in the list whose near quarters belong
                        // to their children — the ground beside this edge
                        // was fine, and forcing onto the coarse line built a
                        // wall where none stood: the cliff chains
                        // photographed across the valley. A covered quarter
                        // means the drawn ground there is finer than any
                        // ancestor this walk passed, and the finer side
                        // conforms to us, not us to it.
                        val m = masks[at] ?: 0
                        if (m != 0) {
                            val shift = z - TerrainScene.zoomOf(at) - 1
                            val bit = (((ny ushr shift) and 1) * 2) +
                                ((nx ushr shift) and 1)
                            if (m and (1 shl bit) != 0) break
                        }
                        force[e + 1] = if (depth >= 2) 2f else 1f
                        break
                    }
                }
            }
        }

        // A skirt belongs only on an edge that faces a COARSER drawn
        // neighbour — the one place a crack the morph could not close can
        // open. On an edge meeting an equal or finer neighbour the fine side
        // has already risen to this tile's line, so the curtain hides
        // nothing; and a coarse tile's tall dark skirt over the refined
        // ground below it then stood as a wall that hung there the whole
        // load. force[] is the same coarser-neighbour test the morph reads,
        // filled by fillForce for the tile about to be drawn. The four skirt
        // runs walk the rim north, east, south, west; force is indexed
        // west 1, north 2, east 3, south 4.
        fun drawSkirts(tile: Tile) {
            val skirtStart = 4 * tile.quadCount
            val total = tile.count - skirtStart
            if (total <= 0) return
            val edge = total / 4
            for (s in 0 until 4) {
                val f = when (s) { 0 -> force[2]; 1 -> force[3]; 2 -> force[4]; else -> force[1] }
                if (f <= 0f) continue
                GLES20.glDrawElements(GLES20.GL_TRIANGLES, edge,
                    GLES20.GL_UNSIGNED_SHORT, (skirtStart + s * edge) * 2)
            }
        }

        // One tile, bound and drawn; the caller has chosen its picture and
        // its alpha. Everything per-tile lives here so the dissolve passes
        // below draw exactly what the opaque pass draws — above all the
        // morph band, or a fading generation would swim off its geometry.
        fun drawOne(tile: Tile, texId: Int, scale: Float, offU: Float, offV: Float,
                    mask: Int = 0, skirts: Boolean = true) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, tile.vertexBuffer)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, tile.indexBuffer)
            GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, stride, 0)
            GLES20.glEnableVertexAttribArray(aPosition)
            GLES20.glVertexAttribPointer(aTexture, 2, GLES20.GL_FLOAT, false, stride, 3 * 4)
            GLES20.glEnableVertexAttribArray(aTexture)
            GLES20.glVertexAttribPointer(aShades, 2, GLES20.GL_FLOAT, false, stride, 5 * 4)
            GLES20.glEnableVertexAttribArray(aShades)
            GLES20.glVertexAttribPointer(aParentY, 1, GLES20.GL_FLOAT, false, stride, 7 * 4)
            GLES20.glEnableVertexAttribArray(aParentY)
            GLES20.glVertexAttribPointer(aGrandY, 1, GLES20.GL_FLOAT, false, stride, 8 * 4)
            GLES20.glEnableVertexAttribArray(aGrandY)
            GLES20.glVertexAttribPointer(aEdge, 1, GLES20.GL_FLOAT, false, stride, 9 * 4)
            GLES20.glEnableVertexAttribArray(aEdge)
            fillForce(tile)
            GLES20.glUniform1fv(uForce, 5, force, 0)

            // The band where this level lives, from the same error model the
            // pager splits by: a level-z tile stands between D and 2D from
            // the eye, where D is the distance its error reaches the split
            // threshold. Vertices start sliding onto the parent's line at
            // 1.4D and lie on it by 1.9D — finished just before the pager
            // could put the parent's level beside them, so the shared edge
            // is the coarser line before there is anything to disagree with.
            val z = TerrainScene.zoomOf(tile.key)
            val d = TerrainScene.errorOf(z) * k / TerrainScene.SPLIT_ERROR_PX
            // Complete AT the merge distance, derived from the same
            // thresholds the pager decides by — not at a rounder number
            // past it. The old band finished at 1.9D while a merged parent
            // could stand beside this tile from 1.6D on: an annulus where
            // every coarse neighbour met a fine tile only part-way onto
            // its line, and the difference stood as the wall. With the
            // band ending where parents begin, a one-level neighbour finds
            // this edge already lying on its line, and the force has
            // nothing left to bridge. Children are born at twice their own
            // split distance, past the band's end, so a fresh quartet
            // still starts exactly on the parent's surface.
            val morphEnd = (d * TerrainScene.SPLIT_ERROR_PX /
                TerrainScene.MERGE_ERROR_PX).toFloat()
            val morphWidth = (0.45 * d).toFloat()
            val morphStart = morphEnd - morphWidth
            GLES20.glUniform2f(uMorph, morphStart,
                if (morphWidth > 0f) 1f / morphWidth else 0f)

            if (texId != 0) {
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
                GLES20.glUniform1f(uHasTexture, 1f)
                GLES20.glUniform1f(uUvScale, scale)
                GLES20.glUniform2f(uUvOff, offU, offV)
            } else {
                GLES20.glUniform1f(uHasTexture, 0f)
                GLES20.glUniform1f(uUvScale, 1f)
                GLES20.glUniform2f(uUvOff, 0f, 0f)
            }
            if ((mask == 0 && skirts) || tile.quadCount == 0) {
                if (tile.quadCount > 0) {
                    // the four quadrant runs are the surface; the skirts that
                    // follow are drawn only where an edge needs one
                    GLES20.glDrawElements(GLES20.GL_TRIANGLES, 4 * tile.quadCount,
                        GLES20.GL_UNSIGNED_SHORT, 0)
                    if (skirts) drawSkirts(tile)
                } else {
                    GLES20.glDrawElements(GLES20.GL_TRIANGLES, tile.count,
                        GLES20.GL_UNSIGNED_SHORT, 0)
                }
            } else {
                // only the quarters no child covers; the offsets are in
                // bytes, two per short index
                for (q in 0 until 4) {
                    if (mask and (1 shl q) != 0) continue
                    GLES20.glDrawElements(GLES20.GL_TRIANGLES, tile.quadCount,
                        GLES20.GL_UNSIGNED_SHORT, q * tile.quadCount * 2)
                }
                if (skirts) drawSkirts(tile)
            }

            GLES20.glDisableVertexAttribArray(aPosition)
            GLES20.glDisableVertexAttribArray(aTexture)
            GLES20.glDisableVertexAttribArray(aShades)
            GLES20.glDisableVertexAttribArray(aParentY)
            GLES20.glDisableVertexAttribArray(aGrandY)
            GLES20.glDisableVertexAttribArray(aEdge)
        }

        val fadeIn = ArrayList<Tile>()
        for (tile in snapshot.values) {
            // yesterdays age out here, on the GL thread, BEFORE the two
            // visibility tests — a tile that swapped and then left the draw
            // set or the frustum must not hold its old picture until the
            // context is lost
            if (tile.prevTextureId != 0 && now - tile.swappedAt >= FADE_MS) {
                GLES20.glDeleteTextures(1, intArrayOf(tile.prevTextureId), 0)
                tile.prevTextureId = 0
            }
            if (drawn != null && !drawn.contains(tile.key)) continue
            if (!boxVisible(tile)) continue

            // Its own picture, or the nearest ancestor's quarter-of-a-quarter
            // while its own is still on the wire — soft beats grey, and the
            // sharp one lands in place. Freshly swapped, the opaque pass
            // still shows what the eye was already seeing — the picture this
            // one replaced, or the borrow — and the new one dissolves in.
            var texId = tile.textureId
            if (now - tile.swappedAt < FADE_MS) {
                fadeIn.add(tile)
                texId = tile.prevTextureId
            }
            var scale = 1f
            var offU = 0f
            var offV = 0f
            if (texId == 0) {
                var at = tile.key
                while (texId == 0 && TerrainScene.zoomOf(at) > 0) {
                    val x = TerrainScene.tileXOf(at)
                    val y = TerrainScene.tileYOf(at)
                    offU = (offU + (x and 1)) * 0.5f
                    offV = (offV + (y and 1)) * 0.5f
                    scale *= 0.5f
                    at = TerrainScene.parentOf(at)
                    texId = snapshot[at]?.textureId ?: 0
                }
                // no picture anywhere in the ancestry: bare shaded ground
                if (texId == 0) {
                    texId = bareTex
                    scale = 1f; offU = 0f; offV = 0f
                }
            }
            drawOne(tile, texId, scale, offU, offV, masks[tile.key] ?: 0)
        }

        if (fadeIn.isNotEmpty() || fadeOut.isNotEmpty()) {
            // The dissolves redraw meshes whose depth the opaque pass just
            // wrote — bitwise equal for a fade-in, epsilon-coincident for a
            // retiring level — so under GL_LESS every blended fragment
            // simply fails and the fade is a no-op. LEQUAL plus a lighter
            // offset than the ground's 2.5/8 puts them reliably in front of
            // the terrain, still behind the lifted lines and the model.
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            GLES20.glDepthMask(false)
            GLES20.glDepthFunc(GLES20.GL_LEQUAL)
            GLES20.glPolygonOffset(1.0f, 2f)
            // No skirts in a dissolve, and no bare dissolves. The fades
            // redraw the surface so a picture change melts instead of
            // popping — but their skirt curtains, pushed toward the viewer
            // by the blend offset, flashed as walls at every level swap;
            // the ground below has its own skirts. And a fade without a
            // picture painted the flat base colour across the sky — the big
            // olive wedge — saying nothing the terrain underneath was not
            // already saying better.
            for (tile in fadeIn) {
                if (tile.textureId == 0) continue
                GLES20.glUniform1f(uAlpha, (now - tile.swappedAt) / FADE_MS)
                drawOne(tile, tile.textureId, 1f, 0f, 0f, masks[tile.key] ?: 0,
                    skirts = false)
            }
            for ((tile, began) in fadeOut) {
                if (tile.textureId == 0) continue
                if (!boxVisible(tile)) continue
                GLES20.glUniform1f(uAlpha, 1f - (now - began) / FADE_MS)
                drawOne(tile, tile.textureId, 1f, 0f, 0f, masks[tile.key] ?: 0,
                    skirts = false)
            }
            GLES20.glDepthMask(true)
            GLES20.glDepthFunc(GLES20.GL_LESS)
            GLES20.glDisable(GLES20.GL_BLEND)
        }
        // everything after this draws from ordinary buffers, which a bound
        // vertex buffer would silently override
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        GLES20.glDisable(GLES20.GL_POLYGON_OFFSET_FILL)
    }

    /**
     * A whisker above the terrain, no more, and no longer growing with
     * distance.
     *
     * The ground is pushed back in depth while it is drawn, and that is what
     * keeps these clear of it. This is only so a line lying across a slope does
     * not weave in and out of the surface between its vertices. Scaling it with
     * the camera made the ring float metres above the ground it belongs to.
     */
    private fun groundLift(): Float = 0.25f

    private fun drawLines() {
        if (lineProgram == 0) return
        GLES20.glUseProgram(lineProgram)
        val aPosition = GLES20.glGetAttribLocation(lineProgram, "aPosition")
        val uMvp = GLES20.glGetUniformLocation(lineProgram, "uMvp")
        val uColor = GLES20.glGetUniformLocation(lineProgram, "uColor")
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glEnableVertexAttribArray(aPosition)
        // Every line here is given an alpha — the shadow, the curtain, the
        // accuracy ring, and the traffic posts most of all, which are meant to
        // be faint. Without this they all drew solid and the alpha was a lie.
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        val track: FloatBuffer?
        val shadow: FloatBuffer?
        val drops: FloatBuffer?
        val tCount: Int
        val sCount: Int
        val dCount: Int
        synchronized(this) {
            track = trackBuffer; tCount = trackCount
            shadow = shadowBuffer; sCount = shadowCount
            drops = dropBuffer; dCount = dropCount
        }

        // Anything lying on the ground fights with it once the camera is far
        // enough out that a metre is below what the depth buffer can tell
        // apart. The ground is pushed back in depth as it is drawn, which is
        // what keeps these clear of it; this is the whisker on top.
        val lift = groundLift()
        Matrix.setIdentityM(liftMatrix, 0)
        Matrix.translateM(liftMatrix, 0, 0f, lift, 0f)
        Matrix.multiplyMM(liftMvp, 0, mvp, 0, liftMatrix, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, liftMvp, 0)

        // Each of the three drawn up to the point before last, and then on to
        // the model — which is always somewhere along that final stretch, since
        // the flight ends at the newest fix and the model is easing towards it.
        val joined = track != null && shadow != null && modelVisible &&
            tCount >= 2 && sCount == tCount

        // How far along the flight the model has actually got.
        //
        // Live it is always within the last stretch, since one point arrives at
        // a time. A replay hands over a batch at once, so the flight can run
        // several points past where the model is — and drawn to its end, it
        // stands in front of the model instead of behind it. Walking back to
        // the stretch the model is really on holds for both.
        var reached = tCount - 1
        if (joined) {
            while (reached >= 1) {
                val a = (reached - 1) * 3
                val b = reached * 3
                val abx = track!!.get(b) - track.get(a)
                val aby = track.get(b + 1) - track.get(a + 1)
                val abz = track.get(b + 2) - track.get(a + 2)
                val amx = shownX - track.get(a)
                val amy = shownY - track.get(a + 1)
                val amz = shownZ - track.get(a + 2)
                if (abx * amx + aby * amy + abz * amz >= 0f) break
                reached--
            }
            if (reached < 1) reached = 1
        }
        val skipped = if (joined) tCount - reached else 0
        val airCount = if (joined) reached else tCount
        val groundCount = if (joined) reached else sCount
        // How much of the curtain to hold back, counted in quads.
        //
        // The flight is thinned before its curtain is built — one quad every
        // few points on a long flight — while the quads added since that
        // rebuild are one per point. So the points the model has not reached
        // yet are quads at the tail and a fraction of a quad each further
        // back, and taking one quad per point removed several times too much:
        // a gap behind the model that grew with the length of the flight.
        val curtainCount = if (joined && dCount >= 6) {
            val tail = Math.min(skipped, appendedQuads)
            val body = (skipped - tail) / Math.max(1, curtainStep)
            dCount - Math.min(tail + body, dCount / 6) * 6
        } else {
            dCount
        }

        if (joined) {
            val previous = (reached - 1) * 3
            val ax = track!!.get(previous)
            val ay = track.get(previous + 1)
            val az = track.get(previous + 2)
            val sx = shadow!!.get(previous)
            val sy = shadow.get(previous + 1)
            val sz = shadow.get(previous + 2)
            val bx: Float
            val by: Float
            val bz: Float
            val groundY: Float
            synchronized(this) {
                bx = shownX; by = shownY; bz = shownZ; groundY = headGroundY
            }
            headQuad[0] = ax; headQuad[1] = ay; headQuad[2] = az
            headQuad[3] = sx; headQuad[4] = sy; headQuad[5] = sz
            headQuad[6] = bx; headQuad[7] = by; headQuad[8] = bz
            headQuad[9] = bx; headQuad[10] = by; headQuad[11] = bz
            headQuad[12] = sx; headQuad[13] = sy; headQuad[14] = sz
            headQuad[15] = bx; headQuad[16] = groundY; headQuad[17] = bz
            fill(headQuadBuffer, headQuad)
        }

        if (shadow != null && groundCount > 1) {
            // its own width, rather than whatever the last pass left set: the
            // shadow changed thickness as other lines came and went
            GLES20.glLineWidth(2f)
            shadow.position(0)
            GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 12, shadow)
            // the route colour darkened, rather than an anonymous black line
            GLES20.glUniform4f(uColor, trackColor[0] * 0.45f, trackColor[1] * 0.45f,
                trackColor[2] * 0.45f, 0.85f)
            GLES20.glDrawArrays(GLES20.GL_LINE_STRIP, 0, groundCount)
        }
        if (joined) {
            leaderPair[0] = headQuad[3]; leaderPair[1] = headQuad[4]; leaderPair[2] = headQuad[5]
            leaderPair[3] = headQuad[15]; leaderPair[4] = headQuad[16]; leaderPair[5] = headQuad[17]
            fill(leaderPairBuffer, leaderPair)
            GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 12,
                leaderPairBuffer)
            GLES20.glLineWidth(2f)
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, 2)
        }
        if (drops != null && curtainCount > 2 || joined) {
            GLES20.glUniform4f(uColor, trackColor[0], trackColor[1], trackColor[2], 0.18f)
            // translucent, so what is behind it must still be drawn
            // no depth writing: the curtain is see through, so what is behind it
            // has to keep drawing, and it must not hide the flight above it
            GLES20.glDepthMask(false)
            if (drops != null && curtainCount > 2) {
                drops.position(0)
                GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 12, drops)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, curtainCount)
            }
            if (joined) {
                GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 12,
                    headQuadBuffer)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6)
            }
            GLES20.glDepthMask(true)
        }

        // the operator line first, the home line after — the line a person
        // walks to a downed model by paints over the other
        if (modelVisible && operatorOn) {
            synchronized(this) {
                leaderPair[0] = shownX; leaderPair[1] = shownY; leaderPair[2] = shownZ
                leaderPair[3] = operatorX; leaderPair[4] = operatorY; leaderPair[5] = operatorZ
            }
            fill(leaderPairBuffer, leaderPair)
            GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 12,
                leaderPairBuffer)
            GLES20.glUniform4f(uColor, operatorR, operatorG, operatorB, operatorA)
            GLES20.glLineWidth(3f)
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, 2)
        }
        if (modelVisible && homeOn) {
            synchronized(this) {
                leaderPair[0] = shownX; leaderPair[1] = shownY; leaderPair[2] = shownZ
                leaderPair[3] = homeX; leaderPair[4] = homeY; leaderPair[5] = homeZ
            }
            fill(leaderPairBuffer, leaderPair)
            GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 12,
                leaderPairBuffer)
            GLES20.glUniform4f(uColor, homeR, homeG, homeB, homeA)
            GLES20.glLineWidth(3f)
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, 2)
        }
        if (modelVisible && headingOn) {
            synchronized(this) {
                val radians = Math.toRadians(shownHeading.toDouble())
                leaderPair[0] = shownX; leaderPair[1] = shownY; leaderPair[2] = shownZ
                leaderPair[3] = shownX + (1000.0 * Math.sin(radians)).toFloat()
                leaderPair[4] = shownY
                leaderPair[5] = shownZ - (1000.0 * Math.cos(radians)).toFloat()
            }
            fill(leaderPairBuffer, leaderPair)
            GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 12,
                leaderPairBuffer)
            GLES20.glUniform4f(uColor, headR, headG, headB, headA)
            GLES20.glLineWidth(2f)
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, 2)
        }

        // the track and the model are up in the air, so they go back to the
        // plain matrix
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)

        val extras: List<DrawnSet>
        synchronized(this) { extras = overlays }
        for (extra in extras) {
            GLES20.glUniformMatrix4fv(uMvp, 1, false,
                if (extra.set.onGround) liftMvp else mvp, 0)
            extra.buffer.position(0)
            GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 12, extra.buffer)
            GLES20.glUniform4f(uColor, extra.set.red, extra.set.green, extra.set.blue,
                extra.set.alpha)
            GLES20.glLineWidth(extra.set.width)
            GLES20.glDrawArrays(
                if (extra.set.strip) GLES20.GL_LINE_STRIP else GLES20.GL_LINES,
                0, extra.count)
        }
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)

        for (spot in arrayOf(me, logged)) {
            val ring: FloatBuffer?
            val rCount: Int
            synchronized(this) {
                ring = if (spot.visible) spot.ring else null
                rCount = spot.ringCount
            }
            if (ring == null || rCount <= 2) continue
            GLES20.glUniformMatrix4fv(uMvp, 1, false, liftMvp, 0)
            ring.position(0)
            GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 12, ring)

            // Filled as well as drawn round, the way the map fills it. A ring
            // that is only an outline reads as somewhere to go; filled, it
            // reads as how well the place inside it is known, which is what it
            // is for.
            //
            // A fan from the first point on the rim rather than from a centre,
            // because the centre is not in the buffer — and a fan from any
            // corner fills a convex shape, which a circle is. Translucent, and
            // writing no depth: the ground under it and the arrow standing in
            // it both have to keep drawing through it.
            GLES20.glUniform4f(uColor, spot.ink[0], spot.ink[1], spot.ink[2], 0.15f)
            GLES20.glDepthMask(false)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, rCount)
            GLES20.glDepthMask(true)

            GLES20.glUniform4f(uColor, spot.ink[0], spot.ink[1], spot.ink[2], spot.ink[3])
            GLES20.glLineWidth(3f)
            GLES20.glDrawArrays(GLES20.GL_LINE_LOOP, 0, rCount)
            GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        }
        if (track != null && airCount > 1) {
            // As far as the model has got, like its shadow and its curtain: it
            // was the one piece of the flight still drawn to the very end, so
            // it alone ran on in front of the model.
            track.position(0)
            GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 12, track)
            GLES20.glUniform4f(uColor, trackColor[0], trackColor[1], trackColor[2], 1f)
            GLES20.glLineWidth(4f)
            GLES20.glDrawArrays(GLES20.GL_LINE_STRIP, 0, airCount)
        }
        if (joined) {
            // and on to the model, which is the stretch it stops short of
            leaderPair[0] = headQuad[0]; leaderPair[1] = headQuad[1]; leaderPair[2] = headQuad[2]
            leaderPair[3] = headQuad[6]; leaderPair[4] = headQuad[7]; leaderPair[5] = headQuad[8]
            fill(leaderPairBuffer, leaderPair)
            GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 12,
                leaderPairBuffer)
            GLES20.glUniform4f(uColor, trackColor[0], trackColor[1], trackColor[2], 1f)
            GLES20.glLineWidth(4f)
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, 2)
        }
        GLES20.glDisableVertexAttribArray(aPosition)
        // put back what the ground and the model expect to find
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    /** Packed [x, y, z, headingDegrees] per aircraft; swapped whole per update. */
    fun setTraffic(planes: FloatArray) {
        trafficPlanes = planes
    }

    @Volatile private var trafficPlanes = FloatArray(0)
    private var trafficBuffer: FloatBuffer? = null
    private var trafficCount = 0
    private val trafficMatrix = FloatArray(16)
    private val trafficMvp = FloatArray(16)

    /**
     * Real aircraft as small planes in the red the 2D marker wears — orange
     * is the operator's colour — at their true place and track, always the
     * plane mesh, whatever the flown model is.
     * Sized off each one's own distance, a shade smaller than the model:
     * traffic is context, and the flight stays the subject.
     */
    private fun drawTraffic() {
        val planes = trafficPlanes
        if (planes.isEmpty() || modelProgram == 0) return
        if (trafficBuffer == null) {
            val mesh = ModelMeshes.plane()
            trafficBuffer = floats(mesh)
            trafficCount = mesh.size / MODEL_FLOATS
        }
        val buffer = trafficBuffer ?: return
        if (trafficCount < 3) return

        GLES20.glUseProgram(modelProgram)
        val aPosition = GLES20.glGetAttribLocation(modelProgram, "aPosition")
        val aCorner = GLES20.glGetAttribLocation(modelProgram, "aCorner")
        val aNormal = GLES20.glGetAttribLocation(modelProgram, "aNormal")
        val uMvp = GLES20.glGetUniformLocation(modelProgram, "uMvp")
        val uBase = GLES20.glGetUniformLocation(modelProgram, "uBase")
        GLES20.glUniform1f(GLES20.glGetUniformLocation(modelProgram, "uInk"), 1.3f)

        val stride = MODEL_FLOATS * 4
        buffer.position(0)
        GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, stride, buffer)
        GLES20.glEnableVertexAttribArray(aPosition)
        buffer.position(3)
        GLES20.glVertexAttribPointer(aCorner, 3, GLES20.GL_FLOAT, false, stride, buffer)
        GLES20.glEnableVertexAttribArray(aCorner)
        buffer.position(6)
        GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, stride, buffer)
        GLES20.glEnableVertexAttribArray(aNormal)
        GLES20.glUniform3f(uBase, 1f, 0.125f, 0.125f)

        var i = 0
        while (i + 3 < planes.size) {
            Matrix.setIdentityM(trafficMatrix, 0)
            Matrix.translateM(trafficMatrix, 0, planes[i], planes[i + 1], planes[i + 2])
            Matrix.rotateM(trafficMatrix, 0, -planes[i + 3], 0f, 1f, 0f)
            val dx = planes[i] - eyeX
            val dy = planes[i + 1] - eyeY
            val dz = planes[i + 2] - eyeZ
            val d = Math.sqrt((dx * dx + dy * dy + dz * dz).toDouble()).toFloat()
            val s = Math.max(3f, d * 0.015f)
            Matrix.scaleM(trafficMatrix, 0, s, s, s)
            Matrix.multiplyMM(trafficMvp, 0, mvp, 0, trafficMatrix, 0)
            GLES20.glUniformMatrix4fv(uMvp, 1, false, trafficMvp, 0)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, trafficCount)
            i += 4
        }

        GLES20.glDisableVertexAttribArray(aPosition)
        GLES20.glDisableVertexAttribArray(aCorner)
        GLES20.glDisableVertexAttribArray(aNormal)
    }

    /**
     * Drawn with the lit shader rather than the flat one.
     *
     * One colour with no shading makes any solid read as a silhouette, so arms,
     * motors and a fuselage were shapes nobody could see. Borrowing the program
     * the ground uses gives the model a light, at the cost of carrying normals.
     */
    private fun drawModelLit() {
        val buffer: FloatBuffer?
        // count and buffer together: they are replaced as a pair when the
        // shape changes, and a new count against an old buffer reads off its end
        val count: Int
        synchronized(this) {
            buffer = if (modelVisible) modelBuffer else null
            count = modelCount
        }
        if (buffer == null || count < 3 || modelProgram == 0) return

        GLES20.glUseProgram(modelProgram)
        val aPosition = GLES20.glGetAttribLocation(modelProgram, "aPosition")
        val aCorner = GLES20.glGetAttribLocation(modelProgram, "aCorner")
        val aNormal = GLES20.glGetAttribLocation(modelProgram, "aNormal")
        val uMvp = GLES20.glGetUniformLocation(modelProgram, "uMvp")
        val uBase = GLES20.glGetUniformLocation(modelProgram, "uBase")
        GLES20.glUniform1f(GLES20.glGetUniformLocation(modelProgram, "uInk"), 1.3f)

        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, shownX, shownY, shownZ)
        // yaw, then pitch, then roll — the order an aircraft's attitude is
        // built in, so a banked turn looks like a banked turn
        Matrix.rotateM(modelMatrix, 0, -shownHeading, 0f, 1f, 0f)
        Matrix.rotateM(modelMatrix, 0, shownPitch, 1f, 0f, 0f)
        Matrix.rotateM(modelMatrix, 0, -shownRoll, 0f, 0f, 1f)
        // undo the vertical exaggeration on the dart itself, or it grows a
        // taller fin the more the ground is stretched
        // Held at a size on screen rather than in metres — a model drawn to
        // scale is invisible from anywhere useful — but a good deal smaller
        // than it was, which made a quad look the size of a hangar.
        // the same fraction of its own distance from the eye the position
        // arrows use, so the two read as one family — a constant size on
        // screen, not shrunk when the camera looks at something close by
        val mx = shownX - eyeX
        val my = shownY - eyeY
        val mz = shownZ - eyeZ
        val ownDist = Math.sqrt((mx * mx + my * my + mz * mz).toDouble()).toFloat()
        val drawSize = Math.max(3f, ownDist * 0.02f)
        Matrix.scaleM(modelMatrix, 0, drawSize, drawSize, drawSize)
        Matrix.multiplyMM(modelMvp, 0, mvp, 0, modelMatrix, 0)

        val stride = MODEL_FLOATS * 4
        buffer.position(0)
        GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, stride, buffer)
        GLES20.glEnableVertexAttribArray(aPosition)
        buffer.position(3)
        GLES20.glVertexAttribPointer(aCorner, 3, GLES20.GL_FLOAT, false, stride, buffer)
        GLES20.glEnableVertexAttribArray(aCorner)
        buffer.position(6)
        GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, stride, buffer)
        GLES20.glEnableVertexAttribArray(aNormal)

        GLES20.glUniformMatrix4fv(uMvp, 1, false, modelMvp, 0)
        GLES20.glUniform3f(uBase, modelColor[0], modelColor[1], modelColor[2])
        // The track ends inside the model, so the two share depths where they
        // cross and flickered against each other. Pulling the model a hair
        // forward settles which one wins, every frame.
        GLES20.glEnable(GLES20.GL_POLYGON_OFFSET_FILL)
        GLES20.glPolygonOffset(-2f, -4f)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
        GLES20.glDisable(GLES20.GL_POLYGON_OFFSET_FILL)

        GLES20.glDisableVertexAttribArray(aPosition)
        GLES20.glDisableVertexAttribArray(aCorner)
        GLES20.glDisableVertexAttribArray(aNormal)
    }

    /**
     * The arrow for where you are standing, drawn the way the model is: lit,
     * and with its own edges inked in, so the two read as one family.
     */
    private fun drawMyArrow() {
        drawArrow(logged)
        // and this phone pulled a hair in front of it, the way the model is
        // pulled in front of the track it ends inside.
        //
        // Replaying a flight from the field it was flown at stands the two
        // arrows on the same spot. At equal depth nothing decides between them,
        // so which one survived came down to a metre of GPS error and changed
        // from one replay to the next — and it was as often the place you stood
        // last week as the place you are standing now. A bias rather than a
        // lift: the arrow does not move, so it cannot be seen to float, and the
        // shift is a few of the depth buffer's own steps — far too little to
        // show through the hill in front of it.
        GLES20.glEnable(GLES20.GL_POLYGON_OFFSET_FILL)
        GLES20.glPolygonOffset(-2f, -4f)
        drawArrow(me)
        GLES20.glDisable(GLES20.GL_POLYGON_OFFSET_FILL)
    }

    private fun drawArrow(spot: Spot) {
        var mine: FloatBuffer? = null
        var count = 0
        var pointing = false
        synchronized(this) {
            pointing = spot.pointing
            if (spot.visible) {
                mine = if (pointing) arrowBuffer else puckBuffer
                count = if (pointing) arrowCount else puckCount
            }
        }
        val buffer = mine ?: return
        if (modelProgram == 0) return

        // eased towards the compass rather than snapped to it, so it turns
        // like the needle on the map instead of twitching
        if (pointing) {
            spot.heading = juricabi.com.telemetry.utils.GeoUtils.turnTowards(
                spot.heading, spot.headingTarget, 0.12f)
        }

        // A fraction of the arrow's OWN distance from the eye, so it is the
        // same size on screen wherever it stands — the way the traffic planes
        // are sized. The camera-to-target distance was a stand-in for that,
        // and it holds while the arrow is near what the camera looks at; but
        // the chase camera looks at the model close up while the operator's
        // arrow is off across the field, and sized by that near distance it
        // shrank to a speck. A larger fraction than it reads as, because an
        // arrow exactly to scale is a speck the moment the whole flight is in
        // view, which is when it is most worth seeing.
        val ax = spot.x - eyeX
        val ay = spot.y - eyeY
        val az = spot.z - eyeZ
        val own = Math.sqrt((ax * ax + ay * ay + az * az).toDouble()).toFloat()
        val size = Math.max(2f, own * 0.02f)
        // Clearance in proportion, because the arrow lies flat: zoomed out it
        // is tens of metres across, and a fixed quarter of a metre left its
        // uphill half buried in any slope.
        val lift = groundLift() + size * (if (pointing) 0.3f else 0.08f)
        Matrix.setIdentityM(arrowMatrix, 0)
        Matrix.translateM(arrowMatrix, 0, spot.x, spot.y + lift, spot.z)
        if (pointing) Matrix.rotateM(arrowMatrix, 0, -spot.heading, 0f, 1f, 0f)
        Matrix.scaleM(arrowMatrix, 0, size, size, size)
        Matrix.multiplyMM(arrowMvp, 0, mvp, 0, arrowMatrix, 0)

        GLES20.glUseProgram(modelProgram)
        val aPosition = GLES20.glGetAttribLocation(modelProgram, "aPosition")
        val aCorner = GLES20.glGetAttribLocation(modelProgram, "aCorner")
        val aNormal = GLES20.glGetAttribLocation(modelProgram, "aNormal")
        val stride = MODEL_FLOATS * 4
        buffer.position(0)
        GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, stride, buffer)
        GLES20.glEnableVertexAttribArray(aPosition)
        buffer.position(3)
        GLES20.glVertexAttribPointer(aCorner, 3, GLES20.GL_FLOAT, false, stride, buffer)
        GLES20.glEnableVertexAttribArray(aCorner)
        buffer.position(6)
        GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, stride, buffer)
        GLES20.glEnableVertexAttribArray(aNormal)

        GLES20.glUniformMatrix4fv(
            GLES20.glGetUniformLocation(modelProgram, "uMvp"), 1, false, arrowMvp, 0)
        // A thinner line and a brighter blue. The arrow is drawn much smaller
        // than the model, so an edge of the same weight took up most of it and
        // turned it dark.
        GLES20.glUniform1f(GLES20.glGetUniformLocation(modelProgram, "uInk"), 0.8f)
        // brighter than the marker on the map: satellite imagery is dark
        // greens and browns, and a deeper blue disappeared into it
        GLES20.glUniform3f(
            GLES20.glGetUniformLocation(modelProgram, "uBase"),
            spot.base[0], spot.base[1], spot.base[2])
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)

        GLES20.glDisableVertexAttribArray(aPosition)
        GLES20.glDisableVertexAttribArray(aCorner)
        GLES20.glDisableVertexAttribArray(aNormal)
    }

    private fun program(vertexSource: String, fragmentSource: String): Int {
        val vertex = shader(GLES20.GL_VERTEX_SHADER, vertexSource)
        val fragment = shader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
        if (vertex == 0 || fragment == 0) return 0
        val id = GLES20.glCreateProgram()
        GLES20.glAttachShader(id, vertex)
        GLES20.glAttachShader(id, fragment)
        GLES20.glLinkProgram(id)
        val status = IntArray(1)
        GLES20.glGetProgramiv(id, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            GLES20.glDeleteProgram(id)
            return 0
        }
        return id
    }

    private fun shader(type: Int, source: String): Int {
        val id = GLES20.glCreateShader(type)
        GLES20.glShaderSource(id, source)
        GLES20.glCompileShader(id)
        val status = IntArray(1)
        GLES20.glGetShaderiv(id, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            GLES20.glDeleteShader(id)
            return 0
        }
        return id
    }
}
