package juricabi.com.telemetry.video

import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.SocketTimeoutException
import java.util.concurrent.ArrayBlockingQueue
import juricabi.com.telemetry.utils.DebugLog

/** Which codec the stream's parameter sets betrayed. */
internal enum class RtpCodec(val mime: String) {
    H264(MediaFormat.MIMETYPE_VIDEO_AVC),
    H265(MediaFormat.MIMETYPE_VIDEO_HEVC)
}

/**
 * Reads the codec off an RTP payload before any depacketizing is possible —
 * the framing itself differs by codec, but parameter sets always ride whole
 * in their own packets, and their first bytes cannot be mistaken for each
 * other: an H.264 SPS starts x7 under the 5-bit type, an H.265 VPS or SPS
 * is 0x40/0x42 followed by 0x01. Anything else says nothing yet.
 */
internal fun sniffRtpCodec(packet: ByteArray, length: Int): RtpCodec? {
    val at = rtpPayloadStart(packet, length) ?: return null
    val b0 = packet[at].toInt() and 0xFF
    if (b0 and 0x9F == 0x07) return RtpCodec.H264
    if ((b0 == 0x40 || b0 == 0x42) && at + 1 < length &&
        packet[at + 1].toInt() == 0x01
    ) return RtpCodec.H265
    // parameter sets also ride first inside aggregates — ffmpeg packs
    // SPS+PPS into one STAP-A and VPS+SPS+PPS into one AP — so the first
    // aggregated unit is sniffed where it lies
    if (b0 and 0x1F == 24 && at + 3 < length &&
        packet[at + 3].toInt() and 0x9F == 0x07
    ) return RtpCodec.H264
    if ((b0 shr 1) and 0x3F == 48 && at + 5 < length) {
        val f0 = packet[at + 4].toInt() and 0xFF
        if ((f0 == 0x40 || f0 == 0x42) && packet[at + 5].toInt() == 0x01) {
            return RtpCodec.H265
        }
    }
    return null
}

/**
 * Where the payload begins inside an RTP datagram, or null for anything that
 * is not RTP version 2: past the fixed header, the contributing sources and
 * the extension, if any.
 */
internal fun rtpPayloadStart(packet: ByteArray, length: Int): Int? {
    if (length < 12) return null
    val b0 = packet[0].toInt() and 0xFF
    if (b0 shr 6 != 2) return null
    var at = 12 + (b0 and 0x0F) * 4
    if (b0 and 0x10 != 0) {
        if (at + 4 > length) return null
        val words = ((packet[at + 2].toInt() and 0xFF) shl 8) or
            (packet[at + 3].toInt() and 0xFF)
        at += 4 + words * 4
    }
    return if (at < length) at else null
}

/**
 * Strips the RTP wrapping and hands whole NAL units over: single units as
 * they come, fragments (FU-A / FU) reassembled, aggregates (STAP-A / AP)
 * split apart. A gap in the sequence numbers while a fragment is open
 * abandons it — half a picture fed onward decodes as garbage.
 *
 * One feeder thread; the marker bit and the timestamp are passed through so
 * the caller can group units into access units.
 */
internal class RtpDepacketizer(
    private val codec: RtpCodec,
    private val onNal: (nal: ByteArray, timestamp: Long, marker: Boolean) -> Unit
) {
    private val fragment = ByteArrayOutputStream(64 * 1024)
    private var fragmentOpen = false
    private var lastSeq = -1

    fun feed(packet: ByteArray, length: Int) {
        val at = rtpPayloadStart(packet, length) ?: return
        val seq = ((packet[2].toInt() and 0xFF) shl 8) or (packet[3].toInt() and 0xFF)
        val timestamp = ((packet[4].toLong() and 0xFF) shl 24) or
            ((packet[5].toLong() and 0xFF) shl 16) or
            ((packet[6].toLong() and 0xFF) shl 8) or
            (packet[7].toLong() and 0xFF)
        val marker = packet[1].toInt() and 0x80 != 0
        var end = length
        if (packet[0].toInt() and 0x20 != 0) end -= packet[length - 1].toInt() and 0xFF
        if (end <= at) return
        if (fragmentOpen && lastSeq != -1 && seq != (lastSeq + 1) and 0xFFFF) {
            fragmentOpen = false
        }
        lastSeq = seq
        when (codec) {
            RtpCodec.H264 -> h264(packet, at, end, timestamp, marker)
            RtpCodec.H265 -> h265(packet, at, end, timestamp, marker)
        }
    }

    private fun h264(p: ByteArray, at: Int, end: Int, ts: Long, marker: Boolean) {
        when (val type = p[at].toInt() and 0x1F) {
            in 1..23 -> onNal(p.copyOfRange(at, end), ts, marker)
            24 -> { // STAP-A: [size][NAL]...
                var i = at + 1
                while (i + 2 <= end) {
                    val size = ((p[i].toInt() and 0xFF) shl 8) or (p[i + 1].toInt() and 0xFF)
                    i += 2
                    if (size == 0) continue // junk entry, not a dead session
                    if (i + size > end) break
                    onNal(p.copyOfRange(i, i + size), ts, marker && i + size >= end)
                    i += size
                }
            }
            28 -> { // FU-A: [indicator][S E R type][fragment]
                if (at + 2 > end) return
                val fu = p[at + 1].toInt() and 0xFF
                if (fu and 0x80 != 0) {
                    fragment.reset()
                    fragment.write((p[at].toInt() and 0xE0) or (fu and 0x1F))
                    fragmentOpen = true
                }
                if (!fragmentOpen) return
                fragment.write(p, at + 2, end - at - 2)
                if (fu and 0x40 != 0) {
                    fragmentOpen = false
                    onNal(fragment.toByteArray(), ts, marker)
                }
            }
            else -> {} // 25..27, 29: interleaved modes nothing here sends
        }
    }

    private fun h265(p: ByteArray, at: Int, end: Int, ts: Long, marker: Boolean) {
        if (at + 2 > end) return
        when (val type = (p[at].toInt() shr 1) and 0x3F) {
            48 -> { // AP: [size][NAL]...
                var i = at + 2
                while (i + 2 <= end) {
                    val size = ((p[i].toInt() and 0xFF) shl 8) or (p[i + 1].toInt() and 0xFF)
                    i += 2
                    if (size == 0) continue // junk entry, not a dead session
                    if (i + size > end) break
                    onNal(p.copyOfRange(i, i + size), ts, marker && i + size >= end)
                    i += size
                }
            }
            49 -> { // FU: [2-byte header][S E type][fragment]
                if (at + 3 > end) return
                val fu = p[at + 2].toInt() and 0xFF
                if (fu and 0x80 != 0) {
                    fragment.reset()
                    fragment.write((p[at].toInt() and 0x81) or ((fu and 0x3F) shl 1))
                    fragment.write(p[at + 1].toInt())
                    fragmentOpen = true
                }
                if (!fragmentOpen) return
                fragment.write(p, at + 3, end - at - 3)
                if (fu and 0x40 != 0) {
                    fragmentOpen = false
                    onNal(fragment.toByteArray(), ts, marker)
                }
            }
            else -> onNal(p.copyOfRange(at, end), ts, marker)
        }
    }
}

/** The NAL type under either codec's header. */
internal fun nalType(codec: RtpCodec, nal: ByteArray): Int = when (codec) {
    RtpCodec.H264 -> nal[0].toInt() and 0x1F
    RtpCodec.H265 -> (nal[0].toInt() shr 1) and 0x3F
}

/**
 * A phone's hardware decodes 4:2:0, 8-bit. A desktop encoder asked for
 * nothing in particular happily produces 4:4:4 or outright RGB — software
 * players eat it, and every phone decoder dies on the first frame with a
 * number for a message. The profile sits in the SPS's first bytes, so the
 * stream is refused by name instead: a field evening went to a Qualcomm
 * decoder's 0x80000000 before ffprobe named the test stream High 4:4:4.
 */
internal fun hostileProfile(codec: RtpCodec, sps: ByteArray): String? = when (codec) {
    // profile_idc is the byte after the one-byte NAL header
    RtpCodec.H264 -> when (sps.getOrNull(1)?.toInt()?.and(0xFF)) {
        244, 144, 44 -> "High 4:4:4"
        122 -> "High 4:2:2"
        110 -> "High 10"
        else -> null
    }
    // general_profile_idc, low five bits of the byte after the two-byte
    // NAL header and the sub-layer byte; Main is 1, Main 10 is 2
    RtpCodec.H265 -> when (val idc = sps.getOrNull(3)?.toInt()?.and(0x1F)) {
        null, 1, 2, 3 -> null
        else -> "profile $idc (a range extension)"
    }
}

/**
 * A raw pushed stream: RTP datagrams carrying H.264 or H.265 straight at a
 * port on this phone — the OpenIPC / wfb-ng ground stations and
 * QGroundControl-style senders, which have no server to dial and begin
 * talking the moment the link is up. The NAL units go to the phone's
 * hardware decoder and every frame renders the moment it is decoded; there
 * is no buffer, so the latency is the link's own.
 *
 * The codec is read off the stream itself — senders repeat their parameter
 * sets, so listening briefly always answers — and decoding starts at the
 * first keyframe after that.
 */
class UdpSource(
    private val port: Int,
    // the picture's extra quarter-turn, asked of the host at fit time — the
    // host owns the setting, the source only wears it
    private val turn: () -> Int,
    private val events: VideoSource.Events
) : VideoSource {

    @Volatile private var running = false
    // the multicast lock this listener holds while it runs, released with it
    private var lock: juricabi.com.telemetry.utils.NetworkBinder? = null
    @Volatile private var live = false
    @Volatile private var socket: DatagramSocket? = null
    // the holder's own Surface — the decoder renders into it; not released
    // here, since the SurfaceView owns it and frees it with its window
    @Volatile private var surface: Surface? = null
    @Volatile private var view: SurfaceView? = null
    @Volatile private var pictureWidth = 0
    @Volatile private var pictureHeight = 0

    // whole access units, receiver to decoder, each marked whether it
    // carries a keyframe; a burst beyond the decoder's pace drops the
    // backlog rather than growing a latency debt
    private val units = ArrayBlockingQueue<Triple<ByteArray, Long, Boolean>>(4)

    // Decoding must (re)start at a keyframe — the picture before one is
    // built on frames never seen. True at the start, and raised again by
    // anything that dropped frames: without this, every burst-then-stall
    // smeared the picture until the sender's next keyframe anyway, plus
    // seconds of grey garbage in between.
    @Volatile private var needKeyframe = true

    // pokes the codec thread when a fresh access unit lands; null while
    // there is no codec to feed
    @Volatile private var feedNudge: (() -> Unit)? = null

    private val refitOnLayout = android.view.View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
        refit()
    }

    // the turn the running decoder was configured with; KEY_ROTATION binds
    // only at configure, so a change to the preference asks the decoder to
    // rebuild — the receive loop respawns it, the socket untouched
    @Volatile private var decoderRotation = 0
    @Volatile private var rebuildDecoder = false

    override fun refit() {
        val v = view ?: return
        val wanted = turn()
        // a tap on rotate moved the preference; the running decoder still
        // outputs the old turn, so rebuild it and keep the half in the old
        // shape until the new frames land — the box and the turned picture
        // then snap together, rather than the box turning first onto a
        // picture not yet there, which read as wrongly turned. The gap is
        // clean black, the old decoder's stretched frames dropped.
        if (wanted != decoderRotation) rebuildDecoder = true
        val (w, h) = turnedSides(pictureWidth, pictureHeight, decoderRotation)
        v.fitPicture(w, h)
    }

    private val holderCallback = object : SurfaceHolder.Callback {
        override fun surfaceCreated(holder: SurfaceHolder) {
            DebugLog.note("Video", "udp surface up")
            // the receive loop builds the decoder on its next packet once it
            // sees a surface to draw into — milliseconds away on a live stream
            surface = holder.surface
        }
        override fun surfaceChanged(holder: SurfaceHolder, f: Int, w: Int, h: Int) {}
        override fun surfaceDestroyed(holder: SurfaceHolder) {
            DebugLog.note("Video", "udp surface gone")
            surface = null
        }
    }

    override fun start(view: SurfaceView) {
        DebugLog.note("Video", "udp listen :$port")
        // Wi-Fi power saving drops broadcast frames, and a ground station that
        // pushes its RTP to the subnet's broadcast address is delivering the
        // picture in exactly those — the telemetry link holds this same lock
        // for the same reason, and the video half should not depend on one
        // being connected. Nothing else here: a listener that never sends
        // needs no network pinned, and hears every interface unbound.
        lock = juricabi.com.telemetry.utils.NetworkBinder(view.context)
            .also { it.acquire() }
        this.view = view
        view.addOnLayoutChangeListener(refitOnLayout)
        view.holder.addCallback(holderCallback)
        view.holder.surface?.takeIf { it.isValid }?.let { surface = it }
        running = true
        Thread({ receive() }, "udp-video").start()
    }

    private fun receive() {
        val socket = try {
            DatagramSocket(port).also {
                it.receiveBufferSize = 1 shl 19
                it.soTimeout = 1000
            }
        } catch (e: Exception) {
            if (running) events.onTrouble("UDP port $port cannot be opened — ${e.message}")
            return
        }
        this.socket = socket
        // stop() closes whatever it finds in the field; landed after it
        // already ran, this side of the handshake closes it itself
        if (!running) {
            socket.close()
            return
        }
        val packet = DatagramPacket(ByteArray(65536), 65536)
        var codec: RtpCodec? = null
        var depacketizer: RtpDepacketizer? = null
        val csd = LinkedHashMap<Int, ByteArray>() // parameter sets by NAL type
        var decoder: Thread? = null
        // the access unit being gathered: NALs sharing one RTP timestamp
        val au = ByteArrayOutputStream(256 * 1024)
        var auTimestamp = -1L
        var auHasKeyframe = false
        var lastHeard = System.currentTimeMillis()
        var firstHeard = lastHeard
        var everHeard = false

        fun finishAu() {
            if (au.size() == 0) return
            val bytes = au.toByteArray()
            val key = auHasKeyframe
            au.reset()
            auHasKeyframe = false
            if (needKeyframe && !key) return
            needKeyframe = false
            if (!units.offer(Triple(bytes, auTimestamp, key))) {
                // the decoder fell behind; the backlog goes, and with it the
                // reference pictures — so a non-keyframe goes with them
                units.clear()
                needKeyframe = !key
                if (key) units.offer(Triple(bytes, auTimestamp, key))
            }
            feedNudge?.invoke()
        }

        try {
            while (running) {
                try {
                    socket.receive(packet)
                } catch (e: SocketTimeoutException) {
                    val quiet = System.currentTimeMillis() - lastHeard
                    if (!everHeard && quiet > 8000) {
                        events.onTrouble(
                            "nothing arrives on UDP port $port — the sender " +
                                "must be pointed at this phone's address"
                        )
                        return
                    }
                    if (everHeard && codec == null && quiet > 8000) {
                        events.onTrouble(
                            "UDP port $port carries data but no H.264/H.265 " +
                                "parameter sets came — is the sender using RTP?"
                        )
                        return
                    }
                    if (live && quiet > 4000) {
                        live = false
                        needKeyframe = true // whatever was mid-air is gone
                        DebugLog.note("Video", "udp stream went quiet")
                        events.onIdle()
                    }
                    continue
                }
                lastHeard = System.currentTimeMillis()
                if (!everHeard) {
                    everHeard = true
                    firstHeard = lastHeard
                    val b = packet.data
                    if (packet.length >= 188 && b[0].toInt() == 0x47 &&
                        packet.length % 188 == 0
                    ) {
                        events.onTrouble(
                            "UDP port $port carries MPEG-TS, which this does " +
                                "not read — set the sender to RTP"
                        )
                        return
                    }
                }
                if (codec == null) {
                    codec = sniffRtpCodec(packet.data, packet.length)
                    if (codec == null) {
                        // judged here, among the arriving packets — a check
                        // living only in the silence branch never ran while
                        // an undecodable stream kept the socket busy
                        if (lastHeard - firstHeard > 8000) {
                            events.onTrouble(
                                "UDP port $port carries data but no " +
                                    "H.264/H.265 parameter sets came — is " +
                                    "the sender using RTP?"
                            )
                            return
                        }
                        continue
                    }
                    DebugLog.note("Video", "udp stream is ${codec.name} (RTP)")
                    val chosen = codec
                    depacketizer = RtpDepacketizer(chosen) { nal, ts, marker ->
                        if (ts != auTimestamp && auTimestamp != -1L) finishAu()
                        auTimestamp = ts
                        val type = nalType(chosen, nal)
                        val parameterSet = when (chosen) {
                            RtpCodec.H264 -> type == 7 || type == 8
                            RtpCodec.H265 -> type in 32..34
                        }
                        if (parameterSet && csd.size < 3) csd[type] = nal
                        auHasKeyframe = auHasKeyframe || when (chosen) {
                            RtpCodec.H264 -> type == 5
                            RtpCodec.H265 -> type in 16..21
                        }
                        au.write(0); au.write(0); au.write(0); au.write(1)
                        au.write(nal, 0, nal.size)
                        if (marker) finishAu()
                    }
                }
                depacketizer?.feed(packet.data, packet.length)
                // the decoder starts once the stream has told it what it is
                // and the screen has given it somewhere to draw — and starts
                // again after a turn ended the last one. A turned decoder is
                // let die fully first (isAlive false) so two hardware codecs
                // never overlap, and a keyframe is waited for so the fresh
                // one is not built on frames unseen; the rebuild flag clears
                // as it is born, or the new decoder would end at once too.
                if (decoder?.isAlive != true && surface != null &&
                    (codec == RtpCodec.H264 && csd.size >= 2 ||
                        codec == RtpCodec.H265 && csd.size >= 3)
                ) {
                    rebuildDecoder = false
                    needKeyframe = true
                    val sps = if (codec == RtpCodec.H264) csd[7] else csd[33]
                    val hostile = sps?.let { hostileProfile(codec!!, it) }
                    if (hostile != null) {
                        events.onTrouble(
                            "the stream is ${codec!!.name} $hostile — phones " +
                                "decode 4:2:0 8-bit; give ffmpeg -pix_fmt yuv420p"
                        )
                        return
                    }
                    // sorted by NAL type: SPS before PPS, VPS-SPS-PPS —
                    // whatever order the stream repeated them in
                    val d = Thread({ decode(codec!!, csd.toSortedMap().values.toList()) }, "udp-decode")
                    decoder = d
                    d.start()
                }
            }
        } catch (e: Exception) {
            // stop() closes the socket under the blocked receive; only a
            // failure while still wanted is trouble
            if (running) events.onTrouble("listening on UDP port $port failed — ${e.message}")
        } finally {
            socket.close()
        }
    }

    // a bare CodecException says nothing; its diagnostic carries the
    // vendor's actual error code
    private fun worded(e: Exception): String =
        if (e is MediaCodec.CodecException) "$e [${e.diagnosticInfo}]" else "$e"

    private fun decode(codec: RtpCodec, parameterSets: List<ByteArray>) {
        val startCode = byteArrayOf(0, 0, 0, 1)
        val decoder = try {
            MediaCodec.createDecoderByType(codec.mime)
        } catch (e: Exception) {
            DebugLog.note("Video", "udp no ${codec.name} decoder: $e")
            if (running) events.onTrouble("this phone has no ${codec.name} decoder")
            return
        }
        // Everything the codec does happens on this one thread, through its
        // own callbacks. The synchronous polling loop this replaced died on
        // a field phone whose Qualcomm stack poisoned the codec at its very
        // first frame and only said so by wrecking the next poll — while the
        // same phone plays RTSP through ExoPlayer, which runs its codecs
        // exactly this way. Asynchronous, onError finally says what broke.
        val codecThread = HandlerThread("udp-codec")
        codecThread.start()
        val handler = Handler(codecThread.looper)
        val died = java.util.concurrent.atomic.AtomicBoolean(false)
        // touched on the codec thread alone
        val freeInputs = ArrayDeque<Int>()
        var fed = 0
        var drained = 0
        // the 32-bit RTP clock extended to 64: it starts anywhere and can
        // wrap mid-session, and time running backward upsets some decoders
        var lastRawTicks = -1L
        var ticks = 0L

        fun fail(said: String, what: String) {
            // stop() tearing the codec down mid-callback is the usual way
            // here; only a death while still wanted is trouble
            if (died.getAndSet(true) || !running) return
            DebugLog.note("Video", "$said, fed=$fed drained=$drained")
            events.onTrouble(what)
        }

        // waiting units into waiting input buffers — run when either side
        // gains a piece
        val pump = object : Runnable {
            override fun run() {
                try {
                    while (freeInputs.isNotEmpty()) {
                        val (bytes, timestamp, keyframe) = units.poll() ?: return
                        // frames behind a drop lean on pictures never decoded
                        if (needKeyframe && !keyframe) continue
                        if (keyframe) needKeyframe = false
                        val at = freeInputs.removeFirst()
                        if (lastRawTicks >= 0) ticks += (timestamp - lastRawTicks).toInt()
                        lastRawTicks = timestamp
                        decoder.getInputBuffer(at)?.put(bytes)
                        // 90 kHz ticks to microseconds; frames render on
                        // arrival, so only monotony matters, not the epoch
                        decoder.queueInputBuffer(at, 0, bytes.size, ticks * 100 / 9, 0)
                        fed++
                    }
                } catch (e: Exception) {
                    fail("udp feed error: ${worded(e)}", "decoding failed — ${e.message}")
                }
            }
        }

        decoder.setCallback(object : MediaCodec.Callback() {
            override fun onInputBufferAvailable(c: MediaCodec, index: Int) {
                freeInputs.addLast(index)
                pump.run()
            }

            override fun onOutputBufferAvailable(
                c: MediaCodec, index: Int, info: MediaCodec.BufferInfo
            ) {
                try {
                    // Once the turn has changed, this decoder's frames are
                    // the old orientation stretched into the reshaped box —
                    // a squished flash. Dropped, not rendered: the box stays
                    // cleanly black until the fresh decoder's real turned
                    // picture lands.
                    c.releaseOutputBuffer(index, !rebuildDecoder)
                } catch (e: Exception) {
                    fail("udp render error: ${worded(e)}", "decoding failed — ${e.message}")
                    return
                }
                if (rebuildDecoder) return
                drained++
                if (!live) {
                    live = true
                    DebugLog.note("Video", "udp first frame rendered")
                    events.onLive()
                }
            }

            override fun onOutputFormatChanged(c: MediaCodec, f: MediaFormat) {
                // the crop is the picture; the coded size carries the
                // macroblock padding — 1088 tall for a 1080p stream
                pictureWidth = if (f.containsKey("crop-right"))
                    f.getInteger("crop-right") - f.getInteger("crop-left") + 1
                else f.getInteger(MediaFormat.KEY_WIDTH)
                pictureHeight = if (f.containsKey("crop-bottom"))
                    f.getInteger("crop-bottom") - f.getInteger("crop-top") + 1
                else f.getInteger(MediaFormat.KEY_HEIGHT)
                DebugLog.note("Video", "udp picture ${pictureWidth}x$pictureHeight")
                view?.post { refit() }
            }

            override fun onError(c: MediaCodec, e: MediaCodec.CodecException) {
                fail(
                    "udp codec error: ${worded(e)} " +
                        "recoverable=${e.isRecoverable} transient=${e.isTransient}",
                    "decoding failed — ${e.message}"
                )
            }
        }, handler)

        try {
            val format = MediaFormat.createVideoFormat(codec.mime, 1920, 1080)
            // the parameter sets, not this nominal 1920x1080, decide the
            // real picture — but the input buffers are sized off it, and a
            // 4K keyframe must still fit in one
            format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 shl 20)
            // Decoders left to themselves pipeline a few frames for
            // throughput's sake; this stream is a pilot's eyes, and Android
            // 11's low-latency switch tells the codec to hand each frame
            // over the moment it is decoded. Asked of the codec first: the
            // key is only defined for codecs that declare the feature, and
            // set blindly it can kill a decoder that never heard of it.
            val lowLatency = android.os.Build.VERSION.SDK_INT >= 30 &&
                decoder.codecInfo.getCapabilitiesForType(codec.mime)
                    .isFeatureSupported(
                        android.media.MediaCodecInfo.CodecCapabilities.FEATURE_LowLatency
                    )
            if (lowLatency) format.setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            // The turn is the decoder's, not the view's: a SurfaceView will
            // not rotate its surface content, so the codec is told to rotate
            // the frames before they reach the surface. Read once here; a
            // change to it rebuilds the decoder, since the key is honoured
            // only at configure.
            decoderRotation = turn()
            format.setInteger(MediaFormat.KEY_ROTATION, decoderRotation)
            when (codec) {
                // AVC's documented form is SPS and PPS as separate buffers;
                // one concatenated run worked on most phones and failed on
                // the picky ones. HEVC's documented form is the one run.
                RtpCodec.H264 -> parameterSets.forEachIndexed { i, set ->
                    val bytes = ByteArrayOutputStream()
                    bytes.write(startCode)
                    bytes.write(set)
                    format.setByteBuffer("csd-$i", java.nio.ByteBuffer.wrap(bytes.toByteArray()))
                }
                RtpCodec.H265 -> {
                    val bytes = ByteArrayOutputStream()
                    for (set in parameterSets) {
                        bytes.write(startCode)
                        bytes.write(set)
                    }
                    format.setByteBuffer("csd-0", java.nio.ByteBuffer.wrap(bytes.toByteArray()))
                }
            }
            decoder.configure(format, surface, null, 0)
            decoder.start()
            DebugLog.note(
                "Video",
                "udp ${codec.name} decoder up (async): ${decoder.name}" +
                    (if (lowLatency) ", low-latency" else "") +
                    ", surface valid=${surface?.isValid}"
            )
        } catch (e: Exception) {
            // a released codec is not scarce; an unreleased one starves the
            // user's own retry of a hardware decoder instance
            decoder.release()
            codecThread.quitSafely()
            DebugLog.note("Video", "udp decoder failed: ${worded(e)}")
            if (running) events.onTrouble("the ${codec.name} decoder failed to start")
            return
        }
        feedNudge = { handler.post(pump) }
        try {
            // this thread now only minds the codec's lifetime, and ends it
            // early when the turn changed — the receive loop builds a fresh
            // one with the new KEY_ROTATION
            while (running && !died.get() && !rebuildDecoder) Thread.sleep(50)
        } catch (e: InterruptedException) {
        } finally {
            feedNudge = null
            // Tear the codec down ON its own handler, where the feed pump
            // and the input callbacks also run: a rebuild that stopped it
            // from this thread raced a queueInputBuffer still in flight —
            // "valid only at Executing states; currently during stop()" —
            // and the spurious throw showed as "decoding failed" on a turn.
            // Posted here, the stop waits its turn behind any live feed.
            val torn = java.util.concurrent.CountDownLatch(1)
            handler.post {
                try {
                    decoder.stop()
                } catch (e: Exception) {
                }
                decoder.release()
                torn.countDown()
            }
            torn.await(500, java.util.concurrent.TimeUnit.MILLISECONDS)
            codecThread.quitSafely()
        }
    }

    override fun stop() {
        DebugLog.note("Video", "udp stop")
        running = false
        lock?.release()
        lock = null
        socket?.close() // unblocks the receiver mid-wait
        view?.holder?.removeCallback(holderCallback)
        view?.removeOnLayoutChangeListener(refitOnLayout)
        view = null
        // dropped, not released: the holder owns the surface and frees it
        surface = null
    }
}
