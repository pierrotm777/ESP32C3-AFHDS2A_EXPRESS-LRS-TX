package juricabi.com.telemetry.protocol

import android.util.Log
import juricabi.com.telemetry.protocol.crc.CRCMAVLink
import juricabi.com.telemetry.protocol.decoder.DataDecoder
import juricabi.com.telemetry.protocol.decoder.MAVLinkDataDecoder
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MAVLinkProtocol : Protocol {

    constructor(dataListener: DataDecoder.Listener) : super(MAVLinkDataDecoder(dataListener))
    constructor(dataDecoder: DataDecoder) : super(dataDecoder)

    private val crc = CRCMAVLink()

    private var state = State.IDLE
    private var buffer: IntArray = IntArray(0)
    private var payloadIndex = 0
    private var packetLength = 0
    private var packetIndex = 0
    private var systemId = 0
    private var componentId = 0
    private var messageId = 0
    private var crcLow: Int? = null
    private var crcHigh: Int? = null
    private var unique = HashSet<Int>()
    /** Prefer the estimator while its stream is actually still arriving. */
    private val positionSource = MavPositionSource()

    private val rssiSource = MavRssiSource()

    companion object {
        enum class State {
            IDLE, LENGTH, INDEX, SYSTEM_ID, COMPONENT_ID, MESSAGE_ID, PAYLOAD, CRC
        }

        private const val PACKET_MARKER = 0xFE

        private const val MAV_PACKET_HEARTBEAT_ID = 0
        private const val MAV_PACKET_STATUS_ID = 1
        private const val MAV_PACKET_ATTITUDE_ID = 30
        private const val MAV_PACKET_RC_CHANNELS_RAW_ID = 35
        private const val MAV_PACKET_VFR_HUD_ID = 74
        private const val MAV_PACKET_GPS_RAW_ID = 24
        private const val MAV_PACKET_GLOBAL_POSITION_ID = 33
        private const val MAV_PACKET_RADIO_STATUS_ID = 109
        private const val MAV_PACKET_GPS_ORIGIN_ID = 49
        private const val MAV_PACKET_HOME_POSITION_ID = 242
        private const val MAV_PACKET_STATUSTEXT_ID = 253
        private const val MAV_PACKET_HIGH_LATENCY2_ID = 235

        private const val MAV_PACKET_STATUS_LENGTH = 31
        private const val MAV_PACKET_HEARTBEAT_LENGTH = 9
        private const val MAV_PACKET_RC_CHANNEL_LENGTH = 22
        private const val MAV_PACKET_ATTITUDE_LENGTH = 28
        private const val MAV_PACKET_VFR_HUD_LENGTH = 20
        private const val MAV_PACKET_GPS_RAW_LENGTH = 30
        private const val MAV_PACKET_GLOBAL_POSITION_LENGTH = 28
        private const val MAV_PACKET_RADIO_STATUS_LENGTH = 9
        private const val MAV_PACKET_GPS_ORIGIN_LENGTH = 12
        private const val  MAV_PACKET_HOME_POSITION_LENGTH = 52
        private const val MAV_PACKET_STATUSTEXT_MIN_LENGTH = 51
        private const val MAV_PACKET_HIGH_LATENCY2_LENGTH = 42
        private const val MAV_PACKET_TRANSMISSION_HANDSHAKE = 130
        private const val MAV_PACKET_ENCAPSULATED_DATA      = 131
    }

    override fun process(data: Int) {
        when (state) {
            State.IDLE -> {
                if (data == PACKET_MARKER) {
                    state = State.LENGTH
                }
            }
            State.LENGTH -> {
                packetLength = data
                state = State.INDEX
            }
            State.INDEX -> {
                packetIndex = data
                state = State.SYSTEM_ID
            }
            State.SYSTEM_ID -> {
                systemId = data
                state = State.COMPONENT_ID
            }
            State.COMPONENT_ID -> {
                componentId = data
                state = State.MESSAGE_ID
            }
            State.MESSAGE_ID -> {
                messageId = data
                state = State.PAYLOAD
                payloadIndex = 0
                buffer = IntArray(packetLength)
            }
            State.PAYLOAD -> {
                if (payloadIndex < packetLength) {
                    buffer[payloadIndex] = data
                    payloadIndex++
                } else {
                    state = State.CRC
                    crcLow = data
                    crcHigh = null
                }
            }
            State.CRC -> {
                crcHigh = data
                if (checkCrc()) {
                    processPacket()
                } else {
                    Log.d("MAVLinkProtocol", "Bad CRC for $messageId")
                }
                state = State.IDLE
            }
        }
    }

    private fun processPacket() {
        val byteBuffer = ByteBuffer.wrap(buffer.map { it.toByte() }.toByteArray())
            .order(ByteOrder.LITTLE_ENDIAN)
        if (messageId == MAV_PACKET_STATUS_ID && packetLength == MAV_PACKET_STATUS_LENGTH) {
            val sensors = byteBuffer.int
            val enabledSensors = byteBuffer.int
            val healthSensors = byteBuffer.int
            val load = byteBuffer.short
            val voltage = byteBuffer.short.toInt() and 0xFFFF
            val current = byteBuffer.short
            val dropRate = byteBuffer.short
            val errors = byteBuffer.short
            val errorsCount1 = byteBuffer.short
            val errorsCount2 = byteBuffer.short
            val errorsCount3 = byteBuffer.short
            val errorsCount4 = byteBuffer.short
            val fuel = byteBuffer.get()

            if (voltage != 0xFFFF) {
                dataDecoder.decodeData(Protocol.Companion.TelemetryData(VBAT, voltage))
            }
            dataDecoder.decodeData( Protocol.Companion.TelemetryData( Protocol.CURRENT, current.toInt()))
            dataDecoder.decodeData(Protocol.Companion.TelemetryData(Protocol.FUEL, fuel.toInt()))
        } else if (
            messageId == MAV_PACKET_STATUSTEXT_ID &&
            packetLength >= MAV_PACKET_STATUSTEXT_MIN_LENGTH
        ) {
            val severity = byteBuffer.get()
            dataDecoder.decodeData(Protocol.Companion.TelemetryData(STATUSTEXT, severity.toInt(), byteBuffer.array()))
        } else if (messageId == MAV_PACKET_HEARTBEAT_ID && packetLength == MAV_PACKET_HEARTBEAT_LENGTH) {
            val customMode = byteBuffer.int
            val aircraftType = byteBuffer.get()
            val autopilotClass = byteBuffer.get()
            val mode = byteBuffer.get()
            val state = byteBuffer.get()
            val version = byteBuffer.get()
            dataDecoder.decodeData(Protocol.Companion.TelemetryData(FLYMODE, mode.toInt(), byteBuffer.array()))
            val rawMode = mode.toInt();
            val armed = (rawMode and MAVLinkDataDecoder.MAV_MODE_FLAG_SAFETY_ARMED) == MAVLinkDataDecoder.MAV_MODE_FLAG_SAFETY_ARMED;
            this.processArmed(armed);
        } else if (messageId == MAV_PACKET_RC_CHANNELS_RAW_ID && packetLength == MAV_PACKET_RC_CHANNEL_LENGTH) {
            //Channels RC
            //mavlink_rc_channels_raw_t
            //https://github.com/iNavFlight/inav/blob/master/lib/main/MAVLink/common/mavlink_msg_rc_channels_raw.h
            val time = byteBuffer.int
            val channel0 = byteBuffer.short
            dataDecoder.decodeData( Protocol.Companion.TelemetryData(RC_CHANNEL_0,channel0.toInt()))
            val channel1 = byteBuffer.short
            dataDecoder.decodeData( Protocol.Companion.TelemetryData(RC_CHANNEL_1,channel1.toInt()))
            val channel2 = byteBuffer.short
            dataDecoder.decodeData( Protocol.Companion.TelemetryData(RC_CHANNEL_2,channel2.toInt()))
            val channel3 = byteBuffer.short
            dataDecoder.decodeData( Protocol.Companion.TelemetryData(RC_CHANNEL_3,channel3.toInt()))
            val channel4 = byteBuffer.short
            dataDecoder.decodeData( Protocol.Companion.TelemetryData(RC_CHANNEL_4,channel4.toInt()))
            val channel5 = byteBuffer.short
            dataDecoder.decodeData( Protocol.Companion.TelemetryData(RC_CHANNEL_5,channel5.toInt()))
            val channel6 = byteBuffer.short
            dataDecoder.decodeData( Protocol.Companion.TelemetryData(RC_CHANNEL_6,channel6.toInt()))
            val channel7 = byteBuffer.short
            dataDecoder.decodeData( Protocol.Companion.TelemetryData(RC_CHANNEL_7,channel7.toInt()))
            val port = byteBuffer.get()
            val rssi = byteBuffer.get().toInt() and 0xff
            if (!rssiSource.preferRadioStatus())
                dataDecoder.decodeData( Protocol.Companion.TelemetryData(RSSI,rssi.toInt()))
        } else if (messageId == MAV_PACKET_ATTITUDE_ID && packetLength == MAV_PACKET_ATTITUDE_LENGTH) {
            dataDecoder.decodeData(
                Protocol.Companion.TelemetryData(
                    ATTITUDE,
                    0,
                    byteBuffer.array()
                )
            )
        } else if (messageId == MAV_PACKET_VFR_HUD_ID && packetLength == MAV_PACKET_VFR_HUD_LENGTH) {
            val airSpeed = byteBuffer.float
            val groundSpeed = byteBuffer.float
            val alt = byteBuffer.float
            val vspeed = byteBuffer.float
            val heading = byteBuffer.short
            val throttle = byteBuffer.short

            dataDecoder.decodeData( Protocol.Companion.TelemetryData( GSPEED, (groundSpeed * 100).toInt()))
            dataDecoder.decodeData( Protocol.Companion.TelemetryData( ASPEED, (airSpeed * 100).toInt()))
            dataDecoder.decodeData( Protocol.Companion.TelemetryData( VSPEED, (vspeed * 100).toInt()))
            dataDecoder.decodeData( Protocol.Companion.TelemetryData( THROTTLE, throttle.toInt()))
            // Not while the estimator's own frame is arriving. This one is
            // height above the sea on ArduPilot and the other is height above
            // the launch, and taking both made the readout — and the height the
            // flight is drawn at — alternate between the two several times a
            // second.
            if (!positionSource.preferGlobal()) {
                dataDecoder.decodeData(Protocol.Companion.TelemetryData(ALTITUDE, (alt * 100).toInt()))
            }

        } else if (messageId == MAV_PACKET_RADIO_STATUS_ID && packetLength == MAV_PACKET_RADIO_STATUS_LENGTH) {
            val rxErrors = byteBuffer.short
            val fixed = byteBuffer.short
            val rssi = byteBuffer.get().toInt() and 0xff
            val remRssi = byteBuffer.get()
            val txbuf = byteBuffer.get()
            val noise = byteBuffer.get()
            val remnoise = byteBuffer.get()
            rssiSource.radioStatusArrived()
            dataDecoder.decodeData( Protocol.Companion.TelemetryData(RSSI,rssi.toInt()))
        } else if (
            messageId == MAV_PACKET_GLOBAL_POSITION_ID &&
            packetLength == MAV_PACKET_GLOBAL_POSITION_LENGTH
        ) {
            // Where the flight controller believes it is, rather than where the
            // GPS receiver alone says: position, height and heading after the
            // estimator has had the accelerometers, the barometer and the
            // compass as well. ArduPilot and PX4 both stream it by default.
            val bootTime = byteBuffer.int
            val lat = byteBuffer.int
            val lon = byteBuffer.int
            val altitude = byteBuffer.int
            val relativeAltitude = byteBuffer.int
            val vx = byteBuffer.short
            val vy = byteBuffer.short
            val vz = byteBuffer.short
            val heading = byteBuffer.short.toInt() and 0xFFFF

            positionSource.globalArrived()
            dataDecoder.decodeData(Protocol.Companion.TelemetryData(Protocol.GPS_ALTITUDE, altitude))
            dataDecoder.decodeData(Protocol.Companion.TelemetryData(Protocol.GPS_LATITUDE, lat))
            this.processLatitude(lat / 10000000.toDouble())
            dataDecoder.decodeData(Protocol.Companion.TelemetryData(Protocol.GPS_LONGITUDE, lon))
            this.processLongitude(lon / 10000000.toDouble())
            // millimetres above the launch, and the readout counts centimetres
            dataDecoder.decodeData(
                Protocol.Companion.TelemetryData(Protocol.ALTITUDE, relativeAltitude / 10))
            // hundredths of a degree, and all ones for "no idea"
            if (heading != 0xFFFF) {
                dataDecoder.decodeData(Protocol.Companion.TelemetryData(Protocol.HEADING, heading))
            }
        } else if (messageId == MAV_PACKET_GPS_RAW_ID && packetLength == MAV_PACKET_GPS_RAW_LENGTH) {
            val time = byteBuffer.long
            val lat = byteBuffer.int
            val lon = byteBuffer.int
            val altitude = byteBuffer.int
            val eph = byteBuffer.short
            val epv = byteBuffer.short
            val vel = byteBuffer.short
            val cog = byteBuffer.short.toInt() and 0xFFFF
            val fixType = byteBuffer.get()
            val satellites = byteBuffer.get()

            // The fix and how many satellites are behind it come from here
            // whatever else is arriving: the estimator's position frame says
            // nothing about either.
            dataDecoder.decodeData( Protocol.Companion.TelemetryData( Protocol.GPS_STATE, fixType.toInt()))
            dataDecoder.decodeData( Protocol.Companion.TelemetryData( Protocol.GPS_SATELLITES, satellites.toInt()))
            // The place itself only while nothing better is being sent. Both
            // frames at once made the model step between the receiver's own
            // position and the estimator's several times a second.
            val preferGlobal = positionSource.preferGlobal()
            if (!preferGlobal) {
                dataDecoder.decodeData(Protocol.Companion.TelemetryData(Protocol.GPS_ALTITUDE, altitude))
                dataDecoder.decodeData(Protocol.Companion.TelemetryData(Protocol.GPS_LATITUDE, lat))
                this.processLatitude(lat / 10000000.toDouble());
                dataDecoder.decodeData(Protocol.Companion.TelemetryData(Protocol.GPS_LONGITUDE, lon))
                this.processLongitude(lon / 10000000.toDouble());
            }
            if (cog != 0xFFFF && !preferGlobal)
                dataDecoder.decodeData( Protocol.Companion.TelemetryData( Protocol.HEADING, cog))
        } else if (
            messageId == MAV_PACKET_GPS_ORIGIN_ID &&
            packetLength == MAV_PACKET_GPS_ORIGIN_LENGTH
        ) {
            val lat = byteBuffer.int
            val lon = byteBuffer.int

            dataDecoder.decodeData(Protocol.Companion.TelemetryData(GPS_ORIGIN_LATITUDE, lat))
            this.processOriginLatitude(lat / 10000000.toDouble())
            dataDecoder.decodeData(Protocol.Companion.TelemetryData(GPS_ORIGIN_LONGITUDE, lon))
            this.processOriginLongitude(lon / 10000000.toDouble())
        } else if (messageId == MAV_PACKET_HOME_POSITION_ID && packetLength == MAV_PACKET_HOME_POSITION_LENGTH) {
            val lat = byteBuffer.int
            val lon = byteBuffer.int

            dataDecoder.decodeData(Protocol.Companion.TelemetryData(GPS_HOME_LATITUDE, lat))
            this.processHomeLatitude(lat / 10000000.toDouble())
            dataDecoder.decodeData(Protocol.Companion.TelemetryData(GPS_HOME_LONGITUDE, lon))
            this.processHomeLongitude(lon / 10000000.toDouble())
        } else if (
            messageId == MAV_PACKET_HIGH_LATENCY2_ID &&
            packetLength == MAV_PACKET_HIGH_LATENCY2_LENGTH
        ) {
            // The whole message in one piece: its fields are packed tightly
            // enough that pulling them apart belongs beside the unit
            // conversions, not here. Position at the protocol level as well,
            // for the distance the base class keeps.
            val lat = byteBuffer.getInt(4)
            val lon = byteBuffer.getInt(8)
            this.processLatitude(lat / 10000000.toDouble())
            this.processLongitude(lon / 10000000.toDouble())
            dataDecoder.decodeData(
                Protocol.Companion.TelemetryData(HIGH_LATENCY, 0, byteBuffer.array()))
        } else if (messageId == MAVLinkProtocol.MAV_PACKET_TRANSMISSION_HANDSHAKE) {
            dataDecoder.decodeData(Protocol.Companion.TelemetryData(IMAGE_HANDSHAKE, 0, byteBuffer.array()))
        } else if (messageId == MAVLinkProtocol.MAV_PACKET_ENCAPSULATED_DATA) {
            dataDecoder.decodeData(Protocol.Companion.TelemetryData(IMAGE_DATA, 0, byteBuffer.array()))
        } else {
            unique.add(messageId)
        }
    }

    private fun checkCrc(): Boolean {
        crc.start_checksum()
        crc.update_checksum(packetLength)
        crc.update_checksum(packetIndex)
        crc.update_checksum(systemId)
        crc.update_checksum(componentId)
        crc.update_checksum(messageId)
        buffer.forEach { crc.update_checksum(it) }
        crc.finish_checksum(messageId)
        return crcHigh == crc.msb && crcLow == crc.lsb
    }
}
