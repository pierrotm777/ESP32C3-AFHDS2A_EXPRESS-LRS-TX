package juricabi.com.telemetry.protocol.pollers

import juricabi.com.telemetry.protocol.decoder.DataDecoder
import juricabi.com.telemetry.utils.NetworkBinder
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import android.util.Base64
import java.io.InputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.net.SocketTimeoutException

/**
 * Telemetry over the network: UDP, TCP either way round, or a WebSocket.
 *
 * The protocol is detected from the bytes as on every other transport, so
 * whatever the module puts on the socket is understood — CRSF from a serial
 * bridge, MAVLink from a backpack.
 *
 * Threading matches the other pollers: one thread of its own, connection state
 * posted to the main thread, telemetry callbacks on the poller thread.
 *
 * A quiet link is never taken for a dead one — a module with no receiver bound
 * looks exactly like one that lost power, so only a close or an error ends a
 * connection.
 */
class NetworkDataPoller(
    private val mode: Int,
    private val host: String,
    private val port: Int,
    private val listener: DataDecoder.Listener,
    logFile: FileOutputStream?,
    private val binder: NetworkBinder?,
    /**
     * MAVLink High Latency: the protocol is pinned to MAVLink 2 rather than
     * detected — detection needs two decodes, which at one message per five
     * seconds is ten seconds of staring at nothing — and the enable command
     * is sent until the stream answers, since an autopilot boots with its
     * high-latency port silent.
     */
    private val highLatency: Boolean = false
) : DataPoller {

    /**
     * The address this transport actually speaks to. A UDP listen and a TCP
     * server dial nobody — the dialog greys the field and says as much — so an
     * address left in it by an earlier TCP session must not go on to choose the
     * network the socket is pinned to, nor collect a ground station heartbeat
     * every second at whatever answers there now. High latency is the exception
     * the dialog also makes: its enable command needs somewhere to go.
     */
    private val reach =
        if ((mode == MODE_UDP && !highLatency) || mode == MODE_TCP_SERVER) "" else host

    companion object {
        private const val TCP_CONNECT_TIMEOUT_MS = 8000
        private const val BUFFER = 2048
        /** Listen for datagrams: a module that broadcasts, or a router. */
        const val MODE_UDP = 0

        /** Dial out: a TBS WiFi module or a serial-to-WiFi bridge is a server. */
        const val MODE_TCP_CLIENT = 1

        /** Wait for the other end to dial in: mavlink-router, pushing bridges. */
        const val MODE_TCP_SERVER = 2

        /**
         * A TBS Crossfire WiFi module's CRSF WebSocket - the only way into that
         * module that works on every firmware, unlike the MQTT path its own app
         * uses.
         */
        const val MODE_WEBSOCKET = 3

        private const val RECEIVE_TIMEOUT_MS = 1000
        private const val HANDSHAKE_TIMEOUT_MS = 8000
        private const val ANNOUNCE_EVERY_MS = 1000L
        private const val MAX_PEERS = 4

        /**
         * How often and how long to keep asking for the high-latency stream:
         * every second announce beat, up to fifteen asks — half a minute,
         * which is several times the five second cadence of the answer.
         */
        private const val HL_ASK_EVERY_BEATS = 2
        private const val HL_ASK_MOST = 15

        /** A datagram arrives whole or truncated, so hold the largest one. */
        private const val DATAGRAM_BUFFER = 65535

        private const val MAX_FRAME = 1 shl 20
        private const val DEVICE_PING_EVERY_MS = 5000L

        private const val OPCODE_CONTINUATION = 0x0
        private const val OPCODE_TEXT = 0x1
        private const val OPCODE_BINARY = 0x2
        private const val OPCODE_CLOSE = 0x8
        private const val OPCODE_PING = 0x9
        private const val OPCODE_PONG = 0xA

        /**
         * CRSF device ping, broadcast, from the radio address: sync, length,
         * type 0x28, destination, origin, CRC8 over the body with poly 0xD5.
         */
        private val DEVICE_PING = byteArrayOf(
            0xC8.toByte(), 0x04, 0x28, 0x00, 0xEA.toByte(), 0x54
        )

        /**
         * A MAVLink v1 HEARTBEAT from a ground station: length 9, sysid 255,
         * compid 190, msgid 0, type GCS, ending in its two byte checksum.
         * Only used to announce ourselves; a receiver that checks the checksum
         * before registering a sender would drop it without one.
         */
        private val HEARTBEAT = byteArrayOf(
            0xFE.toByte(), 9, 0, 0xFF.toByte(), 0xBE.toByte(), 0,
            0, 0, 0, 0, 6, 8, 0xC0.toByte(), 0, 0,
            0x99.toByte(), 0x53
        )
    }

    /** The shared road: log, detect, pump, and the single latched exit. */
    private val chassis = PollerChassis(listener, logFile) { closeQuietly() }

    /** The stream has answered; the enable command has done its work. */
    @Volatile
    private var heardTelemetry = false

    private var announceBeats = 0
    private var enableAsks = 0

    init {
        if (highLatency) {
            // Pinned, not detected, and said so at once. The wrapper is how
            // this poller learns the stream is alive: onSuccessDecode fires
            // for every message the pinned protocol understands.
            val watching = object : DataDecoder.Listener by listener {
                override fun onSuccessDecode() {
                    heardTelemetry = true
                    listener.onSuccessDecode()
                }
            }
            chassis.select(
                juricabi.com.telemetry.protocol.MAVLink2Protocol(watching),
                "MAVLink High Latency"
            )
        }
    }

    /**
     * Asked to stop. Ours rather than the thread's interrupt status, which the
     * telemetry callbacks this thread runs can swallow - and did, leaving a
     * busy link impossible to disconnect.
     */
    @Volatile
    private var stopping = false

    @Volatile
    private var tcpSocket: Socket? = null

    @Volatile
    private var serverSocket: ServerSocket? = null

    @Volatile
    private var udpSocket: DatagramSocket? = null

    /**
     * Everyone we have heard from, as QGroundControl does it: a UDP listen has
     * no address to type, so the sender of an arriving datagram is the only
     * address we will ever have for talking back.
     */
    private val peers = LinkedHashSet<Pair<InetAddress, Int>>()

    private val thread: Thread

    init {
        thread = Thread(Runnable {
            try {
                when (mode) {
                    MODE_TCP_CLIENT -> runTcp()
                    MODE_TCP_SERVER -> runTcpServer()
                    MODE_WEBSOCKET -> runWebSocket()
                    else -> runUdp()
                }
            } catch (e: Exception) {
                // Anything at all that escapes still has to produce exactly one
                // terminal callback, or DataService.isConnected() stays true
                // forever and the app can never reconnect.
                chassis.finish()
            }
        })
        thread.name = "telemetry-net"
        thread.start()
    }

    // ---------------------------------------------------------------- TCP

    private fun runTcp() {
        val socket = Socket()
        tcpSocket = socket
        // The binder routes by the target: the network that specifically
        // reaches this host carries the stream — Wi-Fi, hotspot, USB-ethernet
        // alike — and loopback or an internet host is left on the default.
        binder?.bind(socket, host)
        socket.tcpNoDelay = true
        socket.connect(InetSocketAddress(host, port), TCP_CONNECT_TIMEOUT_MS)

        chassis.connected()

        // No receive timeout here on purpose: there is nothing this loop would
        // do with the wakeup. Stopping already unblocks it, by closing the
        // socket out from under the read.
        val buffer = ByteArray(BUFFER)
        val input = socket.getInputStream()
        while (!stopping && !chassis.done) {
            // -1 is a clean close by the far end. The Bluetooth poller never
            // has to handle this because RFCOMM throws instead, but a TCP peer
            // that goes away politely would otherwise spin here forever.
            val size = input.read(buffer)
            if (size < 0) break
            chassis.feed(buffer, 0, size)
        }
        chassis.finish()
    }

    private fun runTcpServer() {
        val server = ServerSocket()
        serverSocket = server
        server.reuseAddress = true
        server.bind(InetSocketAddress(port))

        // Bound and waiting counts as connected: there is nothing else the user
        // can do, and reporting it lets the service go foreground and the UI
        // stop saying "connecting".
        chassis.connected()

        server.soTimeout = RECEIVE_TIMEOUT_MS
        while (!stopping && !chassis.done) {
            val client = try {
                server.accept()
            } catch (e: SocketTimeoutException) {
                continue
            }
            tcpSocket = client
            client.tcpNoDelay = true
            val buffer = ByteArray(BUFFER)
            val input = client.getInputStream()
            try {
                while (!stopping && !chassis.done) {
                    val size = input.read(buffer)
                    if (size < 0) break
                    chassis.feed(buffer, 0, size)
                }
            } catch (e: IOException) {
                // that client went away; keep the door open for the next one
            }
            try {
                client.close()
            } catch (e: IOException) {
                // ignore
            }
            tcpSocket = null
        }
        chassis.finish()
    }

    // ---------------------------------------------------------- WebSocket

    private fun runWebSocket() {
        val socket = Socket()
        tcpSocket = socket
        binder?.bind(socket, host)
        socket.tcpNoDelay = true
        socket.connect(InetSocketAddress(host, port), TCP_CONNECT_TIMEOUT_MS)

        val key = Base64.encodeToString(randomBytes(16), Base64.NO_WRAP)
        val crlf = "\r\n"
        val request = "GET /ws HTTP/1.1" + crlf +
            "Host: " + host + crlf +
            "Upgrade: websocket" + crlf +
            "Connection: Upgrade" + crlf +
            "Sec-WebSocket-Key: " + key + crlf +
            "Sec-WebSocket-Version: 13" + crlf + crlf
        val out = socket.getOutputStream()
        out.write(request.toByteArray())
        out.flush()

        // before the handshake read, not after: a peer that accepts and then
        // says nothing would otherwise block here forever, with no terminal
        // callback and the button stuck on "Connecting..."
        socket.soTimeout = HANDSHAKE_TIMEOUT_MS

        val input = socket.getInputStream()
        val status = readHandshake(input)
        // the status line only: an ordinary error page can carry " 101" in its
        // headers, and its body would then be parsed as frames
        if (!status.substringBefore(crlf).contains(" 101 ")) {
            // not a WebSocket endpoint: fail rather than feed HTML to a decoder
            chassis.finish()
            return
        }

        chassis.connected()

        // The module answers rather than volunteers: without a device ping the
        // socket opens and stays silent forever.
        writeFrame(out, OPCODE_BINARY, DEVICE_PING)

        // shorter now: the repeat ping below cannot fire while readFrame blocks
        socket.soTimeout = RECEIVE_TIMEOUT_MS

        var lastPing = System.currentTimeMillis()
        while (!stopping && !chassis.done) {
            // Ask again now and then: the first ping is answered only if the
            // module was ready for it, and the name it replies with is what
            // tells a Crossfire from an ExpressLRS.
            val now = System.currentTimeMillis()
            if (now - lastPing >= DEVICE_PING_EVERY_MS) {
                lastPing = now
                writeFrame(out, OPCODE_BINARY, DEVICE_PING)
            }
            val frame = try {
                readFrame(input)
            } catch (e: SocketTimeoutException) {
                // Nothing this second, which is ordinary: a module with no
                // receiver bound answers the ping and otherwise says nothing.
                continue
            } ?: break
            when (frame.first) {
                OPCODE_BINARY, OPCODE_TEXT, OPCODE_CONTINUATION ->
                    chassis.feed(frame.second, 0, frame.second.size)
                OPCODE_PING -> writeFrame(out, OPCODE_PONG, frame.second)
                OPCODE_CLOSE -> {
                    stopping = true
                }
            }
        }
        chassis.finish()
    }

    /**
     * One generator, kept. Seeding a new one from the clock on every call gave
     * the same mask to every frame written within the same millisecond, which
     * is the one thing a mask is not supposed to be.
     */
    private val random = java.util.Random()

    private fun randomBytes(n: Int): ByteArray {
        val out = ByteArray(n)
        random.nextBytes(out)
        return out
    }

    private fun readHandshake(input: InputStream): String {
        val sb = StringBuilder()
        val endOfHeaders = "\r\n\r\n"
        while (sb.length < 4096 && !sb.endsWith(endOfHeaders)) {
            val c = input.read()
            if (c < 0) break
            sb.append(c.toChar())
        }
        return sb.toString()
    }

    /**
     * Read exactly [n] bytes. A timeout part way through a frame means the rest
     * is still coming, and giving up would lose bytes the stream cannot
     * resynchronise from - so it may only escape at a frame boundary, which is
     * what [mayTimeOut] marks.
     */
    private fun readFully(input: InputStream, n: Int, mayTimeOut: Boolean = false): ByteArray? {
        val out = ByteArray(n)
        var read = 0
        while (read < n) {
            val r = try {
                input.read(out, read, n - read)
            } catch (e: SocketTimeoutException) {
                if (read == 0 && mayTimeOut) throw e
                if (stopping || chassis.done) return null
                continue
            }
            if (r < 0) return null
            read += r
        }
        return out
    }

    /**
     * opcode to payload, null when the stream ends, or SocketTimeoutException
     * when no frame has begun to arrive.
     */
    private fun readFrame(input: InputStream): Pair<Int, ByteArray>? {
        val head = readFully(input, 2, mayTimeOut = true) ?: return null
        val opcode = head[0].toInt() and 0x0F
        val masked = (head[1].toInt() and 0x80) != 0
        var length = (head[1].toInt() and 0x7F).toLong()
        if (length == 126L) {
            val ext = readFully(input, 2) ?: return null
            length = ((ext[0].toInt() and 0xFF).toLong() shl 8) or (ext[1].toInt() and 0xFF).toLong()
        } else if (length == 127L) {
            val ext = readFully(input, 8) ?: return null
            length = 0
            for (b in ext) length = (length shl 8) or (b.toInt() and 0xFF).toLong()
        }
        // a server must not mask, but tolerate it rather than desynchronise
        val mask = if (masked) readFully(input, 4) ?: return null else null
        if (length < 0 || length > MAX_FRAME) return null
        val payload = readFully(input, length.toInt()) ?: return null
        if (mask != null) {
            for (i in payload.indices) {
                payload[i] = (payload[i].toInt() xor mask[i % 4].toInt()).toByte()
            }
        }
        return Pair(opcode, payload)
    }

    /** Client frames must always be masked, says RFC 6455. */
    private fun writeFrame(out: java.io.OutputStream, opcode: Int, payload: ByteArray) {
        val mask = randomBytes(4)
        val header = java.io.ByteArrayOutputStream()
        header.write(0x80 or opcode)
        val n = payload.size
        when {
            n < 126 -> header.write(0x80 or n)
            n < 65536 -> {
                header.write(0x80 or 126); header.write((n shr 8) and 0xFF); header.write(n and 0xFF)
            }
            else -> {
                header.write(0x80 or 127)
                for (shift in intArrayOf(56, 48, 40, 32, 24, 16, 8, 0)) {
                    header.write((n ushr shift) and 0xFF)
                }
            }
        }
        header.write(mask)
        val masked = ByteArray(n)
        for (i in 0 until n) masked[i] = (payload[i].toInt() xor mask[i % 4].toInt()).toByte()
        synchronized(this) {
            out.write(header.toByteArray())
            out.write(masked)
            out.flush()
        }
    }

    // ---------------------------------------------------------------- UDP

    private fun runUdp() {
        // Bound with reuse set before the bind, so a previous session that has
        // not finished closing does not make this one fail.
        val socket = DatagramSocket(null)
        udpSocket = socket
        socket.reuseAddress = true
        socket.broadcast = true
        binder?.bind(socket, reach)
        socket.bind(InetSocketAddress(port))

        // Room for a burst to sit in while we are busy decoding the last one.
        // A request, not a demand: the system may give less, and does not fail.
        try {
            socket.receiveBufferSize = 256 * 1024
        } catch (e: SocketException) {
            // ignore
        }

        chassis.connected()

        // Keep saying hello for as long as we are listening.
        //
        // A sender that unicasts points itself at whoever spoke to it most
        // recently, so announcing once at connect is not enough: anything else
        // that talks to the module — another phone, a ground station on a
        // laptop — takes the stream away and this one is starved until it is
        // restarted. A ground station sends heartbeats continuously for exactly
        // this reason, so this does the same and recovers on its own.
        //
        // The timeout is what makes it possible: without it receive() blocks
        // forever and there is never a moment to re-announce.
        socket.soTimeout = RECEIVE_TIMEOUT_MS
        var lastAnnounce = 0L
        val buffer = ByteArray(DATAGRAM_BUFFER)
        val packet = DatagramPacket(buffer, buffer.size)
        while (!stopping && !chassis.done) {
            val now = System.currentTimeMillis()
            if (now - lastAnnounce >= ANNOUNCE_EVERY_MS) {
                lastAnnounce = now
                announce()
                askForHighLatency()
            }
            // The length has to be restored every time: receive() shrinks it to
            // the size of the datagram that arrived, and it is never grown back.
            packet.length = buffer.size
            try {
                socket.receive(packet)
            } catch (e: SocketTimeoutException) {
                // Nothing arrived in the last second. That is not a failure —
                // it is the gap in which we announce ourselves again.
                continue
            }
            rememberPeer(packet.address, packet.port)
            chassis.feed(packet.data, packet.offset, packet.length)
        }
        chassis.finish()
    }

    /**
     * Remember a sender so we can talk back to it. A heartbeat rather than an
     * empty datagram, because plenty of firmware ignores a zero length one.
     */
    private fun rememberPeer(address: InetAddress?, senderPort: Int) {
        if (address == null || senderPort <= 0) return
        synchronized(peers) {
            val key = Pair(address, senderPort)
            if (peers.contains(key)) return
            // bounded: a broadcast network could otherwise introduce us to
            // every device on it
            if (peers.size >= MAX_PEERS) {
                val oldest = peers.iterator()
                if (oldest.hasNext()) {
                    oldest.next()
                    oldest.remove()
                }
            }
            peers.add(key)
        }
    }

    /** Say hello, for a source that only unicasts back to whoever spoke to it. */
    // Resolved once: getByName can block for seconds, and this runs every
    // second. Volatile because the farewell says goodbye from its own thread:
    // seeing "resolved" without the address it was resolved to would send the
    // high-latency stream's stop to learned peers alone — of which there may
    // be none, leaving the modem talking to nobody, the one thing the farewell
    // is for.
    @Volatile private var announceHost: InetAddress? = null
    @Volatile private var announceHostResolved = false

    private fun announce() {
        val socket = udpSocket ?: return

        // Only while the stream might be MAVLink. Once it is known to be
        // something else, this is a ground station heartbeat being written into
        // a link that never asked for one — and a TBS module in bridge mode puts
        // whatever arrives straight onto the CRSF serial link.
        val live = chassis.protocol
        if (live != null && live !is juricabi.com.telemetry.protocol.MAVLinkProtocol &&
            live !is juricabi.com.telemetry.protocol.MAVLink2Protocol
        ) {
            return
        }

        // Nobody to talk to yet is a perfectly ordinary state: it means nothing
        // has arrived. Broadcasting a hello at the whole network to try to shake
        // something loose is not this app's business — QGroundControl does not
        // do it either, and every module we have met announces itself.
        sendToTargets(socket, HEARTBEAT)
    }

    /** Everyone worth talking to: the typed address, then whoever spoke to us. */
    private fun targets(): List<Pair<InetAddress, Int>> {
        val targets = ArrayList<Pair<InetAddress, Int>>()
        if (reach.isNotEmpty() && !isLoopback(reach)) {
            if (!announceHostResolved) {
                announceHostResolved = true
                announceHost = try {
                    InetAddress.getByName(reach)
                } catch (e: IOException) {
                    // an unresolvable address is not worth failing the connection
                    null
                }
            }
            announceHost?.let { targets.add(Pair(it, port)) }
        }
        synchronized(peers) { targets.addAll(peers) }
        return targets
    }

    private fun sendToTargets(socket: DatagramSocket, bytes: ByteArray) {
        for (target in targets()) {
            try {
                socket.send(DatagramPacket(bytes, bytes.size, target.first, target.second))
            } catch (e: IOException) {
                // one unreachable peer must not stop the others
            }
        }
    }

    /**
     * The autopilot boots with its high-latency port silent, and somebody has
     * to say start. Asked on every second announce beat until the stream
     * answers — the data itself is the acknowledgement — and given up after
     * half a minute rather than shouting at a link that is not there.
     */
    private fun askForHighLatency() {
        if (!highLatency || heardTelemetry || enableAsks >= HL_ASK_MOST) return
        val socket = udpSocket ?: return
        announceBeats++
        if (announceBeats % HL_ASK_EVERY_BEATS != 0) return
        enableAsks++
        sendToTargets(socket,
            juricabi.com.telemetry.protocol.MavCommands.controlHighLatency(true, enableAsks))
    }

    // ---------------------------------------------------------------- shared

    private fun isLoopback(target: String): Boolean {
        return target == "localhost" || target.startsWith("127.") || target == "::1"
    }

    private fun closeQuietly() {
        try {
            tcpSocket?.close()
        } catch (e: IOException) {
            // ignore
        }
        try {
            if (!farewellOwnsUdp) udpSocket?.close()
        } catch (e: Exception) {
            // ignore
        }
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            // ignore
        }
        binder?.release()
    }

    /**
     * The farewell owns the socket's close. Spawning the goodbye and closing
     * the socket on the main thread a few microseconds later meant the thread
     * never won: it cannot even start before three close() calls finish. So
     * when a farewell is owed, the teardown leaves the UDP socket to it — it
     * sends, then closes, a millisecond later than the teardown would have.
     */
    @Volatile
    private var farewellOwnsUdp = false

    /** Main thread, so it must not block: closing the socket unblocks the reader. */
    override fun disconnect() {
        // A courtesy disable, so the modem is not left streaming at nobody.
        // Its own thread, because this runs on the main thread where a socket
        // write throws. UDP owes no answer, so it stays best-effort.
        if (highLatency && heardTelemetry && !farewellOwnsUdp) {
            val socket = udpSocket
            if (socket != null) {
                farewellOwnsUdp = true
                Thread({
                    try {
                        sendToTargets(socket,
                            juricabi.com.telemetry.protocol.MavCommands
                                .controlHighLatency(false, 0))
                    } catch (e: Exception) {
                        // nothing owed
                    } finally {
                        try {
                            socket.close()
                        } catch (e: Exception) {
                            // ignore
                        }
                    }
                }, "hl-farewell").start()
            }
        }
        stopping = true
        thread.interrupt()
        // Report it here rather than waiting for the thread to notice and do
        // it: the chassis's exit is latched, so whichever gets there first
        // wins and the other is a no-op — and its teardown closes the sockets,
        // which is what unblocks a thread parked in receive() or read().
        // Without this the UI sat on "Disconnecting…" for as long as the
        // thread took to come back round.
        chassis.finish()
    }
}
