package juricabi.com.telemetry.protocol

import juricabi.com.telemetry.protocol.decoder.DataDecoder
import juricabi.com.telemetry.protocol.decoder.LTMDataDecoder
import kotlin.experimental.xor


class LTMProtocol : Protocol {

    constructor(dataListener: DataDecoder.Listener) : super(LTMDataDecoder(dataListener))
    constructor(dataDecoder: DataDecoder) : super(dataDecoder)

    private var state: State = Companion.State.HEADER
    private var bufferIndex: Int = 0
    private var buffer: ByteArray = ByteArray(MAX_PACKET_SIZE)
    private lateinit var packetType: PacketType
    private var packetSize = 0
    private var checksum: Byte = 0

    companion object {
        enum class State {
            HEADER, HEADER2, TYPE, DATA
        }

        enum class PacketType {
            GPS, ATTITUDE, STATUS, ORIGIN, NAVIGATION, EXTRA
        }

        const val PACKET_MARKER = "\$T"
        const val MAX_PACKET_SIZE = 14
    }

    override fun process(data: Int) {
        when (state) {
            Companion.State.HEADER -> {
                if (data.toChar() == PACKET_MARKER[0]) {
                    packetSize = 0
                    bufferIndex = 0
                    state = Companion.State.HEADER2
                }
            }
            Companion.State.HEADER2 -> {
                if (data.toChar() == PACKET_MARKER[1]) {
                    state = Companion.State.TYPE
                }
            }
            Companion.State.TYPE -> {
                when (data.toChar()) {
                    'G' -> {
                        packetSize = 14
                        state = Companion.State.DATA
                        packetType = Companion.PacketType.GPS
                    }
                    'A' -> {
                        packetSize = 6
                        state = Companion.State.DATA
                        packetType = Companion.PacketType.ATTITUDE
                    }
                    'S' -> {
                        packetSize = 7
                        state = Companion.State.DATA
                        packetType = Companion.PacketType.STATUS
                    }
                    'O' -> {
                        packetSize = 14
                        state = Companion.State.DATA
                        packetType = Companion.PacketType.ORIGIN
                    }
                    'N' -> {
                        packetSize = 6
                        state = Companion.State.DATA
                        packetType = Companion.PacketType.NAVIGATION
                    }
                    'X' -> {
                        packetSize = 6
                        state = Companion.State.DATA
                        packetType = Companion.PacketType.EXTRA
                    }
                    else -> {
                        state = Companion.State.HEADER
                    }
                }
            }
            Companion.State.DATA -> {
                if (bufferIndex == 0) {
                    checksum = data.toByte()
                } else {
                    checksum = checksum.xor(data.toByte())
                }
                if (bufferIndex == packetSize) {
                    if (checksum.toInt() == 0) {
                        // The parser reuses buffer for the next frame. Replays
                        // retain TelemetryData, so each completed packet needs
                        // its own immutable snapshot.
                        val packet = buffer.copyOf(packetSize)
                        when (packetType) {
                            Companion.PacketType.GPS -> {
                                dataDecoder.decodeData( Protocol.Companion.TelemetryData( GPS, 0, packet ))
                            }
                            Companion.PacketType.ATTITUDE -> {
                                dataDecoder.decodeData( Protocol.Companion.TelemetryData( ATTITUDE, 0, packet ))
                            }
                            Companion.PacketType.STATUS -> {
                                dataDecoder.decodeData( Protocol.Companion.TelemetryData( FLYMODE, 0, packet ) )
                            }
                            Companion.PacketType.ORIGIN -> {
                                dataDecoder.decodeData( Protocol.Companion.TelemetryData( ORIGIN, 0, packet ) )
                            }
                            Companion.PacketType.NAVIGATION -> {
                            }
                            Companion.PacketType.EXTRA -> {
                            }
                        }
                    }
                    state = Companion.State.HEADER
                    return
                }
                buffer[bufferIndex++] = data.toByte()
            }
        }
    }
}
