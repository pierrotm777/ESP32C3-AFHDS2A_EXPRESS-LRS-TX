#pragma once
#include <Arduino.h>

/*
  RculToOutput.h
  ============================================================================
  RCUL debug mirror for RCUL Monitor (Arduino IDE plugin).

  This file is deliberately INDEPENDENT from the real RCUL transport.

  It does NOT derive from Rcul and does NOT replace:
    - RculI2cPotTx
    - RculAfhds2aXany
    - SBUS transport
    - CRSF transport
    - any other Rcul implementation

  Your normal path stays untouched:

      application data -> RcTxSerial -> real Rcul transport -> RC channel

  RculToOutput only mirrors the application payload on USB Serial:

      application data -> RculToOutput -> @RCUL ... -> RCUL Monitor

  Enable / disable globally:

      #define RCUL_TO_OUTPUT_ENABLE 1
      #include "RculToOutput.h"

  To compile the exact same project without debug:

      #define RCUL_TO_OUTPUT_ENABLE 0

  Optional serial port override, before including this file:

      #define RCUL_TO_OUTPUT_SERIAL Serial0

  Formats emitted:

      @RCUL SRC=MyRcTxSerial MODE=SW8 SW=0x80 [1000.0000]
      @RCUL SRC=MyRcTxSerial MODE=SW8_PROP SW=0x80 [1000.0000] PROP=245 [1111.0101]
      @RCUL SRC=MyRcTxSerial MODE=SW16 SW=0xA5F0 [1010.0101.1111.0000]
      @RCUL SRC=MyRcTxSerial MODE=SW16_PROP SW=0xA5F0 [1010.0101.1111.0000] PROP=245 [1111.0101]
      @RCUL SRC=MyRcTxSerial MODE=ANGLE_PROP ANGLE=2047 [0111.1111.1111] PROP=245 [1111.0101]
  ============================================================================
*/

#ifndef RCUL_TO_OUTPUT_ENABLE
  #define RCUL_TO_OUTPUT_ENABLE 1
#endif

#ifndef RCUL_TO_OUTPUT_SERIAL
  #define RCUL_TO_OUTPUT_SERIAL Serial
#endif

class RculToOutput
{
public:
#if RCUL_TO_OUTPUT_ENABLE

  static void SW8(const char *src, uint8_t sw)
  {
    Print &out = RCUL_TO_OUTPUT_SERIAL;
    out.print(F("@RCUL SRC=")); out.print(src); out.print(F(" MODE=SW8 SW=0x"));
    printHex8(out, sw);
    out.print(' ');
    printBin8(out, sw);
    out.println();
  }

  // RCUL transport order can be PROP first then SW8; this debug API keeps the
  // human-friendly argument order: switches first, proportional value second.
  static void SW8Prop(const char *src, uint8_t sw, uint8_t prop)
  {
    Print &out = RCUL_TO_OUTPUT_SERIAL;
    out.print(F("@RCUL SRC=")); out.print(src); out.print(F(" MODE=SW8_PROP SW=0x"));
    printHex8(out, sw);
    out.print(' ');
    printBin8(out, sw);
    out.print(F(" PROP="));
    out.print(prop);
    out.print(' ');
    printBin8(out, prop);
    out.println();
  }

  static void SW16(const char *src, uint16_t sw)
  {
    Print &out = RCUL_TO_OUTPUT_SERIAL;
    out.print(F("@RCUL SRC=")); out.print(src); out.print(F(" MODE=SW16 SW=0x"));
    printHex16(out, sw);
    out.print(' ');
    printBin16(out, sw);
    out.println();
  }

  static void SW16Prop(const char *src, uint16_t sw, uint8_t prop)
  {
    Print &out = RCUL_TO_OUTPUT_SERIAL;
    out.print(F("@RCUL SRC=")); out.print(src); out.print(F(" MODE=SW16_PROP SW=0x"));
    printHex16(out, sw);
    out.print(' ');
    printBin16(out, sw);
    out.print(F(" PROP="));
    out.print(prop);
    out.print(' ');
    printBin8(out, prop);
    out.println();
  }

  // ANGLE is kept on 12 bits because ANGLE+PROP uses 5 payload nibbles:
  // 3 nibbles ANGLE + 2 nibbles PROP.
  static void AngleProp(const char *src, uint16_t angle, uint8_t prop)
  {
    angle &= 0x0FFFU;

    Print &out = RCUL_TO_OUTPUT_SERIAL;
    out.print(F("@RCUL SRC=")); out.print(src); out.print(F(" MODE=ANGLE_PROP ANGLE="));
    out.print(angle);
    out.print(F(" ["));
    printBits(out, angle, 12, 4);
    out.print(F("] PROP="));
    out.print(prop);
    out.print(' ');
    printBin8(out, prop);
    out.println();
  }

#else

  static inline void SW8(const char*, uint8_t) {}
  static inline void SW8Prop(const char*, uint8_t, uint8_t) {}
  static inline void SW16(const char*, uint16_t) {}
  static inline void SW16Prop(const char*, uint16_t, uint8_t) {}
  static inline void AngleProp(const char*, uint16_t, uint8_t) {}

#endif

private:
#if RCUL_TO_OUTPUT_ENABLE

  static void printHex8(Print &out, uint8_t value)
  {
    if(value < 0x10U) out.print('0');
    out.print(value, HEX);
  }

  static void printHex16(Print &out, uint16_t value)
  {
    if(value < 0x1000U) out.print('0');
    if(value < 0x0100U) out.print('0');
    if(value < 0x0010U) out.print('0');
    out.print(value, HEX);
  }

  static void printBin8(Print &out, uint8_t value)
  {
    out.print('[');
    printBits(out, value, 8, 4);
    out.print(']');
  }

  static void printBin16(Print &out, uint16_t value)
  {
    out.print('[');
    printBits(out, value, 16, 4);
    out.print(']');
  }

  static void printBits(Print &out,
                        uint32_t value,
                        uint8_t bitCount,
                        uint8_t groupSize)
  {
    for(int8_t bit = (int8_t)bitCount - 1; bit >= 0; --bit)
    {
      out.print((value >> bit) & 0x01U);

      if(groupSize && bit && ((bit % groupSize) == 0))
        out.print('.');
    }
  }

#endif
};

// Optional macros. The TX variants stringify the RcTxSerial object name so the
// plugin can associate the runtime message with the encoder declaration/channel.
#define RCUL_TO_OUTPUT_STR2(x) #x
#define RCUL_TO_OUTPUT_STR(x)  RCUL_TO_OUTPUT_STR2(x)

#if RCUL_TO_OUTPUT_ENABLE
  #define RCUL_DEBUG_TX_SW8(src, sw)                 RculToOutput::SW8(RCUL_TO_OUTPUT_STR(src), (uint8_t)(sw))
  #define RCUL_DEBUG_TX_SW8_PROP(src, sw, prop)      RculToOutput::SW8Prop(RCUL_TO_OUTPUT_STR(src), (uint8_t)(sw), (uint8_t)(prop))
  #define RCUL_DEBUG_TX_SW16(src, sw)                RculToOutput::SW16(RCUL_TO_OUTPUT_STR(src), (uint16_t)(sw))
  #define RCUL_DEBUG_TX_SW16_PROP(src, sw, prop)     RculToOutput::SW16Prop(RCUL_TO_OUTPUT_STR(src), (uint16_t)(sw), (uint8_t)(prop))
  #define RCUL_DEBUG_TX_ANGLE_PROP(src, angle, prop) RculToOutput::AngleProp(RCUL_TO_OUTPUT_STR(src), (uint16_t)(angle), (uint8_t)(prop))

  // Backward-compatible calls without SRC.
  #define RCUL_DEBUG_SW8(sw)                 RculToOutput::SW8("?", (uint8_t)(sw))
  #define RCUL_DEBUG_SW8_PROP(sw, prop)      RculToOutput::SW8Prop("?", (uint8_t)(sw), (uint8_t)(prop))
  #define RCUL_DEBUG_SW16(sw)                RculToOutput::SW16("?", (uint16_t)(sw))
  #define RCUL_DEBUG_SW16_PROP(sw, prop)     RculToOutput::SW16Prop("?", (uint16_t)(sw), (uint8_t)(prop))
  #define RCUL_DEBUG_ANGLE_PROP(angle, prop) RculToOutput::AngleProp("?", (uint16_t)(angle), (uint8_t)(prop))
#else
  #define RCUL_DEBUG_TX_SW8(src, sw)                 do { } while(0)
  #define RCUL_DEBUG_TX_SW8_PROP(src, sw, prop)      do { } while(0)
  #define RCUL_DEBUG_TX_SW16(src, sw)                do { } while(0)
  #define RCUL_DEBUG_TX_SW16_PROP(src, sw, prop)     do { } while(0)
  #define RCUL_DEBUG_TX_ANGLE_PROP(src, angle, prop) do { } while(0)
  #define RCUL_DEBUG_SW8(sw)                         do { } while(0)
  #define RCUL_DEBUG_SW8_PROP(sw, prop)              do { } while(0)
  #define RCUL_DEBUG_SW16(sw)                        do { } while(0)
  #define RCUL_DEBUG_SW16_PROP(sw, prop)             do { } while(0)
  #define RCUL_DEBUG_ANGLE_PROP(angle, prop)         do { } while(0)
#endif
