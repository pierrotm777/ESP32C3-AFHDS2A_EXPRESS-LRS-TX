// ============================================================================
// Serial console
// ============================================================================
// Refactoring only: console-related functions were moved here from
// AF2A_C3_BTLE_v1.ino. Command names and behavior are intentionally unchanged.

static void printChannels()
{
  if(IS_BIND_IN_PROGRESS)
  {
    Serial.println("CH us: hidden during BIND");
    return;
  }

  Serial.print("CH us:");
  for(uint8_t ch = 0; ch < ACTIVE_CHANNELS; ch++)
  {
    Serial.print(' ');
    Serial.print(convert_channel_ppm(ch));
  }
  Serial.println();
}

static void printStatus()
{
  if(rfModeIsCrsf())
  {
    Serial.println();
    Serial.println("--- TX CRSF/ELRS ESP32-C3 ---");
    Serial.printf("Build       : %s\r\n", BUILD_TAG);
    Serial.printf("Input       : %s\r\n", InputSource == INPUT_SWEEP ? "SWEEP" : "PPM");
    Serial.printf("PPM chans   : %u (library max %u)\r\n", PpmChannelCount, PPM_INPUT_CHANNELS);
    Serial.printf("PPM polarity: %s (%s edge)\r\n",
                  PpmPositive ? "POS" : "NEG",
                  PpmPositive ? "RISING" : "FALLING");
    Serial.printf("Motor       : CH%u safe=%u us GPIO%d=%s state=%s%s%s\r\n",
                  MotorChannel, MOTOR_SAFE_US, PIN_MOTOR_SAFE,
                  MotorSafetySwitchActive ? "ACTIVE" : "released",
                  MotorSafetyActive ? "SAFE" : "RUN",
                  MotorSafetySwitchActive ? " GPIO" : "",
                  MotorSafetyPpmLost ? " PPM_LOST" : "");
    Serial.printf("OLED        : %s (CRSF screen not added yet)\r\n",
                  oled_enabled ? (oled_ok ? "ON" : "ON/ERROR") : "OFF");
    xany1PrintStatus();
    xany2PrintStatus();
    pcfSw8PrintStatus();
    btPrintStatus();
    crsfPrintStatus();
    return;
  }

  Serial.println();
  Serial.println("--- TX MPM AFHDS2A ESP32-C3 ---");
  Serial.printf("Build       : %s\r\n", BUILD_TAG);
  Serial.printf("TX ID       : %08lX\r\n", (unsigned long)MProtocol_id);
  Serial.printf("RX num      : %u\r\n", RX_num);
  Serial.printf("Input       : %s\r\n", InputSource == INPUT_SWEEP ? "SWEEP" : "PPM");
  Serial.printf("PPM chans   : %u (library max %u)\r\n", PpmChannelCount, PPM_INPUT_CHANNELS);
  Serial.printf("PPM polarity: %s (%s edge)\r\n",
                PpmPositive ? "POS" : "NEG",
                PpmPositive ? "RISING" : "FALLING");
  Serial.printf("PPM ISR     : %lu  last dt=%lu us\r\n",
                (unsigned long)Cppm32.rxIsrCount(),
                (unsigned long)Cppm32.rxLastDtUs());
  if(InputSource == INPUT_PPM)
  {
    if(PpmFrameSeen)
      Serial.printf("PPM signal  : %s age=%lu ms\r\n",
                    ((uint32_t)(millis() - LastPpmFrameMs) <= PPM_FAILSAFE_MS) ? "OK" : "LOST",
                    (unsigned long)(millis() - LastPpmFrameMs));
    else
      Serial.println("PPM signal  : LOST (no frame yet)");
  }
  else
    Serial.println("PPM signal  : N/A (SWEEP mode)");
  Serial.printf("Motor       : CH%u safe=%u us GPIO%d=%s state=%s%s%s\r\n",
                MotorChannel, MOTOR_SAFE_US, PIN_MOTOR_SAFE,
                MotorSafetySwitchActive ? "ACTIVE" : "released",
                MotorSafetyActive ? "SAFE" : "RUN",
                MotorSafetySwitchActive ? " GPIO" : "",
                MotorSafetyPpmLost ? " PPM_LOST" : "");
  Serial.printf("RF failsafe : CH%u=%u us, others=HOLD, program=%s\r\n",
                MotorChannel, MOTOR_SAFE_US, IS_FAILSAFE_VALUES_on ? "PENDING" : "WAIT SLOT");
  Serial.printf("Bind        : %s\r\n", IS_BIND_IN_PROGRESS ? "YES" : "NO");
  Serial.printf("RF state    : %s  RX_ID=%s\r\n", rfLinkStateText(), receiverIdLooksValid() ? "stored" : "none");
  Serial.printf("A7105       : %s\r\n", RadioOk ? "OK" : "ERROR");
  Serial.printf("RF scheduler: %s  CPU=%lu MHz\r\n", RfUseEspTimer ? "ESP_TIMER" : "LOOP fallback", (unsigned long)getCpuFrequencyMhz());
  Serial.printf("OLED        : %s\r\n", oled_enabled ? (oled_ok ? "ON" : "ON/ERROR") : "OFF");
  xany1PrintStatus();
  xany2PrintStatus();
  pcfSw8PrintStatus();
  Serial.printf("TLM RX      : %s (option=0x%02X, FW telemetry bit kept ON)\r\n",
                TelemetryRxEnabled ? "ON" : "OFF", option);
  btPrintStatus();
  Serial.printf("Hop index   : %u\r\n", hopping_frequency_no);
  Serial.printf("Telemetry   : %s (FW) LQI=%u%% ERR=%u%% RX_RSSI=%d TX_RSSI=%u V1=%u V2=%u\r\n",
                TelemetryRxEnabled ? "ON" : "OFF",
                rxLqiPercent(), RX_LQI, (int8_t)RX_RSSI, TX_RSSI, v_lipo1, v_lipo2);
  telemetryAFHDS2APrintStatus();
  btPrintStatus();
  printChannels();

}

static void helpPause()
{
  // Let the serial driver empty its TX buffer between help sections.
  // The RF scheduler continues independently through esp_timer.
  Serial.flush();
  delay(1);
}

static void printHelpCommon()
{
  Serial.println();
  Serial.printf("Configuration commands - RF=%s:\r\n",
                rfModeIsAfhds2a() ? "AFHDS2A" : "CRSF/ELRS");
  Serial.println("  ?             Status");
  Serial.println("  h             Configuration help");
  Serial.println("  hf            Full help (+ diagnostics/debug)");
  Serial.println("  rf             Display active RF backend");
  Serial.println("  rf ds2a        Select/save AFHDS2A/A7105, then reboot");
  Serial.println("  rf elrs        Select/save CRSF/ExpressLRS, then reboot");
  Serial.println("  ppm           Return to PPM input");
  Serial.println("  ppm pol       Display saved PPM polarity");
  Serial.println("  ppm pos/+     Save positive PPM (rising edge), then reboot");
  Serial.println("  ppm neg/-     Save negative PPM (falling edge), then reboot");
  Serial.println("  oled on/off   Enable/disable OLED + save preference");
  Serial.println("  oled          Display OLED state");
  helpPause();

  Serial.println("  xany1          Display XANY1 SW8 status");
  Serial.println("  xany1 on/off   Enable/disable XANY1 + save preference");
  Serial.println("  xany1 ch5      Set/save XANY1 output channel");
  Serial.println("  xany1 sw 5A    Manual XANY1 SW8 test byte 00..FF");
  Serial.println("  xany2          Display XANY2 SW8+PROP status");
  Serial.println("  xany2 on/off   Enable/disable XANY2 + save preference");
  Serial.println("  xany2 ch6      Set/save XANY2 output channel");
  Serial.println("  xany2 sw 5A    Manual XANY2 SW8 test byte 00..FF");
  Serial.println("  xany2 prop 128 Manual XANY2 PROP byte 0..255");
  Serial.println("  pcf            Display PCF8574(A) SW8 input status (XANY1)");
  Serial.println("  pcf scan       Re-scan PCF8574A 0x38..3F / PCF8574 0x20..27");
  helpPause();
}

static void printHelpAfhds2a()
{
  Serial.println("AFHDS2A / A7105 commands:");
  Serial.println("  id            Display TX/RX IDs");
  Serial.println("  txid          Display saved TX ID");
  Serial.println("  txid new      Create/save a new random TX ID (rebind required)");
  Serial.println("  txid auto     Restore/save board eFuse-based TX ID");
  Serial.println("  txid 1234ABCD Set/save a manual 32-bit hexadecimal TX ID");
  Serial.println("  bind          Start AFHDS2A bind (30 s max)");
  Serial.println("  fs            Display AFHDS2A receiver failsafe programming");
  Serial.println("  fs send       Re-arm failsafe programming packet");
  Serial.println("  tlm on/off    Enable/disable telemetry RX + save preference");
  Serial.println("  tlm           Display telemetry RX state");
  Serial.println("  bt on/off     Enable/disable BT LE + save preference");
  Serial.println("  bt            Display BT LE state");
  helpPause();
}

static void printHelpCrsf()
{
  Serial.println("CRSF / ELRS commands:");
  Serial.println("  crsf          Display CRSF/ELRS UART/channel/link status");
  Serial.println("  bt on/off     Enable/disable BT LE + save preference");
  Serial.println("  bt            Display BT LE state");
  helpPause();
}

static void printHelpMini()
{
  printHelpCommon();

  if(rfModeIsAfhds2a())
    printHelpAfhds2a();
  else
    printHelpCrsf();
}

static void printHelpFull()
{
  printHelpMini();

  Serial.println();
  Serial.println("Common diagnostics / debug commands:");
  Serial.println("  sweep     Temporary internal CH1..CH14 sweep (test only)");
  Serial.println("  d         Debug On/Off");
  Serial.println("  ch        Display CH1..CH14 in us");
  helpPause();

  if(rfModeIsAfhds2a())
  {
    Serial.println("AFHDS2A / A7105 diagnostics:");
    Serial.println("  blog      Display last captured bind log");
    Serial.println("  tlog      Display AFHDS2A telemetry log");
    Serial.println("  tclear    Clear AFHDS2A telemetry log");
    Serial.println("  btsimu    Toggle BLE AFHDS2A simulator");
    Serial.println("  btsimu on/off/reset  Control AFHDS2A BLE simulator");
    Serial.println("  hop       Display 16 hopping channels");
    Serial.println("  rflog     Display ESP RF timer speed/jitter/runtime log");
    Serial.println("  rfclear   Clear ESP RF timer log");
    helpPause();
  }
  else
  {
    Serial.println("CRSF / ELRS diagnostics:");
    Serial.println("  crsf      Display UART, TX frame counter, channels and link statistics");
    Serial.println("  btsimu    Toggle BLE CRSF simulator");
    Serial.println("  btsimu on/off/reset  Control CRSF BLE simulator");
    helpPause();
  }
}

static void setPpmPolarityAndRestart(bool Positive)
{
  if(PpmPositive == Positive)
  {
    Serial.printf("[PPM] polarity already %s (%s edge), preference unchanged\r\n",
                  PpmPositive ? "POS" : "NEG",
                  PpmPositive ? "RISING" : "FALLING");
    return;
  }

  PpmPositive = Positive;
  prefs.putBool("ppmpos", PpmPositive);

  // ESP32_PPM is initialized once at boot. Avoid re-attaching/changing the RX
  // edge while the RF stack is live: save the setting and restart cleanly.
  Serial.printf("[PPM] polarity saved: %s (%s edge) - rebooting...\r\n",
                PpmPositive ? "POS" : "NEG",
                PpmPositive ? "RISING" : "FALLING");
  Serial.flush();
  delay(100);
  ESP.restart();
}

static void processConsole()
{
  static String line;

  while(Serial.available())
  {
    const char c = (char)Serial.read();
    if(c == '\r')
      continue;

    if(c != '\n')
    {
      if(line.length() < 60)
        line += c;
      continue;
    }

    line.trim();
    line.toLowerCase();

    if(line == "?" )
      printStatus();
    else if(line == "h" || line == "help")
      printHelpMini();
    else if(line == "hf" || line == "help full" || line == "helpfull" || line == "hfull")
      printHelpFull();
    else if(line == "rf")
      rfPrintMode();
    else if(line == "rf afhds2a" || line == "rf af2a")
      rfSetModeAndRestart(RF_MODE_AFHDS2A);
    else if(line == "rf elrs" || line == "rf crsf")
      rfSetModeAndRestart(RF_MODE_CRSF);
    else if(line == "sweep")
    {
      InputSource = INPUT_SWEEP;
      Serial.println("Input=SWEEP (14 channels)");
    }
    else if(line == "ppm")
    {
      InputSource = INPUT_PPM;
      PpmFrameSeen = false;
      PpmChannelCount = 0;
      LastPpmFrameMs = 0;
      centerAllChannels();
      applyMotorSafety();
      Serial.printf("Input=PPM (%s) - CH%u failsafe active until valid PPM\r\n",
                    PpmPositive ? "POS" : "NEG", MotorChannel);
    }
    else if(line == "ppm pol" || line == "ppm polarity")
    {
      Serial.printf("[PPM] polarity=%s (%s edge), saved in Preferences\r\n",
                    PpmPositive ? "POS" : "NEG",
                    PpmPositive ? "RISING" : "FALLING");
    }
    else if(line == "ppm pos" || line == "ppm +" || line == "ppm positive")
      setPpmPolarityAndRestart(true);
    else if(line == "ppm neg" || line == "ppm -" || line == "ppm negative")
      setPpmPolarityAndRestart(false);
    else if(line == "bind")
    {
      if(rfModeIsAfhds2a())
        startBind();
      else
        Serial.println("[CRSF] AFHDS2A bind command unavailable in CRSF mode");
    }
    else if(line == "crsf")
      crsfPrintStatus();
    else if(line == "fs" || line == "failsafe")
      printAfhds2aFailsafeStatus();
    else if(line == "fs send" || line == "failsafe send")
    {
      if(IS_BIND_IN_PROGRESS)
        Serial.println("[FAILSAFE] bind in progress - programming will resume after bind");
      else
      {
        armAfhds2aFailsafeProgramming();
        Serial.println("[FAILSAFE] armed - packet 0x56 will be sent at the next AFHDS2A failsafe slot (<= about 6 s)");
      }
    }
    else if(line == "blog")
    {
      if(BindTimerActive)
        Serial.println("[BINDLOG] bind still running; log will be dumped at the end");
      else
        bindLogDump();
    }
    else if(line == "tlog")
      telemetryAFHDS2APrintLog();
    else if(line == "tclear")
    {
      telemetryAFHDS2AReset();
      Serial.println("[TLM] log cleared");
    }
    else if(line == "tlm on")
    {
      TelemetryRxEnabled = true;
      prefs.putBool("tlmrx", TelemetryRxEnabled);
      Serial.println("[TLM] ON saved - AFHDS2A RX telemetry windows enabled (option remains 0x80 / 50 Hz)");
    }
    else if(line == "tlm off")
    {
      TelemetryRxEnabled = false;
      prefs.putBool("tlmrx", TelemetryRxEnabled);
      Serial.println("[TLM] OFF saved - AFHDS2A RX telemetry windows disabled; TX/sticks continue (option remains 0x80 / 50 Hz)");
    }
    else if(line == "tlm")
    {
      Serial.printf("[TLM] %s - option=0x%02X\r\n", TelemetryRxEnabled ? "ON" : "OFF", option);
    }
    else if(line == "bt" || line == "btle")
      btPrintStatus();
    else if(line == "bt on" || line == "btle on")
      btSetEnabled(true);
    else if(line == "bt off" || line == "btle off")
      btSetEnabled(false);
    else if(line == "btsimu")
      btSimuSet(!btSimuIsEnabled());
    else if(line == "btsimu on")
      btSimuSet(true);
    else if(line == "btsimu off")
      btSimuSet(false);
    else if(line == "btsimu reset")
      btSimuReset();
    else if(line == "rflog")
      rfTimerPrintLog();
    else if(line == "rfclear")
    {
      rfTimerResetLog();
      Serial.println("[RF-TIMER] log cleared");
    }
    else if(line == "d")
    {
      DebugIsOn = !DebugIsOn;
      Serial.printf("Debug=%s\r\n", DebugIsOn ? "ON" : "OFF");
    }
    else if(line == "ch")
      printChannels();
    else if(line == "hop")
    {
      Serial.print("HOP:");
      for(uint8_t i = 0; i < 16; i++)
      {
        Serial.print(' ');
        if(hopping_frequency[i] < 0x10) Serial.print('0');
        Serial.print(hopping_frequency[i], HEX);
      }
      Serial.println();
    }
    else if(line == "oled on")
    {
      oled_enabled = true;
      prefs.putBool("oled", oled_enabled);
      oledInit();
    }
    else if(line == "oled off")
    {
      oledDisable();
      prefs.putBool("oled", oled_enabled);
    }
    else if(line == "oled")
    {
      Serial.printf("[OLED] %s\r\n", oled_enabled ? (oled_ok ? "ON" : "ON/ERROR") : "OFF");
    }
    else if(line == "xany1")
    {
      xany1PrintStatus();
    }
    else if(line == "xany1 on")
    {
      xany1SetEnabled(true);
      Serial.printf("XANY1=ON saved (CH%u)\r\n", xany1GetChannel());
    }
    else if(line == "xany1 off")
    {
      xany1SetEnabled(false);
      Serial.printf("XANY1=OFF saved (CH%u released to PPM/SWEEP)\r\n", xany1GetChannel());
    }
    else if(line.startsWith("xany1 ch"))
    {
      const int ch = line.substring(8).toInt();
      if(ch < 1 || ch > ACTIVE_CHANNELS)
        Serial.printf("Usage: xany1 ch1..ch%u\r\n", ACTIVE_CHANNELS);
      else if(xany1SetChannel((uint8_t)ch))
        Serial.printf("XANY1 SW8 channel=CH%u saved; repeat=2\r\n", xany1GetChannel());
      else
        Serial.printf("XANY1 channel rejected (motor CH%u or XANY2 CH%u conflict)\r\n",
                      MotorChannel, xany2GetChannel());
    }
    else if(line.startsWith("xany1 sw "))
    {
      String hex = line.substring(9);
      hex.trim();
      if(hex.length() == 0 || hex.length() > 2)
        Serial.println("Usage: xany1 sw 00..FF");
      else
      {
        char *endp = nullptr;
        const unsigned long v = strtoul(hex.c_str(), &endp, 16);
        if(endp == hex.c_str() || *endp != '\0' || v > 0xFF)
          Serial.println("Usage: xany1 sw 00..FF");
        else
        {
          xany1SetSw8((uint8_t)v);
          Serial.printf("XANY1 SW8=0x%02X (manual; PCF may overwrite when present)\r\n",
                        xany1GetSw8());
        }
      }
    }
    else if(line == "xany2")
    {
      xany2PrintStatus();
    }
    else if(line == "xany2 on")
    {
      xany2SetEnabled(true);
      Serial.printf("XANY2=ON saved (SW8+PROP CH%u)\r\n", xany2GetChannel());
    }
    else if(line == "xany2 off")
    {
      xany2SetEnabled(false);
      Serial.printf("XANY2=OFF saved (CH%u released to PPM/SWEEP)\r\n", xany2GetChannel());
    }
    else if(line.startsWith("xany2 ch"))
    {
      const int ch = line.substring(8).toInt();
      if(ch < 1 || ch > ACTIVE_CHANNELS)
        Serial.printf("Usage: xany2 ch1..ch%u\r\n", ACTIVE_CHANNELS);
      else if(xany2SetChannel((uint8_t)ch))
        Serial.printf("XANY2 SW8+PROP channel=CH%u saved; repeat=2\r\n", xany2GetChannel());
      else
        Serial.printf("XANY2 channel rejected (motor CH%u or XANY1 CH%u conflict)\r\n",
                      MotorChannel, xany1GetChannel());
    }
    else if(line.startsWith("xany2 sw "))
    {
      String hex = line.substring(9);
      hex.trim();
      if(hex.length() == 0 || hex.length() > 2)
        Serial.println("Usage: xany2 sw 00..FF");
      else
      {
        char *endp = nullptr;
        const unsigned long v = strtoul(hex.c_str(), &endp, 16);
        if(endp == hex.c_str() || *endp != '\0' || v > 0xFF)
          Serial.println("Usage: xany2 sw 00..FF");
        else
        {
          xany2SetSw8((uint8_t)v);
          Serial.printf("XANY2 SW8=0x%02X\r\n", xany2GetSw8());
        }
      }
    }
    else if(line.startsWith("xany2 prop "))
    {
      String val = line.substring(11);
      val.trim();
      char *endp = nullptr;
      const unsigned long v = strtoul(val.c_str(), &endp, 0);
      if(endp == val.c_str() || *endp != '\0' || v > 255)
        Serial.println("Usage: xany2 prop 0..255 (or 0x00..0xFF)");
      else
      {
        xany2SetProp((uint8_t)v);
        Serial.printf("XANY2 PROP=%u (0x%02X)\r\n", xany2GetProp(), xany2GetProp());
      }
    }
    else if(line == "pcf")
      pcfSw8PrintStatus();
    else if(line == "pcf scan")
      pcfSw8Scan();
    else if(line == "txid")
    {
      Serial.printf("TX ID=%08lX (saved)  board-auto=%08lX\r\n",
                    (unsigned long)MProtocol_id,
                    (unsigned long)makeBoardTxId());
    }
    else if(line == "txid new")
    {
      const uint32_t id = makeRandomTxId(MProtocol_id);
      applyTxId(id, true);
      Serial.printf("[TXID] NEW=%08lX saved - REBIND REQUIRED\r\n", (unsigned long)MProtocol_id);
    }
    else if(line == "txid auto")
    {
      if(applyTxId(makeBoardTxId(), true))
        Serial.printf("[TXID] AUTO=%08lX saved - REBIND REQUIRED\r\n", (unsigned long)MProtocol_id);
      else
        Serial.printf("[TXID] AUTO=%08lX already active\r\n", (unsigned long)MProtocol_id);
    }
    else if(line.startsWith("txid "))
    {
      String hex = line.substring(5);
      hex.trim();
      if(hex.startsWith("0x"))
        hex.remove(0, 2);

      if(hex.length() == 0 || hex.length() > 8)
      {
        Serial.println("Usage: txid new | txid auto | txid 1234ABCD");
      }
      else
      {
        char *endp = nullptr;
        const unsigned long v = strtoul(hex.c_str(), &endp, 16);
        if(endp == hex.c_str() || *endp != '\0' || v == 0 || v == 0xFFFFFFFFUL)
          Serial.println("Usage: txid new | txid auto | txid 1234ABCD");
        else
        {
          if(applyTxId((uint32_t)v, true))
            Serial.printf("[TXID] SET=%08lX saved - REBIND REQUIRED\r\n", (unsigned long)MProtocol_id);
          else
            Serial.printf("[TXID] SET=%08lX already active\r\n", (unsigned long)MProtocol_id);
        }
      }
    }
    else if(line == "id")
    {
      Serial.printf("TX=%02X %02X %02X %02X  RX=%02X %02X %02X %02X\r\n",
                    rx_tx_addr[0], rx_tx_addr[1], rx_tx_addr[2], rx_tx_addr[3],
                    rx_id[0], rx_id[1], rx_id[2], rx_id[3]);
    }
    else if(line.length())
      Serial.println("Unknown command. Type h (config) or hf (full)");

    line = "";
  }
}
