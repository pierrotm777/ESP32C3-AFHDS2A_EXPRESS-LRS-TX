// ============================================================================
// RF backend selector
// ============================================================================
// The selected backend is saved in the same Preferences namespace as the rest
// of the transmitter configuration. Switching always reboots: this guarantees
// that A7105/AFHDS2A timers and CRSF UART are never hot-swapped while running.

#include "RF_Main.h"

uint8_t RfModeCurrent = RF_MODE_DEFAULT;

void rfLoadPreference(void)
{
  uint8_t Saved = prefs.getUChar("rfmode", RF_MODE_DEFAULT);
  if(Saved != RF_MODE_AFHDS2A && Saved != RF_MODE_CRSF)
  {
    Saved = RF_MODE_DEFAULT;
    prefs.putUChar("rfmode", Saved);
  }
  RfModeCurrent = Saved;
}

void rfPrintMode(void)
{
  Serial.printf("[RF] backend=%s\r\n",
                rfModeIsAfhds2a() ? "AFHDS2A/A7105" : "CRSF/EXPRESS-LRS");
}

void rfSetModeAndRestart(uint8_t Mode)
{
  if(Mode != RF_MODE_AFHDS2A && Mode != RF_MODE_CRSF)
    return;

  if(RfModeCurrent == Mode)
  {
    rfPrintMode();
    Serial.println("[RF] already selected");
    return;
  }

  prefs.putUChar("rfmode", Mode);
  Serial.printf("[RF] saved=%s - rebooting...\r\n",
                Mode == RF_MODE_AFHDS2A ? "AFHDS2A/A7105" : "CRSF/EXPRESS-LRS");
  Serial.flush();
  delay(100);
  ESP.restart();
}
