#pragma once

// ============================================================================
// A7105 / AFHDS2A configuration and original MPM globals
// ============================================================================
// Refactoring only: these definitions were moved out of AF2A_C3_BTLE_v1.ino.
// Values and behavior are intentionally unchanged.

#include <Arduino.h>

// Enable the original MPM AFHDS2A receiver-failsafe programming path.
// The receiver stores these values and applies them itself after RF loss.
#define FAILSAFE_ENABLE

// A7105 uses a 3-wire SPI bus: one bidirectional SDIO line.
// There is deliberately NO separate MISO pin.
static constexpr int A7105_SDIO_PIN = 8;  // MOSI/SDIO bidirectional
static constexpr int A7105_SCK_PIN  = 4;
static constexpr int A7105_CSN_PIN  = 7;

// Original MPM compatibility layer. It uses the pin constants above.
#include "MPM_ESP32C3_Compat.h"

// ============================================================================
// Original MPM globals required by AFHDS2A_a7105.ino / A7105_SPI.ino
// Names are intentionally kept identical for easy comparison/debug.
// ============================================================================
#define NUM_CHN 16

// Original MPM failsafe encoding: 0=no pulses, 2047=hold. AFHDS2A maps
// both special values to 0x0FFF in the receiver programming packet.
#ifndef FAILSAFE_CHANNEL_HOLD
  #define FAILSAFE_CHANNEL_HOLD 2047U
#endif
#ifndef FAILSAFE_CHANNEL_NOPULSES
  #define FAILSAFE_CHANNEL_NOPULSES 0U
#endif
uint16_t Failsafe_data[NUM_CHN];

uint32_t MProtocol_id = 0;
uint16_t Channel_data[NUM_CHN];

uint8_t packet[50];

// Original MPM native AFHDS2A telemetry forwarding buffer.
// Required by AFHDS2A_FW_TELEMETRY (MPM uses 32 bytes).
#define TELEMETRY_BUFFER_SIZE 32
uint8_t packet_in[TELEMETRY_BUFFER_SIZE];

uint8_t rx_tx_addr[5];
uint8_t rx_id[5];
uint8_t phase = 0;
uint8_t bind_phase = 0;
uint8_t packet_count = 0;
uint8_t packet_sent = 0;
uint8_t hopping_frequency[50];
uint8_t hopping_frequency_no = 0;
uint8_t prev_power = 0xFD;

uint8_t protocol = PROTO_AFHDS2A;
uint8_t sub_protocol = PWM_IBUS;
uint8_t RX_num = 0;
uint8_t option = 0x80;              // bit7=FW telemetry ON, low7=0 -> 50 Hz servo setting packet
uint8_t protocol_flags = 0;
uint8_t protocol_flags2 = 0;

// Identity mapping: PPM CH1 remains AFHDS2A CH1, etc.
// Element 16 is intentional: original AFHDS2A code performs one harmless
// lookup before replacing CH17 with RX_LQI.
uint8_t CH_AETR[17] = {
  0, 1, 2, 3, 4, 5, 6, 7,
  8, 9, 10, 11, 12, 13, 14, 15, 0
};

// Original AFHDS2A telemetry variable names.
uint8_t RX_LQI = 0;
uint8_t RX_RSSI = 0;
uint8_t TX_RSSI = 0;
uint8_t v_lipo1 = 0;
uint8_t v_lipo2 = 0;
uint8_t telemetry_link = 0;

// Runtime control: controls only the normal AFHDS2A receive telemetry window.
// The selected ON/OFF state is saved in Preferences. option stays at 0x80 so
// FW telemetry format and the receiver servo setting (50 Hz) remain unchanged.
bool TelemetryRxEnabled = false;

