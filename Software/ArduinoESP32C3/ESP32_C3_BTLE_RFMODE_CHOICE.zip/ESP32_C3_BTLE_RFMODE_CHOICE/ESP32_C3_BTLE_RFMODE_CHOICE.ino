#include <ESP32_PPM.h>
#include <Arduino.h>
#include <Wire.h>
#include <U8g2lib.h>
#include <Preferences.h>
#include <elapsedMillis.h>

/* Pin out ESP32 C3 Oled 

TX
RX
0     PIN_MOTOR_SAFE
1     PPM_IN_PIN
2     CRSF_RX_PIN
3     PIN_LED
4
5     SDA_PIN
6     SCL_PIN
7
8
9     CRSF_TX_PIN
10    PIN_BIND

*/

float VERSION = 1.0f;
static const char* BUILD_TAG = "1.19-CRSF1-BTSIM-RFMODE";

// ============================================================================
// ESP32-C3 Mini pinout
// ============================================================================
// OLED integrated on this ESP32-C3 Mini board.
// Confirmed wiring: SDA=GPIO5, SCL=GPIO6.
static constexpr int SDA_PIN = 5;
static constexpr int SCL_PIN = 6;

// Shared OLED + PCF8574(A) I2C bus. 100 kHz is the conservative PCF8574 rate.
// We can test 400 kHz later by changing this single constant.
static constexpr uint32_t I2C_BUS_HZ = 100000UL;

static constexpr int PPM_IN_PIN = 1;
static constexpr int PIN_BIND   = 10;     // Active LOW
static constexpr int PIN_LED    = 3;
static constexpr int PIN_MOTOR_SAFE = 0;  // Active LOW, forces motor channel to 1000 us

static constexpr uint32_t DEFAULT_BAUD = 115200;

// OLED
static constexpr uint8_t OLED_ADDR = 0x3C;
static constexpr int OLED_W = 128;
static constexpr int OLED_H = 64;

#include "RF_Config.h"
#include "RF_Main.h"
#include "AFHDS2A_Config.h"
#include "A7105_Main.h"
#include "AFHDS2A_Bind.h"
#include "Telemetry_AFHDS2A.h"
#include "BT_LE.h"
#include "CRSF_Main.h"
#include "Xany.h"
#include "pcf8574.h"

Preferences prefs;

// Suppress setup chatter. Console commands remain fully verbose after setup.
static bool StartupConsoleQuiet = true;

static bool oled_enabled = false;   // Saved in Preferences; defaults OFF on first boot
static bool oled_ok = false;
static uint32_t oled_boot_ms = 0;
U8G2_SSD1306_72X40_ER_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

elapsedMillis oledInfoTimer;
uint8_t oledInfo = 0;

// ============================================================================
// PPM input + SWEEP debug mode
// ============================================================================
enum InputMode : uint8_t {
  INPUT_PPM = 0,
  INPUT_SWEEP = 1
};

// Normal/default source is PPM IN. SWEEP remains a temporary bench/test mode
// selected from the console; every reboot returns to PPM IN so motor failsafe is
// active immediately if the transmitter PPM signal is missing.
static InputMode InputSource = INPUT_PPM;
static constexpr uint8_t ACTIVE_CHANNELS = 14;

// Motor safety. CH3 is the default motor channel. In PPM mode, loss of a valid
// PPM frame forces CH3 to 1000 us. GPIO0 can also force CH3 to 1000 us at any
// time with a switch to GND. Xany_SW8.ino already prevents XANY1 from using
// the selected motor channel.
static uint8_t MotorChannel = 3;
static constexpr uint16_t MOTOR_SAFE_US = 1000;
static constexpr uint32_t PPM_FAILSAFE_MS = 100UL;
static bool PpmFrameSeen = false;
static bool MotorSafetyActive = false;
static bool MotorSafetySwitchActive = false;
static bool MotorSafetyPpmLost = false;

// RCUL XANY bridges + PCF8574(A) input live in separate Arduino tabs.
// Their configuration/API declarations are now in Xany.h and pcf8574.h.

// Serial console is implemented in SerialConsole.ino.
static void processConsole(void);
static void printChannels(void);

// ESP32_PPM v1.0 library supplied with this project.
// The library exposes the global object Cppm32.
// Current library RX implementation is limited to 8 physical PPM channels.
// SWEEP mode still drives all 14 AFHDS2A channels for RF debugging.
static constexpr uint8_t PPM_INPUT_CHANNELS = 8;
static bool PpmPositive = true; // Preferences: true=positive/rising, false=negative/falling
static uint8_t PpmChannelCount = 0;
static uint32_t LastPpmFrameMs = 0;

static uint16_t SweepUs = 1000;
static int16_t SweepStepUs = 5;
static uint32_t LastSweepMs = 0;

static bool DebugIsOn = false;

static uint32_t LastDebugMs = 0;
// Forward declarations: original names are implemented in MPM tabs.
uint16_t AFHDS2A_callback();
void AFHDS2A_init();
uint8_t A7105_Reset();

// ============================================================================
// MPM EEPROM compatibility backed by ESP32 Preferences
// ============================================================================
uint8_t eeprom_read_byte(EE_ADDR address)
{
  char key[9];
  snprintf(key, sizeof(key), "e%03u", (unsigned)address);
  return prefs.getUChar(key, 0xFF);
}

void eeprom_write_byte(EE_ADDR address, uint8_t value)
{
  char key[9];
  snprintf(key, sizeof(key), "e%03u", (unsigned)address);
  prefs.putUChar(key, value);
}

// ============================================================================
// Channel conversion: PPM microseconds -> original MPM Channel_data 0..2047
// This is the inverse of MPM convert_channel_ppm().
// ============================================================================
static uint16_t ppmUsToMpmChannel(int us)
{
  if(us < 860) us = 860;
  if(us > 2140) us = 2140;

  uint32_t value = ((uint32_t)(us - 860) * 8U + 2U) / 5U;
  if(value > 2047U) value = 2047U;
  return (uint16_t)value;
}

// ============================================================================
// AFHDS2A receiver failsafe programming
// ============================================================================
// The original MPM AFHDS2A code sends packet 0x56 when FAILSAFE_VALUES_on is
// set. It checks the flag every 1569 packets (~6.04 s with the proven RF
// scheduler). Re-arming after each send makes the programming robust even when
// the receiver is powered after the transmitter.
static constexpr uint32_t AFHDS2A_FAILSAFE_REARM_MS = 3000UL;
static uint32_t LastFailsafeArmMs = 0;

static void initAfhds2aFailsafeValues()
{
  for(uint8_t ch = 0; ch < NUM_CHN; ch++)
    Failsafe_data[ch] = FAILSAFE_CHANNEL_HOLD;

  // Boat safety default: motor CH3 -> minimum/stop.
  if(MotorChannel >= 1 && MotorChannel <= NUM_CHN)
    Failsafe_data[MotorChannel - 1] = ppmUsToMpmChannel(MOTOR_SAFE_US);

  FAILSAFE_VALUES_off;
  LastFailsafeArmMs = millis();
}

static void armAfhds2aFailsafeProgramming()
{
  if(!RadioOk || IS_BIND_IN_PROGRESS)
    return;

  FAILSAFE_VALUES_on;
  LastFailsafeArmMs = millis();
}

static void processAfhds2aFailsafeProgramming()
{
  if(!RadioOk || IS_BIND_IN_PROGRESS)
    return;

  if(!IS_FAILSAFE_VALUES_on &&
     (uint32_t)(millis() - LastFailsafeArmMs) >= AFHDS2A_FAILSAFE_REARM_MS)
  {
    armAfhds2aFailsafeProgramming();
  }
}

static void printAfhds2aFailsafeStatus()
{
  Serial.printf("[FAILSAFE] MPM=FAILSAFE_ENABLE  AFHDS2A RX programming=ON  pending=%s\r\n",
                IS_FAILSAFE_VALUES_on ? "YES" : "NO");
  Serial.printf("[FAILSAFE] CH%u=%u us; all other channels=HOLD\r\n",
                MotorChannel, MOTOR_SAFE_US);
  Serial.println("[FAILSAFE] Packet 0x56 is re-armed automatically; RX applies stored values after RF loss.");
}

static void centerAllChannels()
{
  for(uint8_t ch = 0; ch < NUM_CHN; ch++)
    Channel_data[ch] = CHANNEL_MID;
}

static void updateSweep()
{
  if((uint32_t)(millis() - LastSweepMs) < 20UL)
    return;

  LastSweepMs = millis();

  int next = (int)SweepUs + SweepStepUs;
  if(next >= 2000)
  {
    next = 2000;
    SweepStepUs = -abs(SweepStepUs);
  }
  else if(next <= 1000)
  {
    next = 1000;
    SweepStepUs = abs(SweepStepUs);
  }
  SweepUs = (uint16_t)next;

  const uint16_t mpm = ppmUsToMpmChannel(SweepUs);
  for(uint8_t ch = 0; ch < ACTIVE_CHANNELS; ch++)
    Channel_data[ch] = mpm;

  // CH15 and CH16 remain centered. AFHDS2A directly transports CH1..CH14.
  Channel_data[CH15] = CHANNEL_MID;
  Channel_data[CH16] = CHANNEL_MID;
}

static void updatePpm()
{
  // ESP32_PPM::rxAvailable() returns true once for each complete PPM frame.
  if(!Cppm32.rxAvailable())
    return;

  LastPpmFrameMs = millis();
  PpmFrameSeen = true;
  PpmChannelCount = Cppm32.rxChannels();
  if(PpmChannelCount > ACTIVE_CHANNELS)
    PpmChannelCount = ACTIVE_CHANNELS;

  for(uint8_t ch = 0; ch < ACTIVE_CHANNELS; ch++)
  {
    uint16_t us = 1500;
    if(ch < PpmChannelCount)
      us = Cppm32.rxRead(ch + 1);   // ESP32_PPM channels are numbered 1..N

    Channel_data[ch] = ppmUsToMpmChannel(us);
  }

  // ESP32_PPM v1.0 currently supports 8 physical RX channels.
  // Therefore CH9..CH14 remain centered in PPM mode, while SWEEP exercises
  // all 14 AFHDS2A channels.
  Channel_data[CH15] = CHANNEL_MID;
  Channel_data[CH16] = CHANNEL_MID;
}

static void applyMotorSafety()
{
  if(MotorChannel < 1 || MotorChannel > ACTIVE_CHANNELS)
    return;

  const bool switchActive = (digitalRead(PIN_MOTOR_SAFE) == LOW);

  bool ppmLost = false;
  if(InputSource == INPUT_PPM)
  {
    const bool channelPresent = PpmFrameSeen && (PpmChannelCount >= MotorChannel);
    const bool frameFresh = PpmFrameSeen && ((uint32_t)(millis() - LastPpmFrameMs) <= PPM_FAILSAFE_MS);
    ppmLost = !(channelPresent && frameFresh);
  }

  const bool safe = switchActive || ppmLost;
  const bool changed = (safe != MotorSafetyActive) ||
                       (switchActive != MotorSafetySwitchActive) ||
                       (ppmLost != MotorSafetyPpmLost);

  MotorSafetyActive = safe;
  MotorSafetySwitchActive = switchActive;
  MotorSafetyPpmLost = ppmLost;

  if(safe)
    Channel_data[MotorChannel - 1] = ppmUsToMpmChannel(MOTOR_SAFE_US);

  if(changed && !StartupConsoleQuiet)
  {
    if(safe)
      Serial.printf("[MOTOR] CH%u SAFE=%u us%s%s\r\n",
                    MotorChannel, MOTOR_SAFE_US,
                    switchActive ? " GPIO0" : "",
                    ppmLost ? " PPM_LOST" : "");
    else
      Serial.printf("[MOTOR] CH%u RUN - PPM signal valid, safety switch released\r\n", MotorChannel);
  }
}

// ============================================================================
// OLED
// ============================================================================
static uint8_t oledProbeAddress()
{
  const uint8_t candidates[] = { 0x3C, 0x3D };

  for(uint8_t i = 0; i < sizeof(candidates); i++)
  {
    Wire.beginTransmission(candidates[i]);
    if(Wire.endTransmission() == 0)
      return candidates[i];
  }

  return 0;
}

static void oledInit()
{
  if(!oled_enabled)
  {
    oled_ok = false;
    if(!StartupConsoleQuiet) Serial.println("[OLED] OFF (saved preference) - type 'oled on' to enable");
    return;
  }

  // Shared C3 I2C bus: SDA=GPIO5, SCL=GPIO6.
  // The bus is already started in setup() for OLED + PCF8574(A).
  // Keep the common clock at I2C_BUS_HZ (100 kHz for the first PCF test).
  Wire.setClock(I2C_BUS_HZ);
  delay(20);

  const uint8_t DetectedAddr = oledProbeAddress();
  if(DetectedAddr == 0)
  {
    oled_ok = false;
    if(!StartupConsoleQuiet)
      Serial.printf("[OLED] NO I2C device on SDA=%d SCL=%d (tried 0x3C/0x3D)\r\n",
                    SDA_PIN, SCL_PIN);
    return;
  }

  if(!StartupConsoleQuiet)
    Serial.printf("[OLED] I2C device found at 0x%02X on SDA=%d SCL=%d\r\n",
                  DetectedAddr, SDA_PIN, SCL_PIN);

  u8g2.setI2CAddress(DetectedAddr << 1);
  u8g2.setBusClock(I2C_BUS_HZ);
  oled_ok = u8g2.begin();

  if(!oled_ok)
  {
    if(!StartupConsoleQuiet) Serial.println("[OLED] init FAILED");
    return;
  }

  oled_boot_ms = millis();
  if(!StartupConsoleQuiet) Serial.println("[OLED] init OK (SSD1306 72x40 / U8g2)");

  // Immediate startup test, before A7105 initialization. If this appears,
  // OLED wiring/driver are confirmed independently of the RF code.
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_5x7_tf);
  u8g2.setCursor(0, 8);
  u8g2.print("AFHDS2A");
  u8g2.setCursor(0, 18);
  u8g2.print("ESP32-C3");
  u8g2.setCursor(0, 28);
  u8g2.print("OLED OK");
  u8g2.sendBuffer();
  delay(700);
}

static void oledDisable()
{
  oled_enabled = false;
  if(oled_ok)
    u8g2.setPowerSave(1);
  oled_ok = false;
  Serial.println("[OLED] OFF");
}

static void oledDraw()
{
  if(!oled_enabled || !oled_ok || oledInfoTimer < 500)
    return;
  oledInfoTimer = 0;

  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_5x7_tf);

  u8g2.setCursor(0, 7);
  u8g2.print("AFHDS2A MPM");

  u8g2.setCursor(0, 16);
  if(!RadioOk)
    u8g2.print("A7105 ERROR");
  else if(IS_BIND_IN_PROGRESS)
    u8g2.print("RF BIND...");
  else
    u8g2.print(rfLinkStateText());

  u8g2.setCursor(0, 25);
  if(IS_BIND_IN_PROGRESS)
  {
    // Hide SWEEP/PPM values while the original MPM bind is running.
    // Channel_data still updates exactly as before; bind packets do not use it.
    const uint32_t sec = BindTimerActive ? ((uint32_t)(millis() - BindStartMs) / 1000UL) : 0UL;
    u8g2.print("BIND ");
    u8g2.print(sec);
    u8g2.print("/30s");
  }
  else if(InputSource == INPUT_SWEEP)
  {
    u8g2.print("SWP ");
    u8g2.print(SweepUs);
    u8g2.print("us");
  }
  else
  {
    u8g2.print("PPM ");
    u8g2.print(PpmChannelCount);
    if((uint32_t)(millis() - LastPpmFrameMs) > 500UL)
      u8g2.print(" LOST");
  }

  u8g2.setCursor(0, 34);
  if(!telemetryAFHDS2AHasValidPacket())
  {
    u8g2.print("TLM WAIT");
  }
  else
  {
    u8g2.print("T");
    uint32_t cnt = telemetryAFHDS2AValidPacketCount();
    if(cnt > 999) cnt = 999;
    u8g2.print(cnt);
    u8g2.print(" L");
    u8g2.print(rxLqiPercent());
    u8g2.print(" R");
    u8g2.print((int8_t)RX_RSSI);
  }

  u8g2.sendBuffer();
}

static void debugTask()
{
  // During BIND, suppress the normal SWEEP/PPM debug stream. The dedicated
  // bind logger records the MPM protocol in RAM without disturbing timing.
  if(IS_BIND_IN_PROGRESS)
    return;

  if(!DebugIsOn || (uint32_t)(millis() - LastDebugMs) < 500UL)
    return;

  LastDebugMs = millis();
  Serial.printf("DBG phase=%02X hop=%u mode=%s sweep=%u LQI=%u%% ERR=%u%% RX=%d TX=%u PPMisr=%lu dt=%lu\r\n",
                phase,
                hopping_frequency_no,
                InputSource == INPUT_SWEEP ? "SWEEP" : "PPM",
                SweepUs,
                rxLqiPercent(),
                RX_LQI,
                (int8_t)RX_RSSI,
                TX_RSSI,
                (unsigned long)Cppm32.rxIsrCount(),
                (unsigned long)Cppm32.rxLastDtUs());
  printChannels();
}

void setup()
{
  Serial.begin(DEFAULT_BAUD); // Use Serial

  // Timeout USB Serial (does not block forever without USB)
  uint32_t t0 = millis();
  while(!Serial && (millis() - t0 < 1500UL))
    delay(1);

  // Intentionally minimal startup banner. Detailed state remains available
  // from '?' / 'h' / 'hf' and protocol-specific console commands.
  Serial.println();
  Serial.println("***********************************");
  Serial.println("TX ESP32-C3 - RF backend: AFHDS2A/EXPRESS-LRS");
  Serial.println("***********************************");

  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, LOW);

  pinMode(PIN_BIND, INPUT_PULLUP);
  bindInitButtonState();

  // Independent motor safety switch: connect GPIO0 to GND to force CH3=1000 us.
  pinMode(PIN_MOTOR_SAFE, INPUT_PULLUP);

  // Preferences must be open before choosing which RF hardware is initialized.
  prefs.begin("mpm_afh", false);
  rfLoadPreference();
  oled_enabled = prefs.getBool("oled", false);
  TelemetryRxEnabled = prefs.getBool("tlmrx", false);
  RfRebindRequired = prefs.getBool("rebind", false);
  PpmPositive = prefs.getBool("ppmpos", true);
  btLoadPreference();

  // A7105 / MPM software SPI pins are owned only by the AFHDS2A backend.
  if(rfModeIsAfhds2a())
  {
    pinMode(A7105_CSN_PIN, OUTPUT);
    pinMode(A7105_SCK_PIN, OUTPUT);
    pinMode(A7105_SDIO_PIN, OUTPUT);
    A7105_CSN_on;
    SCLK_off;
    SDI_on;
  }

  // Shared I2C bus is always started because PCF8574(A) provides SW8 inputs.
  Wire.begin(SDA_PIN, SCL_PIN, I2C_BUS_HZ);
  Wire.setClock(I2C_BUS_HZ);

  oledInit();

  if(rfModeIsAfhds2a())
    telemetryAFHDS2AReset();
  xanyBegin();
  pcfSw8Begin();

  // BLE is common to both backends. btsimu selects its protocol automatically.
  btBegin();

  centerAllChannels();
  if(rfModeIsAfhds2a())
    initAfhds2aFailsafeValues();

  // PPM is initialized in both RF modes so the common RC source stays identical.
  Cppm32.beginRx(PPM_IN_PIN,
                 PPM_INPUT_CHANNELS,
                 PpmPositive,
                 3500,
                 800,
                 2200);

  // Establish the initial motor-safe state silently before the first loop pass.
  applyMotorSafety();

  if(rfModeIsAfhds2a())
  {
    protocol = PROTO_AFHDS2A;
    sub_protocol = PWM_IBUS;
    RX_num = 0;
    option = 0x80;  // FW telemetry format bit kept ON; low7=0 -> 50 Hz servo setting

    MProtocol_id = loadOrCreateTxId();
    set_rx_tx_addr(MProtocol_id);

    POWER_FLAG_on;
    RANGE_FLAG_off;

    // Hold BIND button during boot to start binding immediately.
    if(digitalRead(PIN_BIND) == LOW)
      BIND_IN_PROGRESS;
    else
      BIND_DONE;

    // Original MPM A7105 reset test before starting AFHDS2A.
    RadioOk = A7105_Reset();
    if(RadioOk)
    {
      AFHDS2A_init();
      if(IS_BIND_IN_PROGRESS)
        invalidateRfBindState();
      else
      {
        refreshRfBindState();
        armAfhds2aFailsafeProgramming();
      }

      RfUseEspTimer = rfTimerInit();
      rfTimerResetLog();
      if(RfUseEspTimer)
        rfTimerStart(2000UL);
      else
        NextProtocolUs = micros() + 2000UL;

      if(IS_BIND_IN_PROGRESS)
        bindBeginBootSession();
    }
  }
  else
  {
    // XANY uses the legacy bind flag only as a pause guard.
    BIND_DONE;
    RadioOk = false;
    crsfBegin();
  }

  // From this point onward all normal console feedback is enabled again.
  StartupConsoleQuiet = false;
}

void loop()
{
  processConsole();

  if(rfModeIsAfhds2a())
  {
    processBindButton();
    processBindSupervision();
    processRfLinkValidation();
    processAfhds2aFailsafeProgramming();
  }

  if(InputSource == INPUT_SWEEP)
    updateSweep();
  else
    updatePpm();

  // Motor safety has priority over the selected input source. In PPM mode,
  // missing/stale PPM forces CH3 to 1000 us. GPIO0 LOW always forces safe.
  applyMotorSafety();

  // Read physical switches, then let XANY reserve/overwrite its enabled channel
  // widths. This stays upstream and common to AFHDS2A and CRSF/ELRS.
  pcfSw8Process();
  xanyProcess();

  if(rfModeIsAfhds2a())
  {
    // With ESP_TIMER enabled the RF callback runs from the high-priority ESP
    // timer task. processProtocol() is kept only for automatic loop fallback.
    processProtocol();

    // First CRSF test deliberately leaves the existing AFHDS2A BLE bridge out
    // of the CRSF backend. Raw CRSF telemetry forwarding will be a later step.
    btProcess();

    oledDraw();
    debugTask();
    processStatusLed();
  }
  else
  {
    crsfProcess();

    // In CRSF mode this currently serves the CRSF BLE simulator. Live CRSF
    // telemetry forwarding from the ELRS module will be added later.
    btProcess();
  }
}
