// ============================================================================
// A7105 / AFHDS2A RF scheduler
// ============================================================================
// Refactoring only: code moved from AF2A_C3_BTLE_v1.ino.
// Timing logic and callback order are intentionally unchanged.

#include "A7105_Main.h"
#include "AFHDS2A_Bind.h"
#include "esp_timer.h"

bool RadioOk = false;
uint32_t NextProtocolUs = 0;  // mirror of ESP timer deadline / fallback scheduler

// ============================================================================
// ESP32 high-resolution RF timer
// ============================================================================
// esp_timer is backed by the ESP32-C3 system timer and dispatches this callback
// from the high-priority ESP timer task (NOT from an ISR). The A7105 SPI path
// now uses direct ESP32-C3 GPIO registers, while the callback itself remains in
// task context so the original MPM sources do not need ISR-specific rewriting.
// The original variable 1700/2150 us MPM cadence is kept.
static esp_timer_handle_t RfProtocolTimer = nullptr;
bool RfUseEspTimer = false;
static volatile bool RfTimerRunning = false;
static int64_t RfExpectedUs = 0;
static portMUX_TYPE RfTimerStatsMux = portMUX_INITIALIZER_UNLOCKED;

struct RfTimerStatsData
{
  uint32_t callbacks;
  uint32_t delay1700;
  uint32_t delay2150;
  uint32_t delayOther;
  uint32_t lateCount;
  uint64_t lateSumUs;
  uint32_t lateMaxUs;
  uint64_t runtimeSumUs;
  uint32_t runtimeMaxUs;
  uint64_t runtime1700SumUs;
  uint32_t runtime1700MaxUs;
  uint32_t runtime1700Samples;
  uint64_t runtime2150SumUs;
  uint32_t runtime2150MaxUs;
  uint32_t runtime2150Samples;
  uint64_t jitterAbsSumUs;
  uint32_t jitterAbsMaxUs;
  uint32_t jitterSamples;
  uint32_t overruns;
  uint32_t resyncs;
  uint32_t armErrors;
  int64_t firstStartUs;
  int64_t lastStartUs;
  int64_t prevStartUs;
  uint16_t prevDelayUs;
};

static RfTimerStatsData RfTimerStats = {};

static bool rfTimerInit();
static void rfTimerStart(uint32_t firstDelayUs);
static void rfTimerStop();
static void rfTimerResetLog();
static void rfTimerPrintLog();

// ============================================================================
// MPM callback scheduler - ESP32 high-resolution timer
// ============================================================================
static void rfTimerResetLog()
{
  portENTER_CRITICAL(&RfTimerStatsMux);
  RfTimerStats = {};
  portEXIT_CRITICAL(&RfTimerStatsMux);
}

static void rfTimerPrintLog()
{
  RfTimerStatsData s;
  portENTER_CRITICAL(&RfTimerStatsMux);
  s = RfTimerStats;
  portEXIT_CRITICAL(&RfTimerStatsMux);

  Serial.println();
  Serial.println("========== ESP32 RF TIMER LOG ==========");
  Serial.printf("[RF-TIMER] mode=%s SPI=REGGPIO CPU=%luMHz TLM=%s callbacks=%lu\r\n",
                RfUseEspTimer ? "ESP_TIMER" : "LOOP_FALLBACK",
                (unsigned long)getCpuFrequencyMhz(),
                TelemetryRxEnabled ? "ON" : "OFF",
                (unsigned long)s.callbacks);

  if(s.callbacks > 1 && s.lastStartUs > s.firstStartUs)
  {
    const double elapsedSec = (double)(s.lastStartUs - s.firstStartUs) / 1000000.0;
    const double rate = elapsedSec > 0.0 ? (double)(s.callbacks - 1) / elapsedSec : 0.0;
    Serial.printf("[RF-TIMER] elapsed=%.3fs rate=%.2f callbacks/s target~519.48\r\n",
                  elapsedSec, rate);
  }

  Serial.printf("[RF-TIMER] delays: 1700=%lu 2150=%lu other=%lu\r\n",
                (unsigned long)s.delay1700,
                (unsigned long)s.delay2150,
                (unsigned long)s.delayOther);

  const double avgLate = s.lateCount ? (double)s.lateSumUs / (double)s.lateCount : 0.0;
  const double avgRun = s.callbacks ? (double)s.runtimeSumUs / (double)s.callbacks : 0.0;
  const double avgJitter = s.jitterSamples ? (double)s.jitterAbsSumUs / (double)s.jitterSamples : 0.0;
  Serial.printf("[RF-TIMER] lateness avg=%.1fus max=%luus samples=%lu\r\n",
                avgLate, (unsigned long)s.lateMaxUs, (unsigned long)s.lateCount);
  Serial.printf("[RF-TIMER] callback runtime avg=%.1fus max=%luus\r\n",
                avgRun, (unsigned long)s.runtimeMaxUs);
  const double avgRun1700 = s.runtime1700Samples ? (double)s.runtime1700SumUs / (double)s.runtime1700Samples : 0.0;
  const double avgRun2150 = s.runtime2150Samples ? (double)s.runtime2150SumUs / (double)s.runtime2150Samples : 0.0;
  Serial.printf("[RF-TIMER] runtime->1700 avg=%.1fus max=%luus samples=%lu\r\n",
                avgRun1700, (unsigned long)s.runtime1700MaxUs, (unsigned long)s.runtime1700Samples);
  Serial.printf("[RF-TIMER] runtime->2150 avg=%.1fus max=%luus samples=%lu\r\n",
                avgRun2150, (unsigned long)s.runtime2150MaxUs, (unsigned long)s.runtime2150Samples);
  Serial.printf("[RF-TIMER] interval jitter |err| avg=%.1fus max=%luus samples=%lu\r\n",
                avgJitter, (unsigned long)s.jitterAbsMaxUs, (unsigned long)s.jitterSamples);
  Serial.printf("[RF-TIMER] overruns=%lu resyncs=%lu armErrors=%lu\r\n",
                (unsigned long)s.overruns,
                (unsigned long)s.resyncs,
                (unsigned long)s.armErrors);
  Serial.println("========================================");
}

static void rfProtocolTimerCallback(void* arg)
{
  (void)arg;
  if(!RadioOk || !RfTimerRunning)
    return;

  const int64_t cbStartUs = esp_timer_get_time();
  const int64_t expectedUs = RfExpectedUs;
  int64_t lateUs64 = cbStartUs - expectedUs;
  if(lateUs64 < 0) lateUs64 = 0;
  const uint32_t lateUs = (uint32_t)lateUs64;

  const uint8_t phaseBefore = phase;
  bindDiagBeginCallback();
  telemetryAFHDS2ABeginCallback(phaseBefore);
  const uint16_t delayUs = AFHDS2A_callback();
  const uint8_t phaseAfter = phase;
  bindDiagEndCallback(phaseBefore);
  telemetryAFHDS2AEndCallback(phaseBefore, phaseAfter);
  bindLogCapture(phaseBefore, phaseAfter);

  const int64_t cbEndUs = esp_timer_get_time();
  const uint32_t runtimeUs = (uint32_t)(cbEndUs - cbStartUs);

  portENTER_CRITICAL(&RfTimerStatsMux);
  if(RfTimerStats.callbacks == 0)
    RfTimerStats.firstStartUs = cbStartUs;
  else if(RfTimerStats.prevStartUs != 0 && RfTimerStats.prevDelayUs != 0)
  {
    const int64_t actualInterval = cbStartUs - RfTimerStats.prevStartUs;
    int64_t jitter = actualInterval - (int64_t)RfTimerStats.prevDelayUs;
    if(jitter < 0) jitter = -jitter;
    RfTimerStats.jitterAbsSumUs += (uint64_t)jitter;
    if((uint64_t)jitter > RfTimerStats.jitterAbsMaxUs)
      RfTimerStats.jitterAbsMaxUs = (uint32_t)jitter;
    RfTimerStats.jitterSamples++;
  }
  RfTimerStats.callbacks++;
  RfTimerStats.lastStartUs = cbStartUs;
  RfTimerStats.prevStartUs = cbStartUs;
  RfTimerStats.prevDelayUs = delayUs;
  if(delayUs == 1700) RfTimerStats.delay1700++;
  else if(delayUs == 2150) RfTimerStats.delay2150++;
  else RfTimerStats.delayOther++;
  RfTimerStats.lateCount++;
  RfTimerStats.lateSumUs += lateUs;
  if(lateUs > RfTimerStats.lateMaxUs) RfTimerStats.lateMaxUs = lateUs;
  RfTimerStats.runtimeSumUs += runtimeUs;
  if(runtimeUs > RfTimerStats.runtimeMaxUs) RfTimerStats.runtimeMaxUs = runtimeUs;
  if(delayUs == 1700)
  {
    RfTimerStats.runtime1700SumUs += runtimeUs;
    RfTimerStats.runtime1700Samples++;
    if(runtimeUs > RfTimerStats.runtime1700MaxUs) RfTimerStats.runtime1700MaxUs = runtimeUs;
  }
  else if(delayUs == 2150)
  {
    RfTimerStats.runtime2150SumUs += runtimeUs;
    RfTimerStats.runtime2150Samples++;
    if(runtimeUs > RfTimerStats.runtime2150MaxUs) RfTimerStats.runtime2150MaxUs = runtimeUs;
  }
  portEXIT_CRITICAL(&RfTimerStatsMux);

  // Keep the next deadline tied to the previous scheduled deadline, like the
  // original MPM timer scheduler. Callback execution time is therefore not
  // added to the requested 1700/2150 us period.
  int64_t nextExpectedUs = expectedUs + (int64_t)delayUs;

  // Same spirit as the old loop scheduler recovery: only resync after a large
  // (>20 ms) disturbance instead of accumulating an impossible backlog.
  if((cbEndUs - nextExpectedUs) > 20000)
  {
    nextExpectedUs = cbEndUs + (int64_t)delayUs;
    portENTER_CRITICAL(&RfTimerStatsMux);
    RfTimerStats.resyncs++;
    portEXIT_CRITICAL(&RfTimerStatsMux);
  }

  RfExpectedUs = nextExpectedUs;
  NextProtocolUs = (uint32_t)nextExpectedUs;

  int64_t waitUs64 = nextExpectedUs - cbEndUs;
  if(waitUs64 < 1)
  {
    waitUs64 = 1;
    portENTER_CRITICAL(&RfTimerStatsMux);
    RfTimerStats.overruns++;
    portEXIT_CRITICAL(&RfTimerStatsMux);
  }

  const esp_err_t err = esp_timer_start_once(RfProtocolTimer, (uint64_t)waitUs64);
  if(err != ESP_OK)
  {
    portENTER_CRITICAL(&RfTimerStatsMux);
    RfTimerStats.armErrors++;
    portEXIT_CRITICAL(&RfTimerStatsMux);
    RfTimerRunning = false;
  }
}

static bool rfTimerInit()
{
  if(RfProtocolTimer != nullptr)
    return true;

  esp_timer_create_args_t timerArgs = {};
  timerArgs.callback = &rfProtocolTimerCallback;
  timerArgs.arg = nullptr;
  timerArgs.dispatch_method = ESP_TIMER_TASK;
  timerArgs.name = "afhds2a_rf";

  const esp_err_t err = esp_timer_create(&timerArgs, &RfProtocolTimer);
  if(err != ESP_OK)
  {
    if(!StartupConsoleQuiet) Serial.printf("[RF-TIMER] esp_timer_create FAILED err=%d -> loop fallback\r\n", (int)err);
    RfProtocolTimer = nullptr;
    return false;
  }

  if(!StartupConsoleQuiet) Serial.println("[RF-TIMER] ESP32 high-resolution timer ready (ESP_TIMER_TASK)");
  return true;
}

static void rfTimerStop()
{
  RfTimerRunning = false;
  if(RfProtocolTimer != nullptr)
    esp_timer_stop(RfProtocolTimer);  // ESP_ERR_INVALID_STATE is harmless if already stopped
}

static void rfTimerStart(uint32_t firstDelayUs)
{
  if(RfProtocolTimer == nullptr)
    return;

  esp_timer_stop(RfProtocolTimer);
  const int64_t nowUs = esp_timer_get_time();
  RfExpectedUs = nowUs + (int64_t)firstDelayUs;
  NextProtocolUs = (uint32_t)RfExpectedUs;
  RfTimerRunning = true;

  const esp_err_t err = esp_timer_start_once(RfProtocolTimer, firstDelayUs);
  if(err != ESP_OK)
  {
    RfTimerRunning = false;
    portENTER_CRITICAL(&RfTimerStatsMux);
    RfTimerStats.armErrors++;
    portEXIT_CRITICAL(&RfTimerStatsMux);
    if(!StartupConsoleQuiet) Serial.printf("[RF-TIMER] start FAILED err=%d\r\n", (int)err);
  }
}

// Cooperative scheduler retained only as an automatic fallback if esp_timer
// creation fails. In normal operation RfUseEspTimer=true and this is a no-op.
static void processProtocol()
{
  if(RfUseEspTimer || !RadioOk)
    return;

  const uint32_t now = micros();
  if((int32_t)(now - NextProtocolUs) < 0)
    return;

  const uint8_t phaseBefore = phase;
  bindDiagBeginCallback();
  telemetryAFHDS2ABeginCallback(phaseBefore);
  const uint16_t delayUs = AFHDS2A_callback();
  const uint8_t phaseAfter = phase;
  bindDiagEndCallback(phaseBefore);
  telemetryAFHDS2AEndCallback(phaseBefore, phaseAfter);
  bindLogCapture(phaseBefore, phaseAfter);
  NextProtocolUs += delayUs;

  if((int32_t)(micros() - NextProtocolUs) > 20000)
    NextProtocolUs = micros() + delayUs;
}

