/*
  AFHDS2A telemetry diagnostics + first useful sensor decoder for ESP32-C3.

  This file intentionally keeps the original MPM files untouched:
    - AFHDS2A_a7105.ino
    - A7105_SPI.ino
    - iface_a7105.h

  The original AFHDS2A code still owns the RF state machine.  This helper only
  observes the same A7105 MODE/FIFO traffic in RAM and decodes selected sensors
  for the OLED/console.  No Serial output is performed from the RF callback.

  Implemented in v1.9:
    GPS latitude      ID 0x80, signed 32-bit, deg * 1e7
    GPS longitude     ID 0x81, signed 32-bit, deg * 1e7
    GPS satellites    ID 0x0B, high byte
    GPS COG/heading   ID 0x0A, deg * 100
    GPS ground speed  ID 0x13, m/s * 100
    RX voltage        ID 0x00, volts * 100
    V1 / ext voltage  ID 0x03, volts * 100
    Battery current   ID 0x05, amps * 100 (oXs RP2040 clamps negative values to 0)
    Capacity / fuel     ID 0x06, raw 16-bit (also shown signed for RP2040 diagnostics)
    Vario vertical spd ID 0x09, signed m/s * 100 (native climb rate)
    Vario vertical spd ID 0x12, signed m/s * 100
    Vario pressure     ID 0x41, packed pressure + temperature; relative altitude
    Vario altitude     ID 0x83, signed 32-bit m * 100 (AC)
    RPM                 ID 0x02 (MOT) and ID 0x07 (RPM), unsigned raw RPM
    FlySky altitude    ID 0xF9, signed 16-bit meters (AA)
    GPS altitude       ID 0x82, signed 32-bit m * 100 (AC)
    Temperature        ID 0x01, raw 16-bit; radio conversion is (raw - 400) / 10 C
    Pressure temp      ID 0x41, temperature packed in high bits of 32-bit pressure record

  AA sensor record: [ID][instance][valueLo][valueHi]
  AC sensor record: [ID][instance][size][payload...]
*/

static constexpr uint8_t TLM_AFHDS2A_RX_LEN = 37;
static constexpr uint8_t TLM_AFHDS2A_EVENT_MAX = 8;

struct TelemetryAFHDS2AEvent
{
  uint32_t atMs;
  uint8_t phaseBefore;
  uint8_t mode0;
  uint8_t mode1;
  uint8_t len;
  uint8_t data[TLM_AFHDS2A_RX_LEN];
};

static TelemetryAFHDS2AEvent TlmEvents[TLM_AFHDS2A_EVENT_MAX];
static uint8_t TlmEventWrite = 0;
static uint8_t TlmEventCount = 0;

static uint32_t TlmDataCallbacks = 0;
static uint32_t TlmMode0Count = 0;
static uint32_t TlmMode1Count = 0;
static uint32_t TlmRxReadyCount = 0;      // !(MODE#0 & 0x01)
static uint32_t TlmCrcOkCount = 0;        // !(MODE#1 & 0x20)
static uint32_t TlmGateCount = 0;         // exact MPM RX test passed
static uint32_t TlmFifoReadCount = 0;
static uint32_t TlmPacketAA = 0;
static uint32_t TlmPacketAC = 0;
static uint32_t TlmPacketOther = 0;
static uint32_t TlmPacketBadAddr = 0;
static uint32_t TlmPacketConfig = 0;      // AA ... marker FD
static uint32_t TlmPacketSettingsReq = 0; // AA ... marker FC
static uint32_t TlmPacketValid = 0;       // normal AA or AC with our TX address
static uint32_t TlmLastValidMs = 0;

// ---------------------------------------------------------------------------
// Selected decoded values.  Values persist because AFHDS2A telemetry packets
// can be far apart; one packet does not necessarily carry all sensors.
// ---------------------------------------------------------------------------
static bool TlmHasGpsLat = false;
static bool TlmHasGpsLon = false;
static bool TlmHasGpsSat = false;
static bool TlmHasGpsCog = false;
static bool TlmHasGpsSpeed = false;
static int32_t TlmGpsLatE7 = 0;
static int32_t TlmGpsLonE7 = 0;
static uint8_t TlmGpsSat = 0;
static uint16_t TlmGpsCogX100 = 0;
static uint16_t TlmGpsSpeedX100 = 0;

static bool TlmHasGpsAlt = false;
static int32_t TlmGpsAltX100 = 0;

// Vario / barometric values kept separate from GPS.
static bool TlmHasVarioAlt = false;
static bool TlmHasVarioVSpeed = false;
static bool TlmHasVarioClimbRate = false; // kept for API compatibility
static int32_t TlmVarioAltX100 = 0;
static int16_t TlmVarioVSpeedX100 = 0;
static int16_t TlmVarioClimbRateX100 = 0; // mirrors ID 0x09 when present
static uint8_t TlmVarioAltSource = 0;
static uint8_t TlmVarioVSpeedSource = 0;

// OpenTX-compatible pressure-derived relative altitude state.
// ID 0x41 packs pressure in the low 19 bits and iBUS temperature above it.
// First pressure sample is used as zero altitude.
static uint32_t TlmVarioInitPressure = 0;
static uint16_t TlmVarioInitTemperatureK = 0;

static bool TlmHasRxVoltage = false;
static bool TlmHasV1 = false;
static bool TlmHasCurrent = false;
static uint16_t TlmRxVoltageX100 = 0; // V * 100
static uint16_t TlmV1X100 = 0;        // external voltage ID 0x03, V * 100
static int16_t TlmCurrentX100 = 0;     // A * 100; oXs RP2040 clamps negative current before iBUS
static bool TlmHasCapacity = false;
static uint16_t TlmCapacityRaw = 0;     // ID 0x06 is forwarded by MPM as raw 16-bit
static uint32_t TlmCurrentLastMs = 0;
static uint32_t TlmCapacityLastMs = 0;
static uint32_t TlmVarioVSpeedLastMs = 0;
static uint32_t TlmVarioAltLastMs = 0;

// Temperatures. Multiple ID 0x01 sensors are distinguished by instance.
// The pressure/vario ID 0x41 also embeds a temperature and is kept as a
// separate entry. FlySky/iBUS temperature encoding is 0.1 C with +400 offset.
struct TelemetryAFHDS2ATempEntry
{
  bool seen;
  uint8_t id;
  uint8_t instance;
  uint16_t raw;
  int16_t x10;
  uint32_t lastMs;
};
static constexpr uint8_t TLM_AFHDS2A_TEMP_MAX = 6;
static TelemetryAFHDS2ATempEntry TlmTemps[TLM_AFHDS2A_TEMP_MAX];

// RPM sensors. FlySky/iBUS uses both ID 0x02 (MOT) and ID 0x07 (RPM).
// Keep the instance so multiple RPM sources remain distinguishable.
struct TelemetryAFHDS2ARpmEntry
{
  bool seen;
  uint8_t id;
  uint8_t instance;
  uint16_t rpm;
  uint32_t lastMs;
};
static constexpr uint8_t TLM_AFHDS2A_RPM_MAX = 4;
static TelemetryAFHDS2ARpmEntry TlmRpms[TLM_AFHDS2A_RPM_MAX];

// Existing MPM-oriented sensors retained for diagnostics.
static bool TlmHasErrRate = false;
static bool TlmHasRxRssi = false;
static bool TlmHasRxNoise = false;
static bool TlmHasRxSnr = false;
static uint8_t TlmErrRate = 0;
static uint8_t TlmRxRssiRaw = 0;
static uint8_t TlmRxNoiseRaw = 0;
static uint8_t TlmRxSnrRaw = 0;

// Per-callback passive SPI capture.
static bool TlmCaptureActive = false;
static uint8_t TlmPhaseBefore = 0xFF;
static uint8_t TlmLastSpiWrite = 0xFF;
static uint8_t TlmMode[6];
static uint8_t TlmModeCount = 0;
static uint8_t TlmFifo[TLM_AFHDS2A_RX_LEN];
static uint8_t TlmFifoCount = 0;

static uint16_t telemetryAFHDS2AReadU16LE(const uint8_t* p)
{
  return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static int32_t telemetryAFHDS2AReadS32LE(const uint8_t* p)
{
  const uint32_t u = (uint32_t)p[0]
                   | ((uint32_t)p[1] << 8)
                   | ((uint32_t)p[2] << 16)
                   | ((uint32_t)p[3] << 24);
  return (int32_t)u;
}

static uint32_t telemetryAFHDS2AReadU32LE(const uint8_t* p)
{
  return (uint32_t)p[0]
       | ((uint32_t)p[1] << 8)
       | ((uint32_t)p[2] << 16)
       | ((uint32_t)p[3] << 24);
}

// OpenTX FlySky/iBUS pressure-to-relative-altitude conversion.
// Result unit is 0.01 m (centimetres), matching UNIT_METERS precision=2.
static constexpr uint8_t  TLM_ALT_PRECISION = 15;
static constexpr uint64_t TLM_R_DIV_G_MUL_10_Q15 = 9591506ULL;
static constexpr uint64_t TLM_INV_LOG2_E_Q1DOT31 = 0x58b90bfcULL;
static constexpr uint32_t TLM_PRESSURE_MASK = 0x7FFFFUL;

static uint16_t telemetryAFHDS2ATempToK(int16_t temperatureIbus)
{
  return (uint16_t)(temperatureIbus - 400) + 2731U;
}

static int32_t telemetryAFHDS2ALog2Fix(uint32_t x)
{
  int32_t b = 1L << (TLM_ALT_PRECISION - 1);
  int32_t y = 0;

  while(x < (1UL << TLM_ALT_PRECISION))
  {
    x <<= 1;
    y -= 1L << TLM_ALT_PRECISION;
  }
  while(x >= (2UL << TLM_ALT_PRECISION))
  {
    x >>= 1;
    y += 1L << TLM_ALT_PRECISION;
  }

  uint64_t z = x;
  for(uint8_t i = 0; i < TLM_ALT_PRECISION; i++)
  {
    z = (z * z) >> TLM_ALT_PRECISION;
    if(z >= (2ULL << TLM_ALT_PRECISION))
    {
      z >>= 1;
      y += b;
    }
    b >>= 1;
  }
  return y;
}

static int32_t telemetryAFHDS2APressureAltitudeX100(uint32_t packed)
{
  const uint32_t pressurePa = packed & TLM_PRESSURE_MASK;
  if(pressurePa == 0)
    return 0;

  const uint16_t temperatureK = telemetryAFHDS2ATempToK((uint16_t)(packed >> 19));

  if(TlmVarioInitPressure == 0)
  {
    TlmVarioInitPressure = pressurePa;
    TlmVarioInitTemperatureK = temperatureK;
  }

  int32_t temperature = ((int32_t)TlmVarioInitTemperatureK + (int32_t)temperatureK) >> 1;
  bool tempNegative = temperature < 0;
  if(tempNegative)
    temperature = -temperature;

  uint64_t helper = TLM_R_DIV_G_MUL_10_Q15;
  helper *= (uint64_t)temperature;
  helper >>= TLM_ALT_PRECISION;

  uint32_t poToP = TlmVarioInitPressure << (TLM_ALT_PRECISION - 1);
  poToP /= pressurePa;
  poToP <<= 1;
  if(poToP == 0)
    return 0;

  const int64_t log2v = telemetryAFHDS2ALog2Fix(poToP);
  const int64_t t = log2v * (int64_t)TLM_INV_LOG2_E_Q1DOT31;
  int32_t ln = (int32_t)(t >> 31);
  bool neg = ln < 0;
  if(neg)
    ln = -ln;

  helper *= (uint64_t)ln;
  helper >>= TLM_ALT_PRECISION;

  int32_t result = (int32_t)helper;
  if(neg ^ tempNegative)
    result = -result;

  return result;
}

static void telemetryAFHDS2AStoreTemp(uint8_t id, uint8_t instance, uint16_t raw, int16_t x10)
{
  // Update an existing sensor first.
  for(uint8_t i = 0; i < TLM_AFHDS2A_TEMP_MAX; i++)
  {
    if(TlmTemps[i].seen && TlmTemps[i].id == id && TlmTemps[i].instance == instance)
    {
      TlmTemps[i].raw = raw;
      TlmTemps[i].x10 = x10;
      TlmTemps[i].lastMs = millis();
      return;
    }
  }

  // Otherwise allocate the first free slot.
  for(uint8_t i = 0; i < TLM_AFHDS2A_TEMP_MAX; i++)
  {
    if(!TlmTemps[i].seen)
    {
      TlmTemps[i].seen = true;
      TlmTemps[i].id = id;
      TlmTemps[i].instance = instance;
      TlmTemps[i].raw = raw;
      TlmTemps[i].x10 = x10;
      TlmTemps[i].lastMs = millis();
      return;
    }
  }
}

static void telemetryAFHDS2AStoreRpm(uint8_t id, uint8_t instance, uint16_t rpm)
{
  for(uint8_t i = 0; i < TLM_AFHDS2A_RPM_MAX; i++)
  {
    if(TlmRpms[i].seen && TlmRpms[i].id == id && TlmRpms[i].instance == instance)
    {
      TlmRpms[i].rpm = rpm;
      TlmRpms[i].lastMs = millis();
      return;
    }
  }

  for(uint8_t i = 0; i < TLM_AFHDS2A_RPM_MAX; i++)
  {
    if(!TlmRpms[i].seen)
    {
      TlmRpms[i].seen = true;
      TlmRpms[i].id = id;
      TlmRpms[i].instance = instance;
      TlmRpms[i].rpm = rpm;
      TlmRpms[i].lastMs = millis();
      return;
    }
  }
}


static bool telemetryAFHDS2AIsDataCallback(uint8_t p)
{
  // Original AFHDS2A enum: DATA_INIT=4, DATA=5. DATA_INIT falls through to DATA.
  return p == 4 || p == 5;
}

static void telemetryAFHDS2AStoreEvent(uint8_t phaseBefore, uint8_t mode0, uint8_t mode1,
                                       const uint8_t* data, uint8_t len)
{
  TelemetryAFHDS2AEvent &e = TlmEvents[TlmEventWrite];
  e.atMs = millis();
  e.phaseBefore = phaseBefore;
  e.mode0 = mode0;
  e.mode1 = mode1;
  e.len = len;
  if(e.len > TLM_AFHDS2A_RX_LEN)
    e.len = TLM_AFHDS2A_RX_LEN;
  memcpy(e.data, data, e.len);
  if(e.len < TLM_AFHDS2A_RX_LEN)
    memset(e.data + e.len, 0, TLM_AFHDS2A_RX_LEN - e.len);

  TlmEventWrite++;
  if(TlmEventWrite >= TLM_AFHDS2A_EVENT_MAX)
    TlmEventWrite = 0;
  if(TlmEventCount < TLM_AFHDS2A_EVENT_MAX)
    TlmEventCount++;
}

static void telemetryAFHDS2ADecodeAARecord(uint8_t id, uint8_t instance, uint16_t raw)
{
  switch(id)
  {
    case 0x00: // Internal / receiver voltage, V * 100
      TlmHasRxVoltage = true;
      TlmRxVoltageX100 = raw;
      break;

    case 0x01: // iBUS temperature: 0.1 C with +400 offset
    case 0x57: // AFHDS3 virtual temperature, same unit/offset when present
      telemetryAFHDS2AStoreTemp(id, instance, raw, (int16_t)raw - 400);
      break;

    case 0x02: // MOT / motor RPM
    case 0x07: // RPM
      telemetryAFHDS2AStoreRpm(id, instance, raw);
      break;

    case 0x05: // Battery current, A * 100
      TlmHasCurrent = true;
      TlmCurrentX100 = (int16_t)raw;
      TlmCurrentLastMs = millis();
      break;

    case 0x06: // Fuel / capacity. MPM forwards this 16-bit value unchanged.
      TlmHasCapacity = true;
      TlmCapacityRaw = raw;
      TlmCapacityLastMs = millis();
      break;

    case 0x09: // Native climb rate / VSpeed, signed m/s * 100 (= cm/s)
      TlmHasVarioClimbRate = true;
      TlmVarioClimbRateX100 = (int16_t)raw;
      // Use ID 0x09 as VSpeed unless the explicit ID 0x12 has already been seen.
      if(TlmVarioVSpeedSource != 0x12)
      {
        TlmHasVarioVSpeed = true;
        TlmVarioVSpeedX100 = (int16_t)raw;
        TlmVarioVSpeedSource = 0x09;
        TlmVarioVSpeedLastMs = millis();
      }
      break;

    case 0x12: // Explicit vertical speed, signed m/s * 100 (= cm/s)
      TlmHasVarioVSpeed = true;
      TlmVarioVSpeedX100 = (int16_t)raw;
      TlmVarioVSpeedSource = 0x12;
      TlmVarioVSpeedLastMs = millis();
      break;

    case 0xF9: // FlySky native altitude, signed meters
      TlmHasVarioAlt = true;
      TlmVarioAltX100 = (int32_t)(int16_t)raw * 100L;
      TlmVarioAltSource = 0xF9;
      TlmVarioAltLastMs = millis();
      break;

    case 0x0A: // GPS COG, degrees * 100
      TlmHasGpsCog = true;
      TlmGpsCogX100 = raw;
      break;

    case 0x0B: // GPS status: satellites in high byte
      TlmHasGpsSat = true;
      TlmGpsSat = (uint8_t)(raw >> 8);
      break;

    case 0x13: // GPS ground speed, m/s * 100
      TlmHasGpsSpeed = true;
      TlmGpsSpeedX100 = raw;
      break;

    case 0x03: // External voltage: V1 for our first POWER page
      TlmHasV1 = true;
      TlmV1X100 = raw;
      break;

    case 0xFE: // RX error rate
      TlmHasErrRate = true;
      TlmErrRate = (uint8_t)(raw & 0xFF);
      break;

    case 0xFC: // RX RSSI
      TlmHasRxRssi = true;
      TlmRxRssiRaw = (uint8_t)(raw & 0xFF);
      break;

    case 0xFB: // RX noise
      TlmHasRxNoise = true;
      TlmRxNoiseRaw = (uint8_t)(raw & 0xFF);
      break;

    case 0xFA: // RX SNR
      TlmHasRxSnr = true;
      TlmRxSnrRaw = (uint8_t)(raw & 0xFF);
      break;

    default:
      break;
  }
}

static void telemetryAFHDS2ADecodeACRecord(uint8_t id, uint8_t instance,
                                           const uint8_t* value, uint8_t size)
{
  (void)instance;

  if(size == 4)
  {
    if(id == 0x80) // GPS latitude, signed degrees * 1e7
    {
      TlmHasGpsLat = true;
      TlmGpsLatE7 = telemetryAFHDS2AReadS32LE(value);
      return;
    }
    if(id == 0x81) // GPS longitude, signed degrees * 1e7
    {
      TlmHasGpsLon = true;
      TlmGpsLonE7 = telemetryAFHDS2AReadS32LE(value);
      return;
    }
    if(id == 0x82) // GPS altitude, signed meters * 100
    {
      TlmHasGpsAlt = true;
      TlmGpsAltX100 = telemetryAFHDS2AReadS32LE(value);
      return;
    }
    if(id == 0x83) // Barometric / vario altitude, signed meters * 100
    {
      // Keep direct ID 0x83 only as a fallback. Pressure ID 0x41 is
      // preferred because it gives relative altitude from startup zero.
      if(TlmVarioAltSource != 0x41)
      {
        TlmHasVarioAlt = true;
        TlmVarioAltX100 = telemetryAFHDS2AReadS32LE(value);
        TlmVarioAltSource = 0x83;
        TlmVarioAltLastMs = millis();
      }
      return;
    }
    if(id == 0x41) // Pressure: low 19 bits pressure, upper bits temperature
    {
      const uint32_t packed = telemetryAFHDS2AReadU32LE(value);
      const int16_t tempX10 = (int16_t)(packed >> 19) - 400;
      telemetryAFHDS2AStoreTemp(id, instance, (uint16_t)(packed >> 19), tempX10);

      // Same relative-altitude calculation as OpenTX FlySky/iBUS.
      TlmHasVarioAlt = true;
      TlmVarioAltX100 = telemetryAFHDS2APressureAltitudeX100(packed);
      TlmVarioAltSource = 0x41;
      TlmVarioAltLastMs = millis();
      return;
    }
  }

  if(id == 0xFD && size >= 14)
  {
    // GPS_FULL: [fix][sats][LAT x4][LON x4][ALT x4]
    TlmHasGpsSat = true;
    TlmGpsSat = value[1];
    TlmHasGpsLat = true;
    TlmGpsLatE7 = telemetryAFHDS2AReadS32LE(&value[2]);
    TlmHasGpsLon = true;
    TlmGpsLonE7 = telemetryAFHDS2AReadS32LE(&value[6]);
    TlmHasGpsAlt = true;
    TlmGpsAltX100 = telemetryAFHDS2AReadS32LE(&value[10]);
    return;
  }

  if(id == 0xF0 && size >= 10)
  {
    // VOLT_FULL packs IDs 0x03..0x07 as five little-endian 16-bit values.
    // Decode all five so RPM ID 0x07 is retained even when its value is zero.
    for(uint8_t sensorId = 0x03; sensorId <= 0x07; sensorId++)
    {
      const uint8_t off = (uint8_t)((sensorId - 0x03) * 2);
      telemetryAFHDS2ADecodeAARecord(sensorId, instance, telemetryAFHDS2AReadU16LE(&value[off]));
    }
    return;
  }
}

static void telemetryAFHDS2ADecodeSensors(const uint8_t* p, uint8_t len)
{
  if(len < TLM_AFHDS2A_RX_LEN)
    return;

  if(p[0] == 0xAA)
  {
    // Seven fixed 4-byte sensor slots starting at packet[9].
    for(uint8_t sensor = 0; sensor < 7; sensor++)
    {
      const uint8_t index = 9 + 4 * sensor;
      const uint8_t id = p[index];
      if(id == 0xFF)
        break;

      const uint8_t instance = p[index + 1];
      const uint16_t raw = telemetryAFHDS2AReadU16LE(&p[index + 2]);
      telemetryAFHDS2ADecodeAARecord(id, instance, raw);
    }
  }
  else if(p[0] == 0xAC)
  {
    // Variable-size records: [ID][instance][size][payload...]
    uint8_t index = 9;
    while(index + 3 <= len)
    {
      const uint8_t id = p[index];
      if(id == 0xFF)
        break;

      const uint8_t instance = p[index + 1];
      const uint8_t size = p[index + 2];
      if(size == 0 || (uint16_t)index + 3U + size > len)
        break;

      telemetryAFHDS2ADecodeACRecord(id, instance, &p[index + 3], size);
      index = (uint8_t)(index + 3 + size);
    }
  }
}

void telemetryAFHDS2AReset()
{
  TlmEventWrite = 0;
  TlmEventCount = 0;
  TlmDataCallbacks = 0;
  TlmMode0Count = 0;
  TlmMode1Count = 0;
  TlmRxReadyCount = 0;
  TlmCrcOkCount = 0;
  TlmGateCount = 0;
  TlmFifoReadCount = 0;
  TlmPacketAA = 0;
  TlmPacketAC = 0;
  TlmPacketOther = 0;
  TlmPacketBadAddr = 0;
  TlmPacketConfig = 0;
  TlmPacketSettingsReq = 0;
  TlmPacketValid = 0;
  TlmLastValidMs = 0;

  TlmHasGpsLat = false;
  TlmHasGpsLon = false;
  TlmHasGpsSat = false;
  TlmHasGpsCog = false;
  TlmHasGpsSpeed = false;
  TlmGpsLatE7 = 0;
  TlmGpsLonE7 = 0;
  TlmGpsSat = 0;
  TlmGpsCogX100 = 0;
  TlmGpsSpeedX100 = 0;

  TlmHasGpsAlt = false;
  TlmGpsAltX100 = 0;

  TlmHasVarioAlt = false;
  TlmHasVarioVSpeed = false;
  TlmHasVarioClimbRate = false;
  TlmVarioAltX100 = 0;
  TlmVarioVSpeedX100 = 0;
  TlmVarioClimbRateX100 = 0;
  TlmVarioAltSource = 0;
  TlmVarioVSpeedSource = 0;
  TlmVarioInitPressure = 0;
  TlmVarioInitTemperatureK = 0;

  memset(TlmTemps, 0, sizeof(TlmTemps));
  memset(TlmRpms, 0, sizeof(TlmRpms));

  TlmHasRxVoltage = false;
  TlmHasV1 = false;
  TlmHasCurrent = false;
  TlmRxVoltageX100 = 0;
  TlmV1X100 = 0;
  TlmCurrentX100 = 0;
  TlmHasCapacity = false;
  TlmCapacityRaw = 0;
  TlmCurrentLastMs = 0;
  TlmCapacityLastMs = 0;
  TlmVarioVSpeedLastMs = 0;
  TlmVarioAltLastMs = 0;

  TlmHasErrRate = false;
  TlmHasRxRssi = false;
  TlmHasRxNoise = false;
  TlmHasRxSnr = false;
  TlmErrRate = 0;
  TlmRxRssiRaw = 0;
  TlmRxNoiseRaw = 0;
  TlmRxSnrRaw = 0;

  TlmCaptureActive = false;
  TlmPhaseBefore = 0xFF;
  TlmLastSpiWrite = 0xFF;
  TlmModeCount = 0;
  TlmFifoCount = 0;
}

void telemetryAFHDS2ABeginCallback(uint8_t phaseBefore)
{
  TlmCaptureActive = telemetryAFHDS2AIsDataCallback(phaseBefore) && !IS_BIND_IN_PROGRESS;
  TlmPhaseBefore = phaseBefore;
  TlmLastSpiWrite = 0xFF;
  TlmModeCount = 0;
  TlmFifoCount = 0;
}

// Called by the C3 SPI adaptation after each byte written.
void telemetryAFHDS2ASpiWrite(uint8_t value)
{
  if(!TlmCaptureActive)
    return;

  TlmLastSpiWrite = value;
  if(value == 0x45) // 0x40 | A7105_05_FIFO_DATA: FIFO read command
    TlmFifoCount = 0;
}

// Called by the C3 SPI adaptation after each SDIO byte read.
void telemetryAFHDS2ASpiRead(uint8_t value)
{
  if(!TlmCaptureActive)
    return;

  if(TlmLastSpiWrite == 0x40) // MODE register read
  {
    if(TlmModeCount < sizeof(TlmMode))
      TlmMode[TlmModeCount++] = value;
    TlmLastSpiWrite = 0xFF; // one return byte per register read
  }
  else if(TlmLastSpiWrite == 0x45) // FIFO stream
  {
    if(TlmFifoCount < TLM_AFHDS2A_RX_LEN)
      TlmFifo[TlmFifoCount++] = value;
  }
}

void telemetryAFHDS2AEndCallback(uint8_t phaseBefore, uint8_t phaseAfter)
{
  (void)phaseAfter;
  if(!TlmCaptureActive || !telemetryAFHDS2AIsDataCallback(phaseBefore))
  {
    TlmCaptureActive = false;
    return;
  }

  TlmDataCallbacks++;

  uint8_t mode0 = 0xFF;
  uint8_t mode1 = 0xFF;
  if(TlmModeCount >= 1)
  {
    mode0 = TlmMode[0];
    TlmMode0Count++;
    if(!(mode0 & 0x01))
      TlmRxReadyCount++;
  }
  if(TlmModeCount >= 2)
  {
    mode1 = TlmMode[1];
    TlmMode1Count++;
    if(!(mode1 & 0x20))
      TlmCrcOkCount++;
  }
  if(TlmModeCount >= 2 && !(mode0 & 0x01) && !(mode1 & 0x20))
    TlmGateCount++;

  if(TlmFifoCount)
  {
    TlmFifoReadCount++;
    telemetryAFHDS2AStoreEvent(phaseBefore, mode0, mode1, TlmFifo, TlmFifoCount);

    const uint8_t type = TlmFifo[0];
    if(type == 0xAA)
      TlmPacketAA++;
    else if(type == 0xAC)
      TlmPacketAC++;
    else
      TlmPacketOther++;

    if(TlmFifoCount >= TLM_AFHDS2A_RX_LEN && (type == 0xAA || type == 0xAC))
    {
      if(memcmp(&TlmFifo[1], rx_tx_addr, 4) != 0)
      {
        TlmPacketBadAddr++;
      }
      else if(type == 0xAA && TlmFifo[9] == 0xFD)
      {
        TlmPacketConfig++;
      }
      else if(type == 0xAA && TlmFifo[9] == 0xFC)
      {
        TlmPacketSettingsReq++;
      }
      else
      {
        TlmPacketValid++;
        TlmLastValidMs = millis();
        telemetryAFHDS2ADecodeSensors(TlmFifo, TlmFifoCount);
        btTelemetryCapture(TlmFifo, TlmFifoCount);
      }
    }
  }

  TlmCaptureActive = false;
}

bool telemetryAFHDS2AHasValidPacket()
{
  return TlmPacketValid != 0;
}

uint32_t telemetryAFHDS2AValidPacketCount()
{
  return TlmPacketValid;
}

uint32_t telemetryAFHDS2ALastPacketAgeMs()
{
  if(!TlmLastValidMs)
    return 0xFFFFFFFFUL;
  return (uint32_t)(millis() - TlmLastValidMs);
}

bool telemetryAFHDS2AHasGpsLat()      { return TlmHasGpsLat; }
bool telemetryAFHDS2AHasGpsLon()      { return TlmHasGpsLon; }
bool telemetryAFHDS2AHasGpsSat()      { return TlmHasGpsSat; }
bool telemetryAFHDS2AHasGpsCog()      { return TlmHasGpsCog; }
bool telemetryAFHDS2AHasGpsSpeed()    { return TlmHasGpsSpeed; }
int32_t telemetryAFHDS2AGpsLatE7()     { return TlmGpsLatE7; }
int32_t telemetryAFHDS2AGpsLonE7()     { return TlmGpsLonE7; }
uint8_t telemetryAFHDS2AGpsSat()       { return TlmGpsSat; }
uint16_t telemetryAFHDS2AGpsCogX100()  { return TlmGpsCogX100; }
uint16_t telemetryAFHDS2AGpsSpeedX100(){ return TlmGpsSpeedX100; }

bool telemetryAFHDS2AHasGpsAlt()        { return TlmHasGpsAlt; }
int32_t telemetryAFHDS2AGpsAltX100()    { return TlmGpsAltX100; }
bool telemetryAFHDS2AHasVarioAlt()      { return TlmHasVarioAlt; }
bool telemetryAFHDS2AHasVarioVSpeed()   { return TlmHasVarioVSpeed || TlmHasVarioClimbRate; }
int32_t telemetryAFHDS2AVarioAltX100()  { return TlmVarioAltX100; }
int16_t telemetryAFHDS2AVarioVSpeedX100(){ return TlmHasVarioVSpeed ? TlmVarioVSpeedX100 : TlmVarioClimbRateX100; }

bool telemetryAFHDS2AHasRxVoltage()    { return TlmHasRxVoltage; }
uint16_t telemetryAFHDS2ARxVoltageX100(){ return TlmRxVoltageX100; }
bool telemetryAFHDS2AHasV1()           { return TlmHasV1; }
bool telemetryAFHDS2AHasCurrent()      { return TlmHasCurrent; }
uint16_t telemetryAFHDS2AV1X100()      { return TlmV1X100; }
int16_t telemetryAFHDS2ACurrentX100()  { return TlmCurrentX100; }

void telemetryAFHDS2APrintStatus()
{
  Serial.printf("Telemetry RX: fifo=%lu valid=%lu AA=%lu AC=%lu badAddr=%lu age=",
                (unsigned long)TlmFifoReadCount,
                (unsigned long)TlmPacketValid,
                (unsigned long)TlmPacketAA,
                (unsigned long)TlmPacketAC,
                (unsigned long)TlmPacketBadAddr);
  if(!TlmLastValidMs)
    Serial.println("never");
  else
    Serial.printf("%lu ms\r\n", (unsigned long)(millis() - TlmLastValidMs));
}

static void telemetryAFHDS2APrintSignedX100(int32_t value)
{
  const int64_t a = value < 0 ? -(int64_t)value : (int64_t)value;
  Serial.printf("%s%lld.%02llu", value < 0 ? "-" : "",
                (long long)(a / 100LL), (unsigned long long)(a % 100LL));
}

static void telemetryAFHDS2APrintGpsSummary()
{
  Serial.println("[TLM] GPS:");
  if(TlmHasGpsLat)
  {
    const int64_t a = TlmGpsLatE7 < 0 ? -(int64_t)TlmGpsLatE7 : (int64_t)TlmGpsLatE7;
    Serial.printf("  LAT=%s%ld.%07lu deg\r\n", TlmGpsLatE7 < 0 ? "-" : "",
                  (long)(a / 10000000LL), (unsigned long)(a % 10000000LL));
  }
  if(TlmHasGpsLon)
  {
    const int64_t a = TlmGpsLonE7 < 0 ? -(int64_t)TlmGpsLonE7 : (int64_t)TlmGpsLonE7;
    Serial.printf("  LON=%s%ld.%07lu deg\r\n", TlmGpsLonE7 < 0 ? "-" : "",
                  (long)(a / 10000000LL), (unsigned long)(a % 10000000LL));
  }
  if(TlmHasGpsSat) Serial.printf("  SAT=%u\r\n", TlmGpsSat);
  if(TlmHasGpsCog) Serial.printf("  COG=%u.%02u deg\r\n", TlmGpsCogX100 / 100, TlmGpsCogX100 % 100);
  if(TlmHasGpsSpeed)
  {
    Serial.printf("  GSPD=%u.%02u m/s (AFHDS ID 13 raw=%u)\r\n",
                  TlmGpsSpeedX100 / 100, TlmGpsSpeedX100 % 100, TlmGpsSpeedX100);
    // oXs RP2040 currently converts its source cm/s with: source * 36 / 1000.
    // That conversion is lossy. Reverse it only as a diagnostic estimate.
    const uint32_t oxsCmS = ((uint32_t)TlmGpsSpeedX100 * 1000UL + 18UL) / 36UL;
    Serial.printf("  GSPD_oXs_est=%lu cm/s (lossy reverse of RP2040 conversion)\r\n",
                  (unsigned long)oxsCmS);
  }
  if(TlmHasGpsAlt)
  {
    Serial.print("  ALT=");
    telemetryAFHDS2APrintSignedX100(TlmGpsAltX100);
    Serial.println(" m (GPS ID 82)");
  }
  if(!TlmHasGpsLat && !TlmHasGpsLon && !TlmHasGpsSat && !TlmHasGpsCog && !TlmHasGpsSpeed && !TlmHasGpsAlt)
    Serial.println("  none seen");
}

static unsigned long telemetryAFHDS2AAgeMs(uint32_t atMs)
{
  return atMs ? (unsigned long)(millis() - atMs) : 0xFFFFFFFFUL;
}

static void telemetryAFHDS2APrintVarioSummary()
{
  Serial.println("[TLM] Vario:");
  if(TlmHasVarioAlt)
  {
    Serial.print("  ALT=");
    telemetryAFHDS2APrintSignedX100(TlmVarioAltX100);
    Serial.printf(" m (ID %02X age=%lums)\r\n", TlmVarioAltSource, telemetryAFHDS2AAgeMs(TlmVarioAltLastMs));
  }
  if(TlmHasVarioVSpeed)
  {
    Serial.print("  VSPEED=");
    telemetryAFHDS2APrintSignedX100(TlmVarioVSpeedX100);
    Serial.printf(" m/s (ID %02X, %d cm/s age=%lums)\r\n",
                  TlmVarioVSpeedSource, (int)TlmVarioVSpeedX100, telemetryAFHDS2AAgeMs(TlmVarioVSpeedLastMs));
  }
  if(!TlmHasVarioAlt && !TlmHasVarioVSpeed && !TlmHasVarioClimbRate)
    Serial.println("  none seen");
}

static void telemetryAFHDS2APrintTemperatureSummary()
{
  Serial.println("[TLM] Temperatures:");
  uint8_t n = 0;
  for(uint8_t i = 0; i < TLM_AFHDS2A_TEMP_MAX; i++)
  {
    if(!TlmTemps[i].seen)
      continue;

    n++;
    const int32_t t = TlmTemps[i].x10;
    const int32_t a = t < 0 ? -t : t;
    Serial.printf("  TEMP%u=%s%ld.%01ld C (ID %02X inst=%u raw=%u/0x%04X)\r\n",
                  n, t < 0 ? "-" : "", (long)(a / 10), (long)(a % 10),
                  TlmTemps[i].id, TlmTemps[i].instance,
                  TlmTemps[i].raw, TlmTemps[i].raw);
    Serial.printf("    age=%lums\r\n", telemetryAFHDS2AAgeMs(TlmTemps[i].lastMs));
    if(TlmTemps[i].id == 0x01)
      Serial.printf("    radio formula: raw-400=%d -> %s%ld.%01ld C\r\n",
                    (int)((int32_t)TlmTemps[i].raw - 400L),
                    t < 0 ? "-" : "", (long)(a / 10), (long)(a % 10));
  }
  if(n == 0)
    Serial.println("  none seen");
}

static void telemetryAFHDS2APrintRpmSummary()
{
  Serial.println("[TLM] RPM:");
  uint8_t n = 0;
  for(uint8_t i = 0; i < TLM_AFHDS2A_RPM_MAX; i++)
  {
    if(!TlmRpms[i].seen)
      continue;

    n++;
    Serial.printf("  RPM%u=%u (ID %02X inst=%u age=%lums)\r\n",
                  n, TlmRpms[i].rpm, TlmRpms[i].id, TlmRpms[i].instance, telemetryAFHDS2AAgeMs(TlmRpms[i].lastMs));
  }
  if(n == 0)
    Serial.println("  none seen");
}

static void telemetryAFHDS2APrintSensorSummary()
{
  Serial.println("[TLM] Power / receiver:");
  if(TlmHasRxVoltage) Serial.printf("  ID 00 RX=%u.%02u V (raw=%u)\r\n",
                                    TlmRxVoltageX100 / 100, TlmRxVoltageX100 % 100, TlmRxVoltageX100);
  if(TlmHasV1) Serial.printf("  ID 03 V1=%u.%02u V (raw=%u)\r\n",
                             TlmV1X100 / 100, TlmV1X100 % 100, TlmV1X100);
  if(TlmHasCurrent)
  {
    const int32_t c = TlmCurrentX100;
    Serial.printf("  ID 05 CURRENT=%s%ld.%02ld A (raw=%d = %ld mA)\r\n",
                  c < 0 ? "-" : "", labs(c) / 100, labs(c) % 100,
                  (int)TlmCurrentX100, (long)c * 10L);
    Serial.printf("    age=%lums\r\n", telemetryAFHDS2AAgeMs(TlmCurrentLastMs));
    if(TlmCurrentX100 == 0)
      Serial.println("    oXs RP2040 note: negative source current is clamped to 0 before iBUS TX");
  }
  if(TlmHasCapacity)
  {
    Serial.printf("  ID 06 CAPACITY raw=%u (signed16=%d age=%lums)\r\n",
                  TlmCapacityRaw, (int16_t)TlmCapacityRaw, telemetryAFHDS2AAgeMs(TlmCapacityLastMs));
  }
  if(TlmHasErrRate)   Serial.printf("  ID FE RX_ERR_RATE raw=%u (MPM RX_LQI)\r\n", TlmErrRate);
  if(TlmHasRxRssi)    Serial.printf("  ID FC RX_RSSI raw=%u -> MPM=%d\r\n", TlmRxRssiRaw, -(int)TlmRxRssiRaw);
  if(TlmHasRxNoise)   Serial.printf("  ID FB RX_NOISE raw=%u\r\n", TlmRxNoiseRaw);
  if(TlmHasRxSnr)     Serial.printf("  ID FA RX_SNR raw=%u\r\n", TlmRxSnrRaw);
  if(!TlmHasRxVoltage && !TlmHasV1 && !TlmHasCurrent && !TlmHasCapacity && !TlmHasErrRate &&
     !TlmHasRxRssi && !TlmHasRxNoise && !TlmHasRxSnr)
    Serial.println("  none seen");
}

void telemetryAFHDS2APrintLog()
{
  Serial.println();
  Serial.println("========== AFHDS2A TELEMETRY LOG ==========");
  Serial.printf("[TLM] last valid age=%lums\r\n", telemetryAFHDS2ALastPacketAgeMs());
  Serial.printf("[TLM] callbacks=%lu MODE0=%lu MODE1=%lu ready=%lu crcOK=%lu gate=%lu FIFO=%lu\r\n",
                (unsigned long)TlmDataCallbacks,
                (unsigned long)TlmMode0Count,
                (unsigned long)TlmMode1Count,
                (unsigned long)TlmRxReadyCount,
                (unsigned long)TlmCrcOkCount,
                (unsigned long)TlmGateCount,
                (unsigned long)TlmFifoReadCount);
  Serial.printf("[TLM] packet AA=%lu AC=%lu other=%lu valid=%lu badAddr=%lu cfgFD=%lu reqFC=%lu\r\n",
                (unsigned long)TlmPacketAA,
                (unsigned long)TlmPacketAC,
                (unsigned long)TlmPacketOther,
                (unsigned long)TlmPacketValid,
                (unsigned long)TlmPacketBadAddr,
                (unsigned long)TlmPacketConfig,
                (unsigned long)TlmPacketSettingsReq);
  Serial.printf("[TLM] MPM vars: LQI=%u%% ERR=%u%% RX_RSSI=%d TX_RSSI=%u V1=%u V2=%u\r\n",
                rxLqiPercent(), RX_LQI, (int8_t)RX_RSSI, TX_RSSI, v_lipo1, v_lipo2);

  telemetryAFHDS2APrintGpsSummary();
  telemetryAFHDS2APrintVarioSummary();
  telemetryAFHDS2APrintTemperatureSummary();
  telemetryAFHDS2APrintRpmSummary();
  telemetryAFHDS2APrintSensorSummary();

  if(TlmEventCount == 0)
  {
    Serial.println("[TLM] no A7105 FIFO RX packet captured in DATA mode");
    Serial.println("============================================");
    return;
  }

  Serial.println("[TLM] Last FIFO packets (oldest -> newest):");
  uint8_t start = (TlmEventWrite + TLM_AFHDS2A_EVENT_MAX - TlmEventCount) % TLM_AFHDS2A_EVENT_MAX;
  for(uint8_t n = 0; n < TlmEventCount; n++)
  {
    const uint8_t idx = (start + n) % TLM_AFHDS2A_EVENT_MAX;
    const TelemetryAFHDS2AEvent &e = TlmEvents[idx];
    Serial.printf("[TLM] t=%lu phase=%02X MODE=%02X/%02X len=%u :",
                  (unsigned long)e.atMs,
                  e.phaseBefore,
                  e.mode0,
                  e.mode1,
                  e.len);
    for(uint8_t i = 0; i < e.len; i++)
      Serial.printf(" %02X", e.data[i]);
    Serial.println();
  }
  Serial.println("============================================");
}
