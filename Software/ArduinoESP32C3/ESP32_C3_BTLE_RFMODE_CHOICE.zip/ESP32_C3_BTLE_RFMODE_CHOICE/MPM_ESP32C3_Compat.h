#pragma once

#include <Arduino.h>
#include <pgmspace.h>
#include "soc/gpio_struct.h"

// -----------------------------------------------------------------------------
// Minimal compatibility layer for the original MPM AFHDS2A/A7105 sources.
// The goal is to keep AFHDS2A_a7105.ino, A7105_SPI.ino and iface_a7105.h
// as close as possible to Pascal Langer's Multi-Protocol Module project.
// -----------------------------------------------------------------------------

#ifndef _BV
#define _BV(bit) (1U << (bit))
#endif

#ifndef NOP
#define NOP() __asm__ __volatile__("nop")
#endif

#ifndef pgm_read_byte_near
#define pgm_read_byte_near(addr) pgm_read_byte(addr)
#endif

#define A7105_INSTALLED
#define AFHDS2A_A7105_INO
#define AFHDS2A_FW_TELEMETRY
#define TELEMETRY

// Protocol IDs kept identical to MPM Multiprotocol.h where referenced by
// A7105_SPI.ino.
enum PROTOCOLS_C3 {
  PROTO_FLYSKY     = 1,
  PROTO_HUBSAN     = 2,
  PROTO_AFHDS2A    = 28,
  PROTO_BUGS       = 41,
  PROTO_HEIGHT     = 53,
  PROTO_AFHDS2A_RX = 56,
  PROTO_PELIKAN    = 60,
  PROTO_KYOSHO     = 73,
  PROTO_WFLY2      = 79,
  PROTO_JOYSWAY    = 84
};

enum AFHDS2A_SUBPROTO_C3 {
  PWM_IBUS             = 0,
  PPM_IBUS             = 1,
  PWM_SBUS             = 2,
  PPM_SBUS             = 3,
  AFHDS2A_GYRO_OFF     = 4,
  AFHDS2A_GYRO_ON      = 5,
  AFHDS2A_GYRO_ON_REV  = 6
};

#define KYOSHO_HYPE   1
#define HEIGHT_8CH    1
#define PELIKAN_SCX24 2

// Channel definitions copied from MPM TX_Def.h.
#define CH1   0
#define CH2   1
#define CH3   2
#define CH4   3
#define CH5   4
#define CH6   5
#define CH7   6
#define CH8   7
#define CH9   8
#define CH10  9
#define CH11 10
#define CH12 11
#define CH13 12
#define CH14 13
#define CH15 14
#define CH16 15

#define CHANNEL_MAX_100     1844
#define CHANNEL_MIN_100      204
#define CHANNEL_MID         1024
#define CHANNEL_MIN_COMMAND  409
#define CHANNEL_SWITCH      1106
#define CHANNEL_MAX_COMMAND 1639

#define CH16_SW (Channel_data[CH16] > CHANNEL_SWITCH)

// A7105 front-end state, same names as MPM.
enum TXRX_State {
  TXRX_OFF,
  TX_EN,
  RX_EN
};

// A7105 power values copied from MPM Multiprotocol.h.
enum A7105_POWER {
  A7105_POWER_0 = (0x00 << 3) | 0x00,
  A7105_POWER_1 = (0x00 << 3) | 0x01,
  A7105_POWER_2 = (0x00 << 3) | 0x02,
  A7105_POWER_3 = (0x00 << 3) | 0x04,
  A7105_POWER_4 = (0x01 << 3) | 0x05,
  A7105_POWER_5 = (0x02 << 3) | 0x07,
  A7105_POWER_6 = (0x03 << 3) | 0x07,
  A7105_POWER_7 = (0x03 << 3) | 0x07
};

#define A7105_HIGH_POWER  A7105_POWER_7
#define A7105_LOW_POWER   A7105_POWER_3
#define A7105_RANGE_POWER A7105_POWER_0
#define A7105_BIND_POWER  A7105_POWER_0

// MPM EEPROM locations used by AFHDS2A bind/model match.
#define AFHDS2A_EEPROM_OFFSET  50
#define AFHDS2A_EEPROM_OFFSET2 250
#define EE_ADDR uint16_t

// MPM flags. Keep the original semantics and names.
#define POWER_FLAG_on      protocol_flags |= _BV(2)
#define POWER_FLAG_off     protocol_flags &= ~_BV(2)
#define IS_POWER_FLAG_on   ((protocol_flags & _BV(2)) != 0)

#define RANGE_FLAG_on      protocol_flags |= _BV(3)
#define RANGE_FLAG_off     protocol_flags &= ~_BV(3)
#define IS_RANGE_FLAG_on   ((protocol_flags & _BV(3)) != 0)

#define PPM_FLAG_off       protocol_flags &= ~_BV(6)
#define PPM_FLAG_on        protocol_flags |= _BV(6)
#define IS_PPM_FLAG_on     ((protocol_flags & _BV(6)) != 0)

#define BIND_IN_PROGRESS   protocol_flags &= ~_BV(7)
#define BIND_DONE          protocol_flags |= _BV(7)
#define IS_BIND_DONE       ((protocol_flags & _BV(7)) != 0)
#define IS_BIND_IN_PROGRESS ((protocol_flags & _BV(7)) == 0)

#define FAILSAFE_VALUES_off protocol_flags2 &= ~_BV(0)
#define FAILSAFE_VALUES_on  protocol_flags2 |= _BV(0)
#define IS_FAILSAFE_VALUES_on ((protocol_flags2 & _BV(0)) != 0)

#define delayMilliseconds(ms) delay(ms)

// -----------------------------------------------------------------------------
// ESP32-C3 direct GPIO implementation for the original MPM SPI.ino macros.
// Keep the presentation intentionally close to MPM Pins.h (AVR/Orange style):
// pin name + direct SET/CLEAR/input/output-enable register operations.
//
// pinMode() is still used once in setup() to attach the pads to GPIO and keep
// the SDIO input buffer enabled. The time-critical SPI path below then touches
// GPIO registers directly; no digitalWrite()/digitalRead()/pinMode() is used.
// A7105 is 3-wire: SDIO is GPIO8 and changes output-enable for reads.
// -----------------------------------------------------------------------------

// SDIO
#define SDI_pin         A7105_SDIO_PIN
#define SDI_on          GPIO.out_w1ts.val = _BV(SDI_pin)
#define SDI_off         GPIO.out_w1tc.val = _BV(SDI_pin)
#define SDI_1           (GPIO.in.val & _BV(SDI_pin))
#define SDI_0           ((GPIO.in.val & _BV(SDI_pin)) == 0x00)
#define SDI_input       GPIO.enable_w1tc.val = _BV(SDI_pin)
#define SDI_output      GPIO.enable_w1ts.val = _BV(SDI_pin)

// SCLK
#define SCLK_pin        A7105_SCK_PIN
#define SCLK_output     GPIO.enable_w1ts.val = _BV(SCLK_pin)
#define SCLK_on         GPIO.out_w1ts.val = _BV(SCLK_pin)
#define SCLK_off        GPIO.out_w1tc.val = _BV(SCLK_pin)

// A7105
#define A7105_CSN_pin       A7105_CSN_PIN
#define A7105_CSN_output    GPIO.enable_w1ts.val = _BV(A7105_CSN_pin)
#define A7105_CSN_on        GPIO.out_w1ts.val = _BV(A7105_CSN_pin)
#define A7105_CSN_off       GPIO.out_w1tc.val = _BV(A7105_CSN_pin)

// Generic MPM SPI_Read() compatibility only; A7105 uses SPI_SDI_Read().
#define SDO_1           SDI_1
#define SDO_0           SDI_0
