#pragma once

// ============================================================================
// Bluetooth LE telemetry bridge API
// ============================================================================
// Implemented in BT_LE.ino.
// The existing RF/tlog path remains independent; the RF callback only copies
// accepted telemetry bytes to a small RAM queue for later BLE transmission.

#include <Arduino.h>

static void btLoadPreference();
static void btBegin();
static void btProcess();
static void btSetEnabled(bool enabled);
static bool btIsEnabled();
static void btPrintStatus();
static void btSimuSet(bool enabled);
static bool btSimuIsEnabled();
static void btSimuReset();
static void btTelemetryCapture(const uint8_t* p, uint8_t len);
