#pragma once

// ============================================================================
// AFHDS2A bind / identity wrapper
// ============================================================================
// Refactoring only: bind supervision, bind diagnostics/logger and TX/RX
// identity helpers were moved out of the main sketch. Protocol behavior is
// intentionally unchanged.

#include <Arduino.h>

extern bool BindTimerActive;
extern uint32_t BindStartMs;
extern bool RfRebindRequired;
extern volatile bool RfTelemetryProofPending;

static void bindInitButtonState();
static void bindBeginBootSession();

static bool receiverIdLooksValid();
static void refreshRfBindState();
static void storeRfBindState(bool ok);
static void invalidateRfBindState();
static void set_rx_tx_addr(uint32_t id);
static uint32_t makeBoardTxId();
static uint32_t makeRandomTxId(uint32_t previous);
static uint32_t loadOrCreateTxId();
static bool applyTxId(uint32_t id, bool save);
static uint8_t rxLqiPercent();
static const char* rfLinkStateText();
static void processRfLinkValidation();

static void bindDiagReset();
static void bindDiagBeginCallback();
void bindDiagSpiWrite(uint8_t value);
void bindDiagSpiRead(uint8_t value);
static void bindDiagEndCallback(uint8_t phaseBefore);

static void bindLogReset();
static void bindLogCapture(uint8_t phaseBefore, uint8_t phaseAfter);

static void startBind();
static void processBindSupervision();
static void processStatusLed();
static void processBindButton();
