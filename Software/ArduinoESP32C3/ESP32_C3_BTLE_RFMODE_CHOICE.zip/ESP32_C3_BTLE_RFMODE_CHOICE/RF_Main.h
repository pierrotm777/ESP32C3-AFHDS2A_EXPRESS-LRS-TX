#pragma once

#include <Arduino.h>
#include "RF_Config.h"

// Runtime RF backend selector.
extern uint8_t RfModeCurrent;

static inline bool rfModeIsAfhds2a(void)
{
  return RfModeCurrent == RF_MODE_AFHDS2A;
}

static inline bool rfModeIsCrsf(void)
{
  return RfModeCurrent == RF_MODE_CRSF;
}

void rfLoadPreference(void);
void rfPrintMode(void);
void rfSetModeAndRestart(uint8_t Mode);
