#pragma once

// ============================================================================
// PCF8574 / PCF8574A SW8 configuration and API
// ============================================================================
// Refactoring only: constants and public API were moved out of
// PCF8574_SW8.ino / AF2A_C3_BTLE_v1.ino. Runtime behavior is unchanged.

#include <Arduino.h>

static constexpr uint32_t PCF_SW8_POLL_US = 5000UL;
static constexpr uint32_t PCF_SW8_DEBOUNCE_US = 10000UL;

// API implemented in PCF8574_SW8.ino.
static void pcfSw8Begin(void);
static void pcfSw8Process(void);
static void pcfSw8PrintStatus(void);
static void pcfSw8Scan(void);
