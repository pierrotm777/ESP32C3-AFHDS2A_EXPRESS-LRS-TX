/*
 This project is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 Multiprotocol is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Multiprotocol.  If not, see <http://www.gnu.org/licenses/>.
 */
/********************/
/**  SPI routines  **/
/********************/

// ESP32-C3 adaptation of the original MPM software SPI interface.
// Function names and bit order are intentionally kept identical.

void SPI_Write(uint8_t command)
{
  const uint8_t diagCommand = command;
  uint8_t n = 8;

  SCLK_off; // SCK starts low
  NOP();
  SDI_off;
  NOP();
  do
  {
    if(command & 0x80)
      SDI_on;
    else
      SDI_off;

    NOP();
    SCLK_on;
    NOP();
    NOP();
    command <<= 1;
    SCLK_off;
    NOP();
  }
  while(--n);

  SDI_on;

  // Passive RAM-only diagnostics. No Serial output here.
  bindDiagSpiWrite(diagCommand);
  telemetryAFHDS2ASpiWrite(diagCommand);
}

// Kept for compatibility with the original common MPM SPI API.
// The A7105 itself uses SPI_SDI_Read() because SDIO is bidirectional.
uint8_t SPI_Read(void)
{
  uint8_t result = 0;
  for(uint8_t i = 0; i < 8; i++)
  {
    result <<= 1;
    if(SDO_1)
      result |= 0x01;
    SCLK_on;
    NOP();
    NOP();
    NOP();
    SCLK_off;
    NOP();
    NOP();
  }
  return result;
}

#ifdef A7105_INSTALLED
// Read one A7105 SDIO byte while the caller keeps SDIO configured as INPUT.
// This is used for FIFO burst reads so the ESP32-C3 does not call pinMode()
// for every byte while CSN remains low.
uint8_t SPI_SDI_ReadBurstByte(void)
{
  uint8_t result = 0;

  for(uint8_t i = 0; i < 8; i++)
  {
    result <<= 1;
    if(SDI_1)
      result |= 0x01;
    SCLK_on;
    NOP();
    SCLK_off;
  }

  bindDiagSpiRead(result);
  telemetryAFHDS2ASpiRead(result);

  return result;
}

uint8_t SPI_SDI_Read(void)
{
  uint8_t result = 0;

  SDI_input;
  for(uint8_t i = 0; i < 8; i++)
  {
    result <<= 1;
    if(SDI_1)
      result |= 0x01;
    SCLK_on;
    NOP();
    SCLK_off;
  }
  SDI_output;

  // Passive RAM-only diagnostics. The last SPI write byte tells the
  // loggers whether this byte came from MODE (0x40) or FIFO (0x45).
  bindDiagSpiRead(result);
  telemetryAFHDS2ASpiRead(result);

  return result;
}
#endif
