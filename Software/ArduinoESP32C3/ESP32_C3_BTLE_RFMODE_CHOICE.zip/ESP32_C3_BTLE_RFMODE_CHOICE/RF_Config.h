#pragma once

// ============================================================================
// RF backend IDs / default selection
// ============================================================================
// The active backend itself is selected at runtime and saved in Preferences
// by RF_Main.ino. First boot defaults to AFHDS2A.

#define RF_MODE_AFHDS2A 0
#define RF_MODE_CRSF     1
#define RF_MODE_DEFAULT  RF_MODE_AFHDS2A
