// ============================================================================
// CRSF / ELRS TX backend - first integration test
// ============================================================================
// This first step only does what is needed to validate the second HF path:
//   - full-duplex CRSF UART at 400 kbaud
//   - current Channel_data[0..15] -> microseconds -> RculCrsfSerial
//   - CRSF RC_CHANNELS_PACKED (0x16) every 4 ms / 250 Hz
//   - receive/process CRSF return traffic so link-statistics callback can be
//     observed later
//
// No CRSF telemetry is bridged to BLE/Android yet. No ELRS parameter/bind
// command is implemented here. Configure the ELRS TX target separately first.

#include "CRSF_Main.h"

static HardwareSerial CrsfUart(1);
static RculCrsfSerial Crsf(CrsfUart, CRSF_HANDSET_BAUD);

static uint32_t CrsfLastChannelsUs = 0;
static uint32_t CrsfTxChannelFrames = 0;
static uint32_t CrsfLinkStatsFrames = 0;
static crsfLinkStatistics_t CrsfLastLinkStats = {};
static bool CrsfLinkStatsSeen = false;

static void crsfOnLinkStatistics(crsfLinkStatistics_t *ls)
{
  if(ls == nullptr)
    return;

  CrsfLastLinkStats = *ls;
  CrsfLinkStatsSeen = true;
  CrsfLinkStatsFrames++;
}

static uint16_t crsfChannelUs(uint8_t channel)
{
  uint16_t us = convert_channel_ppm(channel);

  // RculCrsfSerial supports the CRSF extended-limits endpoints. Clamp only the
  // copy sent to CRSF; Channel_data[] itself is never modified.
  if(us < CRSF_ELIMIT_US_MIN) us = CRSF_ELIMIT_US_MIN;
  if(us > CRSF_ELIMIT_US_MAX) us = CRSF_ELIMIT_US_MAX;
  return us;
}

static void crsfLoadChannels(void)
{
  for(uint8_t ch = 0; ch < CRSF_NUM_CHANNELS; ch++)
    Crsf.setChannel((unsigned int)ch + 1U, crsfChannelUs(ch));
}

static void crsfBegin(void)
{
  // UART idle is HIGH. Pull-up on RX also gives a defined local level if the
  // ELRS module is absent during a bench power-up (after ESP32 boot straps have
  // already been sampled).
  pinMode(CRSF_RX_PIN, INPUT_PULLUP);
  pinMode(CRSF_TX_PIN, OUTPUT);
  digitalWrite(CRSF_TX_PIN, HIGH);

  CrsfUart.begin(CRSF_HANDSET_BAUD, SERIAL_8N1, CRSF_RX_PIN, CRSF_TX_PIN);//RX=2, TX=9
  Crsf.begin(); // ESP32: port is already configured above; initializes RCUL state.
  Crsf.onPacketLinkStatistics = &crsfOnLinkStatistics;

  crsfLoadChannels();
  CrsfLastChannelsUs = micros();
  CrsfTxChannelFrames = 0;
  CrsfLinkStatsFrames = 0;
  CrsfLinkStatsSeen = false;

  // In CRSF mode there is no AFHDS2A bind state. Mark the shared legacy flag
  // done so the existing XANY RCUL generator is not paused by its bind guard.
  BIND_DONE;

  digitalWrite(PIN_LED, HIGH);

  if(!StartupConsoleQuiet)
  {
    Serial.println("[CRSF] ELRS TX backend started");
    Serial.printf("[CRSF] UART1 %lu baud  TX=GPIO%d -> ELRS RX  RX=GPIO%d <- ELRS TX\r\n",
                  (unsigned long)CRSF_HANDSET_BAUD, CRSF_TX_PIN, CRSF_RX_PIN);
    Serial.printf("[CRSF] RC_CHANNELS_PACKED 16ch every %lu us (~%lu Hz)\r\n",
                  (unsigned long)CRSF_CHANNEL_SEND_INTERVAL_US,
                  (unsigned long)(1000000UL / CRSF_CHANNEL_SEND_INTERVAL_US));
  }
}

static void crsfProcess(void)
{
  // Process return traffic first (link statistics / future telemetry path).
  Crsf.loop();

  const uint32_t now = micros();
  if((uint32_t)(now - CrsfLastChannelsUs) < CRSF_CHANNEL_SEND_INTERVAL_US)
    return;

  // Keep cadence tied to the previous deadline and recover cleanly after a
  // long pause without creating a burst of queued channel frames.
  CrsfLastChannelsUs += CRSF_CHANNEL_SEND_INTERVAL_US;
  if((uint32_t)(now - CrsfLastChannelsUs) > 20000UL)
    CrsfLastChannelsUs = now;

  // PPM/SWEEP, motor safety and XANY have already updated Channel_data[] in the
  // main loop before this function is called. CRSF is therefore only another
  // transport for the same 16 logical channels.
  crsfLoadChannels();
  Crsf.queuePacketChannels();
  CrsfTxChannelFrames++;
}

static void crsfPrintStatus(void)
{
  Serial.println();
  Serial.println("========== CRSF / ELRS STATUS ==========");
  Serial.printf("[CRSF] UART1 baud=%lu TX=GPIO%d RX=GPIO%d interval=%luus txCH=%lu\r\n",
                (unsigned long)CRSF_HANDSET_BAUD,
                CRSF_TX_PIN, CRSF_RX_PIN,
                (unsigned long)CRSF_CHANNEL_SEND_INTERVAL_US,
                (unsigned long)CrsfTxChannelFrames);

  if(CrsfLinkStatsSeen)
  {
    Serial.printf("[CRSF] linkstats=%lu UL_LQ=%u UL_RSSI1=%u UL_RSSI2=%u UL_SNR=%d RFMD=%u PWR=%u DL_LQ=%u\r\n",
                  (unsigned long)CrsfLinkStatsFrames,
                  CrsfLastLinkStats.uplink_Link_quality,
                  CrsfLastLinkStats.uplink_RSSI_1,
                  CrsfLastLinkStats.uplink_RSSI_2,
                  CrsfLastLinkStats.uplink_SNR,
                  CrsfLastLinkStats.rf_Mode,
                  CrsfLastLinkStats.uplink_TX_Power,
                  CrsfLastLinkStats.downlink_Link_quality);
  }
  else
  {
    Serial.printf("[CRSF] linkstats=WAIT rxAvailable=%d\r\n", CrsfUart.available());
  }

  Serial.print("[CRSF] CH us:");
  for(uint8_t ch = 0; ch < CRSF_NUM_CHANNELS; ch++)
  {
    Serial.print(' ');
    Serial.print(crsfChannelUs(ch));
  }
  Serial.println();
  Serial.println("========================================");
}
