RCUL DEBUG UNIVERSAL - RculToOutput.h
=====================================

BUT
---
Séparer complètement le transport RCUL réel du diagnostic envoyé au plugin.

Le transport réel ne change jamais :
  RcTxSerial -> RculI2cPotTx / RculAfhds2aXany / SBUS / CRSF / ...

Le debug est un miroir passif :
  Valeurs applicatives -> RculToOutput.h -> Serial -> RCUL Monitor

AJOUT MINIMAL
-------------
En haut du projet :

  #define RCUL_TO_OUTPUT_ENABLE 1
  #include "RculToOutput.h"

Puis juste après sendNibbleMsg() :

SW8
  MyRcTxSerial.sendNibbleMsg(Message, 2, 1);
  RCUL_DEBUG_SW8(Message[0]);

SW8+PROP
  // Message[0] = PROP
  // Message[1] = SW8
  MyRcTxSerial.sendNibbleMsg(Message, 4, 1);
  RCUL_DEBUG_SW8_PROP(Message[1], Message[0]);

SW16
  MyRcTxSerial.sendNibbleMsg(Message, 4, 1);
  uint16_t sw16 = ((uint16_t)Message[0] << 8) | Message[1];
  RCUL_DEBUG_SW16(sw16);

SW16+PROP
  // Convention du projet fourni :
  // Message[0] = PROP
  // Message[1] = SW16 high (SW9..SW16)
  // Message[2] = SW16 low  (SW1..SW8)
  MyRcTxSerial.sendNibbleMsg(Message, 6, 1);
  uint16_t sw16 = ((uint16_t)Message[1] << 8) | Message[2];
  RCUL_DEBUG_SW16_PROP(sw16, Message[0]);

ANGLE+PROP
  // ANGLE = 12 bits, PROP = 8 bits
  MyRcTxSerial.sendNibbleMsg(Message, 5, 1);
  RCUL_DEBUG_ANGLE_PROP(angle, prop);

SUPPRIMER LE DEBUG
------------------
Il suffit de passer :

  #define RCUL_TO_OUTPUT_ENABLE 0

Les appels RCUL_DEBUG_* restent dans le source mais ne génèrent aucun code utile.

IMPORTANT
---------
Le canal CH1..CH16 n'est volontairement PAS envoyé par le sketch.
Il est choisi dans RCUL Monitor, comme demandé.
