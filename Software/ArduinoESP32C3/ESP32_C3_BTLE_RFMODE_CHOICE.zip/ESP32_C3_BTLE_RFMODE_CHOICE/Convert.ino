/*
  Minimal extraction from the MPM Convert.ino file.
  The original function names and formulas needed by AFHDS2A/A7105 are kept.
*/

// Channel value is converted to ppm 860<->2140 -125%<->+125%
// and 988<->2012 -100%<->+100%.
uint16_t convert_channel_ppm(uint8_t num)
{
  uint16_t val = Channel_data[num];
  return (((val << 2) + val) >> 3) + 860;
}

// Channel value is limited to 100%.
uint16_t limit_channel_100(uint8_t num)
{
  if(Channel_data[num] >= CHANNEL_MAX_100)
    return CHANNEL_MAX_100;
  if(Channel_data[num] <= CHANNEL_MIN_100)
    return CHANNEL_MIN_100;
  return Channel_data[num];
}

// Channel value 100% is converted to a scaled value.
int16_t convert_channel_16b_limit(uint8_t num, int16_t min, int16_t max)
{
  int32_t val = limit_channel_100(num);
  val = (val - CHANNEL_MIN_100) * (max - min) /
        (CHANNEL_MAX_100 - CHANNEL_MIN_100) + min;
  return (uint16_t)val;
}

// Channel value -125%<->125% is scaled to a 16-bit value with no limit.
int16_t convert_channel_16b_nolimit(uint8_t num, int16_t min, int16_t max, bool failsafe)
{
  (void)failsafe;
  int32_t val = Channel_data[num];
  val = (val - CHANNEL_MIN_100) * (max - min) /
        (CHANNEL_MAX_100 - CHANNEL_MIN_100) + min;
  return (uint16_t)val;
}
