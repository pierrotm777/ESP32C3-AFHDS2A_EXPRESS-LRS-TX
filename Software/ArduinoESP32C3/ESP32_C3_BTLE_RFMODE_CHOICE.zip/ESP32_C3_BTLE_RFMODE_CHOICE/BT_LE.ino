/*
  Bluetooth LE telemetry bridge for ESP32-C3.

  This tab is intentionally self-contained. The existing AFHDS2A RF, PPM,
  XANY, OLED and tlog code stays unchanged except for small hook calls from
  AF2A_C3.ino / Telemetry_AFHDS2A.ino.

  BLE wire format is selected automatically from the active RF backend:

    AFHDS2A: 'M' 'P' TYPE LENGTH PAYLOAD... (existing MULTI bridge)
    CRSF:    raw standard CRSF frames (sync/len/type/payload/crc)

  The same btsimu on/off command is used for both protocols. In CRSF mode the
  simulator emits standard Link Statistics, Battery, GPS, Vario and Attitude
  frames directly to BLE, so no ELRS RF module is required for the bench test.

  Console commands are handled by AF2A_C3.ino:
    bt / bt on / bt off
    btsimu / btsimu on / btsimu off / btsimu reset

  btsimu affects the BLE output only. Real RF telemetry acquisition and tlog
  continue normally in the background.
*/

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <math.h>

static const char* BTLE_DEVICE_NAME = "AF2A-C3";//Nom Bluetooth LE

// Nordic-UART-style UUIDs are used only as a convenient, well-known BLE
// container. The Android application scans all NOTIFY characteristics, so it
// does not depend on these UUIDs.
static const char* BTLE_SERVICE_UUID = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E";
static const char* BTLE_TX_UUID      = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E";

static constexpr uint8_t BTLE_QUEUE_SIZE = 4;
static constexpr uint8_t BTLE_MP_MAX_PAYLOAD = 29; // TX_RSSI + RF bytes 9..36
static constexpr uint8_t BTLE_NOTIFY_CHUNK = 20;   // safe even with MTU=23

struct BtLeFrame
{
  uint8_t type;                       // 0x06 AA, 0x0C AC
  uint8_t len;                        // payload bytes
  uint8_t payload[BTLE_MP_MAX_PAYLOAD];
};

static BLEServer* BtLeServer = nullptr;
static BLECharacteristic* BtLeTx = nullptr;
static volatile bool BtLeConnected = false;
static bool BtLeEnabled = false;
static bool BtLeStackStarted = false;
static bool BtLeSimuEnabled = false;

// BLE protocol-identification probe.
// The Android application considers a BLE link "connected" only after its
// protocol detector has decoded AFHDS2A data.  With no powered/recognized RF
// receiver there is no live telemetry to forward, so the GATT link can be up
// while Android is still waiting and eventually reports "connection failed".
//
// Send a few sensor-less MULTI/AFHDS2A frames just after each BLE connection.
// They identify the stream as AFHDS2A without inventing receiver sensor data
// and do not touch the RF/PPM/XANY/tlog paths.
static constexpr uint32_t BTLE_PROBE_START_DELAY_MS = 800UL;
static constexpr uint32_t BTLE_PROBE_PERIOD_MS      = 500UL;
static constexpr uint8_t  BTLE_PROBE_MAX_FRAMES     = 8;
static volatile bool BtLeProbePending = false;
static uint32_t BtLeConnectedAtMs = 0;
static uint32_t BtLeLastProbeMs = 0;
static uint8_t BtLeProbeFramesSent = 0;

static BtLeFrame BtLeQueue[BTLE_QUEUE_SIZE];
static volatile uint8_t BtLeQueueRead = 0;
static volatile uint8_t BtLeQueueWrite = 0;
static volatile uint8_t BtLeQueueCount = 0;
static portMUX_TYPE BtLeQueueMux = portMUX_INITIALIZER_UNLOCKED;

static uint32_t BtLeFramesCaptured = 0;
static uint32_t BtLeFramesSent = 0;
static uint32_t BtLeFramesDropped = 0;
static uint32_t BtLeSimFramesSent = 0;

// MULTI type 0x0D: RC channel forwarding.
// We intentionally forward only CH1..CH8 over BLE.  Channel_data[] remains
// owned/updated by the existing PPM/XANY code; this BLE tab only takes a copy.
static constexpr uint8_t  BTLE_RC_CHANNEL_COUNT = 8;
static constexpr uint32_t BTLE_RC_PERIOD_MS = 100UL; // 10 Hz, enough for UI
static uint32_t BtLeRcLastMs = 0;

// ---------------------------------------------------------------------------
// GPS / battery simulator state.
// The GPS route contains 20 regularly spaced positions between point A and
// point B. It is read forward, then backward, continuously (A -> B -> A).
// The two end points are about 95 m apart, so one point per second gives an
// actual displacement close to the simulated 5 m/s (18 km/h).
// ---------------------------------------------------------------------------
static constexpr double BT_SIM_POINT_A_LAT = 48.8566000;
static constexpr double BT_SIM_POINT_A_LON = 2.3522000;
static constexpr double BT_SIM_POINT_B_LAT = 48.8571390;
static constexpr double BT_SIM_POINT_B_LON = 2.3532110;
static constexpr uint8_t BT_SIM_POINT_COUNT = 20;
static constexpr double BT_SIM_SPEED_MS = 5.0;
static constexpr uint32_t BT_SIM_PERIOD_MS = 1000UL;
static constexpr uint16_t BT_SIM_VOLTAGE_START_X100 = 1260; // 12.60 V
static constexpr uint16_t BT_SIM_VOLTAGE_END_X100   = 1080; // 10.80 V

static uint8_t BtSimPointIndex = 0;
static int8_t BtSimPointDirection = 1;
static uint16_t BtSimVoltageX100 = BT_SIM_VOLTAGE_START_X100;
static uint16_t BtSimCapacityMah = 0;
static uint32_t BtSimLastMs = 0;
static uint32_t BtSimLastVoltageMs = 0;

class BtLeServerCallbacks : public BLEServerCallbacks
{
  void onConnect(BLEServer* server) override
  {
    (void)server;
    BtLeConnected = true;
    BtLeProbePending = true;
    BtLeConnectedAtMs = millis();
    BtLeLastProbeMs = 0;
    BtLeProbeFramesSent = 0;
  }

  void onDisconnect(BLEServer* server) override
  {
    (void)server;
    BtLeConnected = false;
    BtLeProbePending = false;
    BtLeConnectedAtMs = 0;
    BtLeLastProbeMs = 0;
    BtLeProbeFramesSent = 0;
    if(BtLeEnabled && BtLeStackStarted)
      BLEDevice::startAdvertising();
  }
};

static BtLeServerCallbacks BtLeCallbacks;

static void btQueueClear()
{
  portENTER_CRITICAL(&BtLeQueueMux);
  BtLeQueueRead = 0;
  BtLeQueueWrite = 0;
  BtLeQueueCount = 0;
  portEXIT_CRITICAL(&BtLeQueueMux);
}

static void btLoadPreference()
{
  BtLeEnabled = prefs.getBool("btle", false);
}

static bool btIsEnabled()
{
  return BtLeEnabled;
}

static bool btSimuIsEnabled()
{
  return BtLeSimuEnabled;
}

static void btStartStack()
{
  if(BtLeStackStarted || !BtLeEnabled)
    return;

  BLEDevice::init(BTLE_DEVICE_NAME);
  BtLeServer = BLEDevice::createServer();
  BtLeServer->setCallbacks(&BtLeCallbacks);

  BLEService* service = BtLeServer->createService(BTLE_SERVICE_UUID);
  BtLeTx = service->createCharacteristic(
      BTLE_TX_UUID,
      BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
  BtLeTx->setValue((uint8_t*)"", 0);

  service->start();

  BLEAdvertising* advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(BTLE_SERVICE_UUID);
  advertising->setScanResponse(true);
  advertising->start();

  BtLeStackStarted = true;
  BtLeConnected = false;
  if(!StartupConsoleQuiet) Serial.printf("[BTLE] ON - advertising as %s\r\n", BTLE_DEVICE_NAME);
}

static void btStopStack()
{
  BtLeSimuEnabled = false;
  btQueueClear();

  if(BtLeStackStarted)
  {
    BLEDevice::stopAdvertising();
    BLEDevice::deinit(false);
  }

  BtLeTx = nullptr;
  BtLeServer = nullptr;
  BtLeConnected = false;
  BtLeProbePending = false;
  BtLeConnectedAtMs = 0;
  BtLeLastProbeMs = 0;
  BtLeProbeFramesSent = 0;
  BtLeRcLastMs = 0;
  BtLeStackStarted = false;
}

static void btBegin()
{
  // Preference is loaded separately in setup() so it can be shown in the
  // common [PREFS] startup line before the BLE stack is started.
  if(BtLeEnabled)
    btStartStack();
  else
    if(!StartupConsoleQuiet) Serial.println("[BTLE] OFF (saved preference)");
}

static void btSetEnabled(bool enabled)
{
  if(BtLeEnabled == enabled)
  {
    Serial.printf("[BTLE] already %s\r\n", enabled ? "ON" : "OFF");
    return;
  }

  BtLeEnabled = enabled;
  prefs.putBool("btle", BtLeEnabled);

  if(BtLeEnabled)
  {
    btStartStack();
    Serial.println("[BTLE] ON saved");
  }
  else
  {
    btStopStack();
    Serial.println("[BTLE] OFF saved");
  }
}

static void btSimuReset()
{
  BtSimPointIndex = 0;
  BtSimPointDirection = 1;
  BtSimVoltageX100 = BT_SIM_VOLTAGE_START_X100;
  BtSimCapacityMah = 0;
  BtSimLastMs = 0;
  BtSimLastVoltageMs = millis();
  BtLeRcLastMs = 0;
  btQueueClear();
  Serial.printf("[BTSIMU] reset protocol=%s GPS=%.7f,%.7f route=%upts A<->B VBAT=%.2fV\r\n",
                rfModeIsAfhds2a() ? "AFHDS2A" : "CRSF",
                BT_SIM_POINT_A_LAT, BT_SIM_POINT_A_LON,
                (unsigned)BT_SIM_POINT_COUNT,
                (double)BtSimVoltageX100 / 100.0);
}

static void btSimuSet(bool enabled)
{
  if(enabled && !BtLeEnabled)
  {
    Serial.println("[BTSIMU] BT LE is OFF - use 'bt on' first");
    return;
  }

  if(BtLeSimuEnabled == enabled)
  {
    Serial.printf("[BTSIMU] already %s\r\n", enabled ? "ON" : "OFF");
    return;
  }

  BtLeSimuEnabled = enabled;
  btQueueClear();

  if(BtLeSimuEnabled)
  {
    btSimuReset();
    Serial.printf("[BTSIMU] ON - protocol auto=%s, no HF module required\r\n",
                  rfModeIsAfhds2a() ? "AFHDS2A" : "CRSF/ELRS");
  }
  else
  {
    if(rfModeIsAfhds2a())
      Serial.println("[BTSIMU] OFF - BLE output returned to live AFHDS2A telemetry");
    else
      Serial.println("[BTSIMU] OFF - CRSF simulator stopped (live CRSF BLE bridge not added yet)");
  }
}

static void btPrintStatus()
{
  Serial.printf("Bluetooth LE: %s stack=%s link=%s name=%s protocol=%s simu=%s queue=%u captured=%lu sent=%lu drop=%lu sim=%lu\r\n",
                BtLeEnabled ? "ON" : "OFF",
                BtLeStackStarted ? "UP" : "DOWN",
                BtLeConnected ? "CONNECTED" : "WAIT",
                BTLE_DEVICE_NAME,
                rfModeIsAfhds2a() ? "AFHDS2A" : "CRSF",
                BtLeSimuEnabled ? "ON" : "OFF",
                (unsigned)BtLeQueueCount,
                (unsigned long)BtLeFramesCaptured,
                (unsigned long)BtLeFramesSent,
                (unsigned long)BtLeFramesDropped,
                (unsigned long)BtLeSimFramesSent);
}

// Called from Telemetry_AFHDS2A.ino after a valid addressed RF packet has been
// accepted and decoded. This function only copies bytes into RAM; it never
// calls the BLE stack from the high-priority RF timer task.
static void btTelemetryCapture(const uint8_t* p, uint8_t len)
{
  if(!BtLeEnabled || !BtLeConnected || BtLeSimuEnabled || !p || len < 37)
    return;

  uint8_t mpType;
  if(p[0] == 0xAA)
    mpType = 0x06;
  else if(p[0] == 0xAC)
    mpType = 0x0C;
  else
    return;

  BtLeFrame frame;
  frame.type = mpType;
  frame.len = BTLE_MP_MAX_PAYLOAD;
  frame.payload[0] = TX_RSSI;
  memcpy(&frame.payload[1], &p[9], 28);

  portENTER_CRITICAL(&BtLeQueueMux);
  if(BtLeQueueCount >= BTLE_QUEUE_SIZE)
  {
    // Keep the freshest telemetry. Drop the oldest queued frame.
    BtLeQueueRead = (uint8_t)((BtLeQueueRead + 1) % BTLE_QUEUE_SIZE);
    BtLeQueueCount = (uint8_t)(BtLeQueueCount - 1);
    BtLeFramesDropped++;
  }
  BtLeQueue[BtLeQueueWrite] = frame;
  BtLeQueueWrite = (uint8_t)((BtLeQueueWrite + 1) % BTLE_QUEUE_SIZE);
  BtLeQueueCount = (uint8_t)(BtLeQueueCount + 1);
  BtLeFramesCaptured++;
  portEXIT_CRITICAL(&BtLeQueueMux);
}

// Do not use BtLeFrame in this function signature. Arduino IDE 1.8.x
// auto-generates function prototypes before local struct declarations and would
// otherwise generate an invalid prototype for BtLeFrame. Primitive pointer
// arguments keep the tab compatible with the classic Arduino preprocessor.
static bool btQueuePop(uint8_t* type, uint8_t* len, uint8_t* payload)
{
  bool haveFrame = false;

  if(!type || !len || !payload)
    return false;

  portENTER_CRITICAL(&BtLeQueueMux);
  if(BtLeQueueCount)
  {
    const BtLeFrame& frame = BtLeQueue[BtLeQueueRead];
    *type = frame.type;
    *len = frame.len;
    memcpy(payload, frame.payload, frame.len);
    BtLeQueueRead = (uint8_t)((BtLeQueueRead + 1) % BTLE_QUEUE_SIZE);
    BtLeQueueCount = (uint8_t)(BtLeQueueCount - 1);
    haveFrame = true;
  }
  portEXIT_CRITICAL(&BtLeQueueMux);

  return haveFrame;
}

static bool btNotifyBytes(const uint8_t* data, uint8_t len)
{
  if(!BtLeConnected || !BtLeTx || !data || !len)
    return false;

  uint8_t offset = 0;
  while(offset < len)
  {
    const uint8_t chunk = (uint8_t)min((int)BTLE_NOTIFY_CHUNK, (int)(len - offset));
    BtLeTx->setValue((uint8_t*)&data[offset], chunk);
    BtLeTx->notify();
    offset = (uint8_t)(offset + chunk);

    // Keep notifications ordered on peers that remain at the default MTU=23.
    if(offset < len)
      delay(1);
  }
  return true;
}

static bool btSendMpFrame(uint8_t type, const uint8_t* payload, uint8_t payloadLen)
{
  if(!payload || payloadLen == 0 || payloadLen > BTLE_MP_MAX_PAYLOAD)
    return false;

  uint8_t frame[4 + BTLE_MP_MAX_PAYLOAD];
  frame[0] = 'M';
  frame[1] = 'P';
  frame[2] = type;
  frame[3] = payloadLen;
  memcpy(&frame[4], payload, payloadLen);

  if(!btNotifyBytes(frame, (uint8_t)(payloadLen + 4)))
    return false;

  BtLeFramesSent++;
  return true;
}


// CRSF uses CRC8 with polynomial 0xD5 over TYPE + PAYLOAD.
// Keep this local to the BLE bridge so the simulator does not depend on the
// internal implementation details of RculCrsfSerial.
static uint8_t btCrsfCrc8(const uint8_t* data, uint8_t len)
{
  uint8_t crc = 0;
  while(len--)
  {
    crc ^= *data++;
    for(uint8_t bit = 0; bit < 8; bit++)
      crc = (crc & 0x80U) ? (uint8_t)((crc << 1) ^ 0xD5U) : (uint8_t)(crc << 1);
  }
  return crc;
}

static void btWriteU16BE(uint8_t* p, uint16_t value)
{
  p[0] = (uint8_t)(value >> 8);
  p[1] = (uint8_t)(value & 0xFFU);
}

static void btWriteS16BE(uint8_t* p, int16_t value)
{
  btWriteU16BE(p, (uint16_t)value);
}

static void btWriteU24BE(uint8_t* p, uint32_t value)
{
  p[0] = (uint8_t)((value >> 16) & 0xFFU);
  p[1] = (uint8_t)((value >> 8) & 0xFFU);
  p[2] = (uint8_t)(value & 0xFFU);
}

static void btWriteS32BE(uint8_t* p, int32_t value)
{
  const uint32_t u = (uint32_t)value;
  p[0] = (uint8_t)((u >> 24) & 0xFFU);
  p[1] = (uint8_t)((u >> 16) & 0xFFU);
  p[2] = (uint8_t)((u >> 8) & 0xFFU);
  p[3] = (uint8_t)(u & 0xFFU);
}

static bool btSendCrsfFrame(uint8_t type, const uint8_t* payload, uint8_t payloadLen)
{
  // CRSF length byte = TYPE + PAYLOAD + CRC. The simulated frames below are
  // deliberately <= 20 bytes total so one BLE notification carries one frame.
  if(payloadLen > 60U)
    return false;

  uint8_t frame[64];
  frame[0] = 0xC8; // CRSF sync / flight-controller address
  frame[1] = (uint8_t)(payloadLen + 2U);
  frame[2] = type;
  if(payloadLen && payload)
    memcpy(&frame[3], payload, payloadLen);
  frame[3U + payloadLen] = btCrsfCrc8(&frame[2], (uint8_t)(payloadLen + 1U));

  if(!btNotifyBytes(frame, (uint8_t)(payloadLen + 4U)))
    return false;

  BtLeFramesSent++;
  return true;
}

// Send one minimal AFHDS2A MULTI frame containing only MULTI TX_RSSI.
// Afhds2aProtocol accepts payload length 1, and two such frames are enough for
// the Android protocol detector.  No receiver voltage/GPS/RSSI sensor record is
// fabricated here.
static void btSendProtocolProbe()
{
  if(!rfModeIsAfhds2a())
    return;

  if(!BtLeProbePending || !BtLeConnected || !BtLeTx || BtLeSimuEnabled)
    return;

  const uint32_t now = millis();
  if((uint32_t)(now - BtLeConnectedAtMs) < BTLE_PROBE_START_DELAY_MS)
    return;

  if(BtLeLastProbeMs && (uint32_t)(now - BtLeLastProbeMs) < BTLE_PROBE_PERIOD_MS)
    return;

  BtLeLastProbeMs = now;

  // Payload[0] is MULTI TX_RSSI.  Keep the current value if available; when
  // there is no RF receiver it is normally zero, which is appropriate.
  const uint8_t payload[1] = { TX_RSSI };
  if(btSendMpFrame(0x06, payload, 1))
  {
    BtLeProbeFramesSent++;
    if(BtLeProbeFramesSent >= BTLE_PROBE_MAX_FRAMES)
      BtLeProbePending = false;
  }
}

static void btSendRcChannels()
{
  if(!rfModeIsAfhds2a())
    return;

  if(!BtLeConnected || !BtLeTx)
    return;

  const uint32_t now = millis();
  if(BtLeRcLastMs && (uint32_t)(now - BtLeRcLastMs) < BTLE_RC_PERIOD_MS)
    return;
  BtLeRcLastMs = now;

  // 8 channels * 11 bits = 88 bits = 11 packed bytes.
  // MULTI type 0x0D payload header adds four bytes.
  uint8_t payload[4 + 11] = {0};
  payload[0] = 0;        // received packets/s: not applicable on this TX bridge
  payload[1] = TX_RSSI;  // keep the current MULTI RSSI byte
  payload[2] = 0;        // first forwarded channel = CH1 (zero-based)
  payload[3] = BTLE_RC_CHANNEL_COUNT;

  uint32_t bitBuffer = 0;
  uint8_t bitsInBuffer = 0;
  uint8_t out = 4;

  for(uint8_t ch = 0; ch < BTLE_RC_CHANNEL_COUNT; ch++)
  {
    // Existing project convention is already MPM 0..2047.
    uint16_t value = Channel_data[ch];
    if(value > 2047U)
      value = 2047U;

    bitBuffer |= ((uint32_t)value << bitsInBuffer);
    bitsInBuffer = (uint8_t)(bitsInBuffer + 11U);

    while(bitsInBuffer >= 8U)
    {
      payload[out++] = (uint8_t)(bitBuffer & 0xFFU);
      bitBuffer >>= 8U;
      bitsInBuffer = (uint8_t)(bitsInBuffer - 8U);
    }
  }

  if(bitsInBuffer && out < sizeof(payload))
    payload[out++] = (uint8_t)(bitBuffer & 0xFFU);

  btSendMpFrame(0x0D, payload, out);
}

static void btWriteU16LE(uint8_t* p, uint16_t value)
{
  p[0] = (uint8_t)(value & 0xFF);
  p[1] = (uint8_t)(value >> 8);
}

static void btWriteS32LE(uint8_t* p, int32_t value)
{
  const uint32_t u = (uint32_t)value;
  p[0] = (uint8_t)(u & 0xFF);
  p[1] = (uint8_t)((u >> 8) & 0xFF);
  p[2] = (uint8_t)((u >> 16) & 0xFF);
  p[3] = (uint8_t)((u >> 24) & 0xFF);
}

// CRSF/ELRS BLE simulator. This is intentionally independent of the CRSF UART
// and therefore also works with no Nano/ELRS RF module connected.
static void btSendCrsfSimulation()
{
  if(!BtLeSimuEnabled || !BtLeConnected || !rfModeIsCrsf())
    return;

  const uint32_t now = millis();
  if(BtSimLastMs && (uint32_t)(now - BtSimLastMs) < BT_SIM_PERIOD_MS)
    return;
  BtSimLastMs = now;

  if(!BtSimLastVoltageMs)
    BtSimLastVoltageMs = now;
  if((uint32_t)(now - BtSimLastVoltageMs) >= 1000UL)
  {
    BtSimLastVoltageMs = now;
    if(BtSimVoltageX100 > BT_SIM_VOLTAGE_END_X100)
    {
      BtSimVoltageX100--;
      if(BtSimCapacityMah <= 65531U)
        BtSimCapacityMah = (uint16_t)(BtSimCapacityMah + 4U);
    }
    else
    {
      BtSimVoltageX100 = BT_SIM_VOLTAGE_START_X100;
      BtSimCapacityMah = 0;
    }
  }

  const double routeT = (double)BtSimPointIndex / (double)(BT_SIM_POINT_COUNT - 1);
  const double lat = BT_SIM_POINT_A_LAT
                   + (BT_SIM_POINT_B_LAT - BT_SIM_POINT_A_LAT) * routeT;
  const double lon = BT_SIM_POINT_A_LON
                   + (BT_SIM_POINT_B_LON - BT_SIM_POINT_A_LON) * routeT;
  const double altM = 25.0 + 5.0 * sin(routeT * PI);

  const double meanLatRad = ((BT_SIM_POINT_A_LAT + BT_SIM_POINT_B_LAT) * 0.5) * DEG_TO_RAD;
  const double north = BT_SIM_POINT_B_LAT - BT_SIM_POINT_A_LAT;
  const double east = (BT_SIM_POINT_B_LON - BT_SIM_POINT_A_LON) * cos(meanLatRad);
  double headingDeg = atan2(east, north) * RAD_TO_DEG;
  if(headingDeg < 0.0)
    headingDeg += 360.0;
  if(BtSimPointDirection < 0)
  {
    headingDeg += 180.0;
    if(headingDeg >= 360.0)
      headingDeg -= 360.0;
  }

  const double wave = sin(routeT * PI);
  const double vSpeedMs = (double)BtSimPointDirection
                        * (5.0 * PI / (double)(BT_SIM_POINT_COUNT - 1))
                        * cos(routeT * PI);
  const double rollDeg = 20.0 * sin(routeT * 2.0 * PI);
  const double pitchDeg = 10.0 * cos(routeT * 2.0 * PI);
  double yawDeg = headingDeg;
  if(yawDeg > 180.0)
    yawDeg -= 360.0;

  // CRSF LINK_STATISTICS (0x14), 10-byte payload.
  uint8_t link[10];
  link[0] = 45;  // uplink RSSI1 -> -45 dBm
  link[1] = 48;  // uplink RSSI2 -> -48 dBm
  link[2] = 95;  // uplink LQ %
  link[3] = (uint8_t)(int8_t)12; // uplink SNR dB
  link[4] = 0;   // active antenna
  link[5] = 2;   // RF mode/rate index (simulated)
  link[6] = 3;   // TX power index (simulated)
  link[7] = 55;  // downlink RSSI -> -55 dBm
  link[8] = 90;  // downlink LQ %
  link[9] = (uint8_t)(int8_t)8; // downlink SNR dB
  btSendCrsfFrame(0x14, link, sizeof(link));

  // CRSF BATTERY_SENSOR (0x08): 0.1 V, 0.1 A, capacity mAh (24-bit), %.
  uint8_t battery[8];
  const uint16_t voltageX10 = (uint16_t)((BtSimVoltageX100 + 5U) / 10U);
  const uint16_t currentX10 = (uint16_t)lround(70.0 + 60.0 * wave); // 7..13 A
  btWriteU16BE(&battery[0], voltageX10);
  btWriteU16BE(&battery[2], currentX10);
  btWriteU24BE(&battery[4], BtSimCapacityMah);
  battery[7] = (uint8_t)constrain((int)((BtSimVoltageX100 - BT_SIM_VOLTAGE_END_X100) * 100L /
                                       (BT_SIM_VOLTAGE_START_X100 - BT_SIM_VOLTAGE_END_X100)), 0, 100);
  btSendCrsfFrame(0x08, battery, sizeof(battery));

  // CRSF GPS (0x02): lat/lon 1e-7 deg, speed 0.1 km/h, heading 0.01 deg,
  // altitude in whole metres with +1000 m CRSF offset, satellites.
  uint8_t gps[15];
  btWriteS32BE(&gps[0], (int32_t)llround(lat * 10000000.0));
  btWriteS32BE(&gps[4], (int32_t)llround(lon * 10000000.0));
  btWriteU16BE(&gps[8], (uint16_t)lround(BT_SIM_SPEED_MS * 3.6 * 10.0));
  btWriteU16BE(&gps[10], (uint16_t)lround(headingDeg * 100.0));
  btWriteU16BE(&gps[12], (uint16_t)lround(altM + 1000.0));
  gps[14] = 10;
  btSendCrsfFrame(0x02, gps, sizeof(gps));

  // CRSF VARIO (0x07): vertical speed in cm/s.
  uint8_t vario[2];
  btWriteS16BE(vario, (int16_t)lround(vSpeedMs * 100.0));
  btSendCrsfFrame(0x07, vario, sizeof(vario));

  // CRSF ATTITUDE (0x1E): pitch/roll/yaw in radians * 10000.
  uint8_t attitude[6];
  btWriteS16BE(&attitude[0], (int16_t)lround(pitchDeg * DEG_TO_RAD * 10000.0));
  btWriteS16BE(&attitude[2], (int16_t)lround(rollDeg  * DEG_TO_RAD * 10000.0));
  btWriteS16BE(&attitude[4], (int16_t)lround(yawDeg   * DEG_TO_RAD * 10000.0));
  btSendCrsfFrame(0x1E, attitude, sizeof(attitude));

  BtLeSimFramesSent += 5;

  if(BtSimPointDirection > 0)
  {
    if(BtSimPointIndex + 1 >= BT_SIM_POINT_COUNT)
    {
      BtSimPointDirection = -1;
      if(BtSimPointIndex > 0)
        BtSimPointIndex--;
    }
    else
      BtSimPointIndex++;
  }
  else
  {
    if(BtSimPointIndex == 0)
    {
      BtSimPointDirection = 1;
      if(BT_SIM_POINT_COUNT > 1)
        BtSimPointIndex++;
    }
    else
      BtSimPointIndex--;
  }
}

static void btSendSimulation()
{
  if(!BtLeSimuEnabled || !BtLeConnected)
    return;

  const uint32_t now = millis();
  if(BtSimLastMs && (uint32_t)(now - BtSimLastMs) < BT_SIM_PERIOD_MS)
    return;
  BtSimLastMs = now;

  // Battery: 12.60 V -> 10.80 V in 0.01 V steps, then restart.
  if(!BtSimLastVoltageMs)
    BtSimLastVoltageMs = now;
  if((uint32_t)(now - BtSimLastVoltageMs) >= 1000UL)
  {
    BtSimLastVoltageMs = now;
    if(BtSimVoltageX100 > BT_SIM_VOLTAGE_END_X100)
    {
      BtSimVoltageX100--;
      if(BtSimCapacityMah <= 65531U)
        BtSimCapacityMah = (uint16_t)(BtSimCapacityMah + 4U);
    }
    else
    {
      BtSimVoltageX100 = BT_SIM_VOLTAGE_START_X100;
      BtSimCapacityMah = 0;
    }
  }

  // Twenty GPS positions between A and B. The index is played forward then
  // backward so there is no discontinuous GPS jump when the route loops.
  const double routeT = (double)BtSimPointIndex / (double)(BT_SIM_POINT_COUNT - 1);
  const double lat = BT_SIM_POINT_A_LAT
                   + (BT_SIM_POINT_B_LAT - BT_SIM_POINT_A_LAT) * routeT;
  const double lon = BT_SIM_POINT_A_LON
                   + (BT_SIM_POINT_B_LON - BT_SIM_POINT_A_LON) * routeT;
  const double altM = 25.0 + 5.0 * sin(routeT * PI);

  // Heading follows the route direction. Equirectangular approximation is
  // more than sufficient for this ~95 m simulator path.
  const double meanLatRad = ((BT_SIM_POINT_A_LAT + BT_SIM_POINT_B_LAT) * 0.5) * DEG_TO_RAD;
  const double north = BT_SIM_POINT_B_LAT - BT_SIM_POINT_A_LAT;
  const double east = (BT_SIM_POINT_B_LON - BT_SIM_POINT_A_LON) * cos(meanLatRad);
  double headingDeg = atan2(east, north) * RAD_TO_DEG;
  if(headingDeg < 0.0)
    headingDeg += 360.0;
  if(BtSimPointDirection < 0)
  {
    headingDeg += 180.0;
    if(headingDeg >= 360.0)
      headingDeg -= 360.0;
  }

  // Additional simulated sensors.  These are BLE-only test values: no RF,
  // AFHDS2A state machine, tlog, PPM or XANY data is modified.
  const double wave = sin(routeT * PI);
  const uint16_t cellVoltageX100 = (uint16_t)(BtSimVoltageX100 / 3U);
  const uint16_t currentX100 = (uint16_t)lround(700.0 + 600.0 * wave);  // 7..13 A
  const double vSpeedMs = (double)BtSimPointDirection
                        * (5.0 * PI / (double)(BT_SIM_POINT_COUNT - 1))
                        * cos(routeT * PI);
  const int16_t vSpeedX100 = (int16_t)lround(vSpeedMs * 100.0);
  const int16_t rollX100 = (int16_t)lround(20.0 * sin(routeT * 2.0 * PI) * 100.0);
  const int16_t pitchX100 = (int16_t)lround(10.0 * cos(routeT * 2.0 * PI) * 100.0);
  double yawSignedDeg = headingDeg;
  if(yawSignedDeg > 180.0)
    yawSignedDeg -= 360.0;
  const int16_t yawX100 = (int16_t)lround(yawSignedDeg * 100.0);
  const uint16_t distanceM = (uint16_t)lround(95.0 * routeT);
  const double temperatureC = 25.0 + 15.0 * wave;
  const uint16_t temperatureRaw = (uint16_t)lround(temperatureC * 10.0 + 400.0);
  const uint16_t rpm = (uint16_t)lround(3200.0 + 2800.0 * wave);
  const uint16_t snr = (uint16_t)lround(20.0 + 10.0 * wave);

  // AA #1: values already understood by the current Android v16 display.
  // Exactly seven 4-byte AFHDS2A records fit after MULTI TX_RSSI.
  uint8_t aa[29];
  uint8_t i = 0;
  aa[i++] = 220; // MULTI TX_RSSI
  aa[i++] = 0x03; aa[i++] = 0x00;
  btWriteU16LE(&aa[i], BtSimVoltageX100); i += 2;       // model battery V*100
  aa[i++] = 0x04; aa[i++] = 0x00;
  btWriteU16LE(&aa[i], cellVoltageX100); i += 2;        // cell voltage V*100
  aa[i++] = 0x05; aa[i++] = 0x00;
  btWriteU16LE(&aa[i], currentX100); i += 2;            // current A*100
  aa[i++] = 0x06; aa[i++] = 0x00;
  btWriteU16LE(&aa[i], BtSimCapacityMah); i += 2;       // consumed capacity / fuel
  aa[i++] = 0x12; aa[i++] = 0x00;
  btWriteU16LE(&aa[i], (uint16_t)vSpeedX100); i += 2;   // vertical speed m/s*100
  aa[i++] = 0xFE; aa[i++] = 0x00;
  btWriteU16LE(&aa[i], 5); i += 2;                      // 5% error -> 95% LQ
  aa[i++] = 0xFC; aa[i++] = 0x00;
  btWriteU16LE(&aa[i], 45); i += 2;                     // -45 dBm
  btSendMpFrame(0x06, aa, i);

  // AA #2: attitude/distance/SNR plus temperature and RPM.  Temperature and
  // RPM are deliberately emitted now so the BLE simulator is ready for the
  // corresponding Android decoder/UI addition; Android v16 safely ignores
  // these two unknown IDs for the moment.
  uint8_t aa2[29];
  i = 0;
  aa2[i++] = 220;
  aa2[i++] = 0x14; aa2[i++] = 0x00;
  btWriteU16LE(&aa2[i], distanceM); i += 2;
  aa2[i++] = 0x0F; aa2[i++] = 0x00;
  btWriteU16LE(&aa2[i], (uint16_t)rollX100); i += 2;
  aa2[i++] = 0x10; aa2[i++] = 0x00;
  btWriteU16LE(&aa2[i], (uint16_t)pitchX100); i += 2;
  aa2[i++] = 0x11; aa2[i++] = 0x00;
  btWriteU16LE(&aa2[i], (uint16_t)yawX100); i += 2;
  aa2[i++] = 0xFA; aa2[i++] = 0x00;
  btWriteU16LE(&aa2[i], snr); i += 2;
  aa2[i++] = 0x01; aa2[i++] = 0x00;
  btWriteU16LE(&aa2[i], temperatureRaw); i += 2;        // (raw-400)/10 C
  aa2[i++] = 0x02; aa2[i++] = 0x00;
  btWriteU16LE(&aa2[i], rpm); i += 2;                   // motor RPM
  btSendMpFrame(0x06, aa2, i);

  // Extended telemetry frame: GPS_FULL + COG + ground speed.
  uint8_t ac[28];
  i = 0;
  ac[i++] = 220; // MULTI TX_RSSI

  ac[i++] = 0xFD; // GPS_FULL
  ac[i++] = 0x00; // instance
  ac[i++] = 14;   // payload size
  ac[i++] = 1;    // GPS fix
  ac[i++] = 10;   // satellites
  btWriteS32LE(&ac[i], (int32_t)llround(lat * 10000000.0)); i += 4;
  btWriteS32LE(&ac[i], (int32_t)llround(lon * 10000000.0)); i += 4;
  btWriteS32LE(&ac[i], (int32_t)llround(altM * 100.0)); i += 4;

  ac[i++] = 0x0A; // GPS COG x100
  ac[i++] = 0x00;
  ac[i++] = 2;
  btWriteU16LE(&ac[i], (uint16_t)lround(headingDeg * 100.0)); i += 2;

  ac[i++] = 0x13; // GPS ground speed, m/s x100
  ac[i++] = 0x00;
  ac[i++] = 2;
  btWriteU16LE(&ac[i], (uint16_t)lround(BT_SIM_SPEED_MS * 100.0)); i += 2;

  btSendMpFrame(0x0C, ac, i);

  // AC #2: barometric altitude plus a realistic packed pressure/temperature
  // record. Android v16 already displays ID 0x83 as Altitude. ID 0x41 is sent
  // for the next decoder step and is ignored harmlessly by v16.
  uint8_t acBaro[15];
  i = 0;
  acBaro[i++] = 220;
  acBaro[i++] = 0x83;
  acBaro[i++] = 0x00;
  acBaro[i++] = 4;
  btWriteS32LE(&acBaro[i], (int32_t)lround(altM * 100.0)); i += 4;

  const uint32_t pressurePa = (uint32_t)lround(101325.0 - altM * 12.0);
  const uint32_t pressurePacked = (pressurePa & 0x7FFFFUL)
                                | ((uint32_t)temperatureRaw << 19);
  acBaro[i++] = 0x41;
  acBaro[i++] = 0x00;
  acBaro[i++] = 4;
  btWriteS32LE(&acBaro[i], (int32_t)pressurePacked); i += 4;
  btSendMpFrame(0x0C, acBaro, i);

  BtLeSimFramesSent += 4;

  // Move to the next route point for the next simulator period.
  if(BtSimPointDirection > 0)
  {
    if(BtSimPointIndex + 1 >= BT_SIM_POINT_COUNT)
    {
      BtSimPointDirection = -1;
      if(BtSimPointIndex > 0)
        BtSimPointIndex--;
    }
    else
      BtSimPointIndex++;
  }
  else
  {
    if(BtSimPointIndex == 0)
    {
      BtSimPointDirection = 1;
      if(BT_SIM_POINT_COUNT > 1)
        BtSimPointIndex++;
    }
    else
      BtSimPointIndex--;
  }
}

static void btProcess()
{
  if(!BtLeEnabled || !BtLeStackStarted)
    return;

  if(rfModeIsCrsf())
  {
    // CRSF btsimu is a raw CRSF byte stream over BLE and needs no HF module.
    // Live UART->BLE CRSF telemetry forwarding is deliberately not part of
    // this first simulator test.
    if(BtLeSimuEnabled)
      btSendCrsfSimulation();
    else
      btQueueClear();
    return;
  }

  // AFHDS2A path below is the already validated MULTI BLE bridge.
  btSendProtocolProbe();
  btSendRcChannels();

  if(BtLeSimuEnabled)
  {
    btSendSimulation();
    return;
  }

  if(!BtLeConnected)
  {
    btQueueClear();
    return;
  }

  // Send at most one real telemetry frame per loop pass. The RF acquisition
  // itself remains fully independent in the ESP timer task.
  uint8_t type = 0;
  uint8_t len = 0;
  uint8_t payload[BTLE_MP_MAX_PAYLOAD];
  if(btQueuePop(&type, &len, payload))
    btSendMpFrame(type, payload, len);
}
