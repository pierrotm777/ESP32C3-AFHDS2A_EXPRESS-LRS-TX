#pragma once

// ============================================================================
// A7105 RF scheduler / ESP32-C3 timer API
// ============================================================================
// Refactoring only: the high-resolution scheduler was moved out of the main
// sketch. The original AFHDS2A callback cadence and fallback scheduler are
// intentionally unchanged.

#include <Arduino.h>

extern bool RadioOk;
extern bool RfUseEspTimer;
extern uint32_t NextProtocolUs;

static bool rfTimerInit();
static void rfTimerStart(uint32_t firstDelayUs);
static void rfTimerStop();
static void rfTimerResetLog();
static void rfTimerPrintLog();
static void processProtocol();
