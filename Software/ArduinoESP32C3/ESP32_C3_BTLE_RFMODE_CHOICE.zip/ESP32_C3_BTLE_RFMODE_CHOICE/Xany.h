#pragma once

// ============================================================================
// XANY configuration / bridge declaration
// ============================================================================
// Refactoring only: constants, bridge class and public XANY API were moved
// out of Xany_SW8.ino / AF2A_C3_BTLE_v1.ino. Runtime behavior is unchanged.

#include <Arduino.h>
#include <RcTxSerial.h>

static constexpr uint8_t XANY1_DEFAULT_CHANNEL = 5;
static constexpr uint8_t XANY2_DEFAULT_CHANNEL = 6;
static constexpr uint8_t XANY_REPEAT = RC_TX_SERIAL_REPEAT2;
static constexpr uint8_t XANY_FIFO_SIZE = 8;

// One RCUL symbol presentation per receiver servo frame. AFHDS2A is currently
// configured for 50 Hz servo output (option=0x80, low 7 bits = 0), therefore
// use a 20 ms strobe.
// Do NOT clock RcTxSerial from the 3.85 ms RF callback.
static constexpr uint32_t XANY_FRAME_US = 20000UL;

// RcTxSerial's idle symbol is 1976 us. Starting on a valid RCUL symbol avoids
// a meaningless 1500 us value before the first encoded frame is produced.
static constexpr uint16_t XANY_IDLE_US = 1976;

class RculAfhds2aXany : public Rcul
{
  private:
    uint8_t _Synchro = 0;
    uint16_t _WidthUs = XANY_IDLE_US;

  public:
    void signalFrame(void)
    {
      // RcTxSerial::process() walks every existing instance and assigns a
      // different ClientIdx. 0xFF allows this Rcul bridge to accept its slot.
      _Synchro = 0xFF;
    }

    uint16_t widthUs(void) const
    {
      return _WidthUs;
    }

    virtual uint8_t RculIsSynchro(uint8_t ClientIdx = RCUL_DEFAULT_CLIENT_IDX)
    {
      if(ClientIdx > 7)
        return 0;

      const uint8_t mask = (uint8_t)(1U << ClientIdx);
      const uint8_t ret = !!(_Synchro & mask);
      if(ret)
        _Synchro &= (uint8_t)~mask;
      return ret;
    }

    virtual uint16_t RculGetWidth_us(uint8_t Ch)
    {
      (void)Ch;
      return _WidthUs;
    }

    virtual void RculSetWidth_us(uint16_t Width_us, uint8_t Ch = RCUL_NO_CH)
    {
      (void)Ch;
      if(Width_us < 900) Width_us = 900;
      if(Width_us > 2100) Width_us = 2100;
      _WidthUs = Width_us;
    }
};

// API implemented in Xany_SW8.ino.
static void xanyBegin(void);
static void xanyProcess(void);
static bool xany1SetChannel(uint8_t Ch);
static bool xany2SetChannel(uint8_t Ch);
static void xany1SetEnabled(bool Enabled);
static void xany2SetEnabled(bool Enabled);
static bool xany1IsEnabled(void);
static bool xany2IsEnabled(void);
static void xany1SetSw8(uint8_t Value);
static void xany2SetSw8(uint8_t Value);
static void xany2SetProp(uint8_t Value);
static uint8_t xany1GetChannel(void);
static uint8_t xany2GetChannel(void);
static uint8_t xany1GetSw8(void);
static uint8_t xany2GetSw8(void);
static uint8_t xany2GetProp(void);
static void xany1PrintStatus(void);
static void xany2PrintStatus(void);
