/*
 * Xany_SW8.ino
 * --------------------------------------------------------------------------
 * RCUL X-Any bridges for the AFHDS2A transmitter.
 *
 * V1.13:
 *   - XANY1 = SW8, default CH5
 *   - XANY2 = SW8+PROP, default CH6
 *   - XANY1/XANY2 enable state saved in Preferences
 *   - each output channel selectable/saved from console
 *   - legacy RcTxSerial encoder
 *   - 2 repetitions (RC_TX_SERIAL_REPEAT2)
 *   - XANY1 SW8      = one byte  -> sendNibbleMsg(..., 2, 1)
 *   - XANY2 SW8+PROP = two bytes -> PROP first, SW8 second,
 *                                  sendNibbleMsg(..., 4, 1)
 *
 * Future XANY3/XANY4 instances can use the same bridge without modifying
 * AFHDS2A_a7105.ino. RcTxSerial simply generates RC pulse widths and this
 * adapter writes the selected widths into Channel_data[].
 */

// XANY constants, bridge class and API declarations are in Xany.h.

static RculAfhds2aXany Xany1Rcul;
static RculAfhds2aXany Xany2Rcul;

static RcTxSerial Xany1Tx(&Xany1Rcul,
                          XANY_REPEAT,
                          XANY_FIFO_SIZE,
                          XANY1_DEFAULT_CHANNEL);

static RcTxSerial Xany2Tx(&Xany2Rcul,
                          XANY_REPEAT,
                          XANY_FIFO_SIZE,
                          XANY2_DEFAULT_CHANNEL);

static uint8_t Xany1Channel = XANY1_DEFAULT_CHANNEL; // 1..14
static uint8_t Xany2Channel = XANY2_DEFAULT_CHANNEL; // 1..14
static bool Xany1Enabled = true;
static bool Xany2Enabled = true;

static uint8_t Xany1Sw8 = 0x00; // 8 ON/OFF bits
static uint8_t Xany2Sw8 = 0x00; // 8 ON/OFF bits
static uint8_t Xany2Prop = 0x80; // proportional byte 0..255, center=128

static uint32_t Xany1LastFrameUs = 0;
static uint32_t Xany2LastFrameUs = 0;

static bool xanyChannelIsValid(uint8_t Ch)
{
  return Ch >= 1 && Ch <= ACTIVE_CHANNELS;
}

static uint8_t xanyFindFreeChannel(uint8_t Preferred, uint8_t Other)
{
  if(xanyChannelIsValid(Preferred) && Preferred != MotorChannel && Preferred != Other)
    return Preferred;

  for(uint8_t ch = 1; ch <= ACTIVE_CHANNELS; ch++)
    if(ch != MotorChannel && ch != Other)
      return ch;

  return 0;
}

static void xany1ApplyChannel(void)
{
  if(!Xany1Enabled || !xanyChannelIsValid(Xany1Channel))
    return;

  // The motor channel is never allowed to be overwritten by X-Any.
  if(Xany1Channel == MotorChannel)
    return;

  Channel_data[Xany1Channel - 1] = ppmUsToMpmChannel(Xany1Rcul.widthUs());
}

static void xany2ApplyChannel(void)
{
  if(!Xany2Enabled || !xanyChannelIsValid(Xany2Channel))
    return;

  if(Xany2Channel == MotorChannel)
    return;

  Channel_data[Xany2Channel - 1] = ppmUsToMpmChannel(Xany2Rcul.widthUs());
}

static void xanyBegin(void)
{
  Xany1Enabled = prefs.getBool("x1on", false);
  Xany2Enabled = prefs.getBool("x2on", false);

  Xany1Channel = prefs.getUChar("x1ch", XANY1_DEFAULT_CHANNEL);
  if(!xanyChannelIsValid(Xany1Channel) || Xany1Channel == MotorChannel)
  {
    Xany1Channel = xanyFindFreeChannel(XANY1_DEFAULT_CHANNEL, 0);
    prefs.putUChar("x1ch", Xany1Channel);
  }

  Xany2Channel = prefs.getUChar("x2ch", XANY2_DEFAULT_CHANNEL);
  if(!xanyChannelIsValid(Xany2Channel) ||
     Xany2Channel == MotorChannel ||
     Xany2Channel == Xany1Channel)
  {
    Xany2Channel = xanyFindFreeChannel(XANY2_DEFAULT_CHANNEL, Xany1Channel);
    prefs.putUChar("x2ch", Xany2Channel);
  }

  Xany1Tx.setCh(Xany1Channel);
  Xany1Tx.setRepeatNb(XANY_REPEAT);
  Xany2Tx.setCh(Xany2Channel);
  Xany2Tx.setRepeatNb(XANY_REPEAT);

  Xany1Sw8 = 0x00;
  Xany2Sw8 = 0x00;
  Xany2Prop = 0x80;

  const uint32_t now = micros();
  Xany1LastFrameUs = now;
  Xany2LastFrameUs = now;

  if(!StartupConsoleQuiet)
  {
    Serial.printf("[XANY1] %s SW8 CH%u repeat=%u SW=0x%02X\r\n",
                  Xany1Enabled ? "ON" : "OFF",
                  Xany1Channel,
                  (unsigned)XANY_REPEAT,
                  Xany1Sw8);
    Serial.printf("[XANY2] %s SW8+PROP CH%u repeat=%u PROP=%u SW=0x%02X\r\n",
                  Xany2Enabled ? "ON" : "OFF",
                  Xany2Channel,
                  (unsigned)XANY_REPEAT,
                  Xany2Prop,
                  Xany2Sw8);
  }
}

static void xanyProcess(void)
{
  // Keep reserved RCUL widths on their AFHDS2A channels at all times. This is
  // intentionally done after PPM/SWEEP updates so enabled XANY channels win.
  xany1ApplyChannel();
  xany2ApplyChannel();

  // Bind packets do not use Channel_data[]. Pausing both RCUL state machines
  // keeps their timing deterministic when DATA mode resumes.
  if(IS_BIND_IN_PROGRESS)
  {
    const uint32_t now = micros();
    Xany1LastFrameUs = now;
    Xany2LastFrameUs = now;
    return;
  }

  const uint32_t now = micros();
  bool processNeeded = false;

  if(Xany1Enabled && (uint32_t)(now - Xany1LastFrameUs) >= XANY_FRAME_US)
  {
    Xany1LastFrameUs = now;

    if(Xany1Tx.isReadyForTx())
    {
      uint8_t Message[1];
      Message[0] = Xany1Sw8;

      // SW8 = 8 bits = 2 nibbles. Add the standard legacy RCUL checksum.
      Xany1Tx.sendNibbleMsg(Message, 2, 1);
    }

    Xany1Rcul.signalFrame();
    processNeeded = true;
  }

  if(Xany2Enabled && (uint32_t)(now - Xany2LastFrameUs) >= XANY_FRAME_US)
  {
    Xany2LastFrameUs = now;

    if(Xany2Tx.isReadyForTx())
    {
      uint8_t Message[2];
      Message[0] = Xany2Prop;
      Message[1] = Xany2Sw8;

      // SW8+PROP = 16 bits = 4 nibbles. The established RCUL order is
      // PROP first, then the 8 switch bits, followed by the legacy checksum.
      Xany2Tx.sendNibbleMsg(Message, 4, 1);
    }

    Xany2Rcul.signalFrame();
    processNeeded = true;
  }

  // One static call services every RcTxSerial instance.
  if(processNeeded)
    RcTxSerial::process();

  // Apply newly generated pulse widths immediately for the next AFHDS2A data
  // packets. Disabled instances leave their channels to PPM/SWEEP untouched.
  xany1ApplyChannel();
  xany2ApplyChannel();
}

static bool xany1SetChannel(uint8_t Ch)
{
  if(!xanyChannelIsValid(Ch) || Ch == MotorChannel || Ch == Xany2Channel)
    return false;

  Xany1Channel = Ch;
  Xany1Tx.setCh(Xany1Channel);
  prefs.putUChar("x1ch", Xany1Channel);
  xany1ApplyChannel();
  return true;
}

static bool xany2SetChannel(uint8_t Ch)
{
  if(!xanyChannelIsValid(Ch) || Ch == MotorChannel || Ch == Xany1Channel)
    return false;

  Xany2Channel = Ch;
  Xany2Tx.setCh(Xany2Channel);
  prefs.putUChar("x2ch", Xany2Channel);
  xany2ApplyChannel();
  return true;
}

static void xany1SetEnabled(bool Enabled)
{
  Xany1Enabled = Enabled;
  prefs.putBool("x1on", Xany1Enabled);
  Xany1LastFrameUs = micros();
}

static void xany2SetEnabled(bool Enabled)
{
  Xany2Enabled = Enabled;
  prefs.putBool("x2on", Xany2Enabled);
  Xany2LastFrameUs = micros();
}

static bool xany1IsEnabled(void)
{
  return Xany1Enabled;
}

static bool xany2IsEnabled(void)
{
  return Xany2Enabled;
}

static void xany1SetSw8(uint8_t Value)
{
  Xany1Sw8 = Value;
}

static void xany2SetSw8(uint8_t Value)
{
  Xany2Sw8 = Value;
}

static void xany2SetProp(uint8_t Value)
{
  Xany2Prop = Value;
}

static uint8_t xany1GetChannel(void)
{
  return Xany1Channel;
}

static uint8_t xany2GetChannel(void)
{
  return Xany2Channel;
}

static uint8_t xany1GetSw8(void)
{
  return Xany1Sw8;
}

static uint8_t xany2GetSw8(void)
{
  return Xany2Sw8;
}

static uint8_t xany2GetProp(void)
{
  return Xany2Prop;
}

static void xany1PrintStatus(void)
{
  Serial.printf("XANY1       : %s SW8 CH%u repeat=2 sw=0x%02X width=%u us\r\n",
                Xany1Enabled ? "ON" : "OFF",
                Xany1Channel,
                Xany1Sw8,
                Xany1Rcul.widthUs());
}

static void xany2PrintStatus(void)
{
  Serial.printf("XANY2       : %s SW8+PROP CH%u repeat=2 prop=%u sw=0x%02X width=%u us\r\n",
                Xany2Enabled ? "ON" : "OFF",
                Xany2Channel,
                Xany2Prop,
                Xany2Sw8,
                Xany2Rcul.widthUs());
}
