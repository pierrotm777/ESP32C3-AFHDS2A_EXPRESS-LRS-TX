// ============================================================================
// AFHDS2A bind / identity supervision
// ============================================================================
// Refactoring only: code moved from AF2A_C3_BTLE_v1.ino.
// Original MPM AFHDS2A bind code in AFHDS2A_a7105.ino is untouched.

#include "AFHDS2A_Bind.h"
#include "A7105_Main.h"
#include "esp_random.h"

static uint32_t LastBindButtonMs = 0;
static bool LastBindButton = HIGH;

// Bind supervision added around the original MPM protocol logic.
// The MPM AFHDS2A source itself remains unchanged.
static constexpr uint32_t BIND_TIMEOUT_MS = 30000UL;
static constexpr uint32_t BIND_LED_BLINK_MS = 250UL;
bool BindTimerActive = false;
uint32_t BindStartMs = 0;
static uint32_t LastBindLedMs = 0;
static bool BindLedState = false;

// True when a receiver ID has been learned/stored by a successful AFHDS2A bind.
// A valid addressed telemetry packet can also prove an existing stored pairing.
static bool RfBindOk = false;

// Set only from the RF timer task after a normal telemetry packet matches both
// the active TX ID and the stored RX ID. Preferences are updated later in loop(),
// never from the high-priority RF timer task.
volatile bool RfTelemetryProofPending = false;
static uint32_t RfLastLinkProofMs = 0;
bool RfRebindRequired = false;

// ============================================================================
// Bind protocol logger
// ============================================================================
// Do not print continuously while binding: Serial output could disturb the
// original MPM 3850 us scheduler. Instead we sample the MPM state in RAM and
// dump the trace only after bind success/timeout. This keeps AFHDS2A_a7105.ino
// completely unchanged.
static constexpr uint32_t BIND_LOG_SAMPLE_MS = 500UL;
static constexpr uint8_t BIND_LOG_MAX = 72;   // 30 s / 500 ms + margin

struct BindLogEntry
{
  uint16_t elapsedMs;
  uint8_t phaseBefore;
  uint8_t phaseAfter;
  uint8_t packet0;
  uint8_t packet9;
  uint8_t packetCount;
  uint8_t bindPhase;
};

static BindLogEntry BindLog[BIND_LOG_MAX];
static uint8_t BindLogCount = 0;
static uint32_t BindLogNextSampleMs = 0;
static uint32_t BindLogCallbacks = 0;
static uint32_t BindPhaseCount[6] = {0,0,0,0,0,0};
static uint32_t BindWaitCount[3] = {0,0,0};
static bool BindSawBind4 = false;
// 0=none, 1=running, 2=success, 3=timeout
static uint8_t BindLogResult = 0;

// --------------------------------------------------------------------------
// Passive A7105 RX diagnostics for bind.
// These hooks live in the ESP32-C3 software-SPI adaptation only. They do not
// change AFHDS2A_a7105.ino or A7105_SPI.ino protocol behaviour and never print
// while the bind is running.
//
// During AFHDS2A_BIND1/2/3 the original MPM callback reads MODE twice:
//   MODE#0 = data_rx, sampled before the next bind packet is transmitted
//   MODE#1 = CRC/status test immediately after A7105_WriteData()
// If the original MPM condition passes, A7105_ReadData() then reads 38 bytes
// from FIFO.  We reconstruct those low-level reads here for the post-bind log.
// --------------------------------------------------------------------------
static constexpr uint8_t BIND_RX_PACKET_SIZE = 38;
static constexpr uint8_t BIND_RX_EVENT_MAX = 16;

struct BindRxEvent
{
  uint16_t elapsedMs;
  uint8_t phase;
  uint8_t mode0;
  uint8_t mode1;
  uint8_t len;
  uint8_t data[BIND_RX_PACKET_SIZE];
};

static BindRxEvent BindRxEvents[BIND_RX_EVENT_MAX];
static uint8_t BindRxEventCount = 0;
static uint32_t BindRxFifoReadCount = 0;
static uint32_t BindRxBaseCallbackCount = 0;
static uint32_t BindRxMode0Count = 0;
static uint32_t BindRxMode1Count = 0;
static uint32_t BindRxReadyCount = 0;       // !(MODE#0 & 0x01)
static uint32_t BindRxCrcOkCount = 0;       // !(MODE#1 & 0x20)
static uint32_t BindRxGateCount = 0;        // both original MPM tests true
static uint16_t BindRxMode0Hist[256];
static uint16_t BindRxMode1Hist[256];

// Per-callback low-level SPI capture.
static uint8_t BindDiagLastSpiWrite = 0xFF;
static uint8_t BindDiagMode[8];
static uint8_t BindDiagModeCount = 0;
static uint8_t BindDiagFifo[BIND_RX_PACKET_SIZE];
static uint8_t BindDiagFifoCount = 0;


static bool receiverIdLooksValid()
{
  bool allFF = true;
  bool all00 = true;

  for(uint8_t i = 0; i < 4; i++)
  {
    if(rx_id[i] != 0xFF) allFF = false;
    if(rx_id[i] != 0x00) all00 = false;
  }

  return !allFF && !all00;
}

static void refreshRfBindState()
{
  // A stored RX ID is enough for READY display, while bindok/rebind keep track
  // of whether the currently selected TX identity has been positively proven.
  RfRebindRequired = prefs.getBool("rebind", false);
  RfBindOk = !RfRebindRequired && prefs.getBool("bindok", false) && receiverIdLooksValid();
}

static void storeRfBindState(bool ok)
{
  RfBindOk = ok && receiverIdLooksValid();
  prefs.putBool("bindok", RfBindOk);
  if(RfBindOk)
  {
    RfRebindRequired = false;
    prefs.putBool("rebind", false);
  }
}

static void invalidateRfBindState()
{
  RfBindOk = false;
  prefs.putBool("bindok", false);
}

// Exact MPM helper: Convert 32-bit ID to rx_tx_addr.
static void set_rx_tx_addr(uint32_t id)
{
  rx_tx_addr[0] = (id >> 24) & 0xFF;
  rx_tx_addr[1] = (id >> 16) & 0xFF;
  rx_tx_addr[2] = (id >>  8) & 0xFF;
  rx_tx_addr[3] = (id >>  0) & 0xFF;
  rx_tx_addr[4] = (rx_tx_addr[2] & 0xF0) | (rx_tx_addr[3] & 0x0F);
}

static uint32_t makeBoardTxId()
{
  // Deterministic per ESP32-C3: two boards naturally get different IDs.
  const uint64_t mac = ESP.getEfuseMac();
  uint32_t id = (uint32_t)(mac ^ (mac >> 32) ^ 0x0A7105C3UL);
  if(id == 0 || id == 0xFFFFFFFFUL)
    id = 0x13572468UL;
  return id;
}

static uint32_t makeRandomTxId(uint32_t previous)
{
  uint32_t id;
  do
  {
    // esp_random() is hardware-backed on ESP32-C3. Mix in the board identity so
    // copied firmware images do not make different transmitters share an ID.
    id = esp_random() ^ makeBoardTxId();
  } while(id == 0 || id == 0xFFFFFFFFUL || id == previous);
  return id;
}

static uint32_t loadOrCreateTxId()
{
  uint32_t id = prefs.getUInt("txid", 0);
  if(id == 0 || id == 0xFFFFFFFFUL)
  {
    id = makeBoardTxId();
    prefs.putUInt("txid", id);
  }
  return id;
}

static bool applyTxId(uint32_t id, bool save)
{
  if(id == 0 || id == 0xFFFFFFFFUL)
    return false;

  if(id == MProtocol_id)
  {
    if(save)
      prefs.putUInt("txid", MProtocol_id);
    return false;
  }

  if(RfUseEspTimer)
    rfTimerStop();

  // Changing identity while a bind is active aborts that attempt. It must not
  // be mistaken for a successful MPM BIND_DONE transition.
  BindTimerActive = false;
  BIND_DONE;

  MProtocol_id = id;
  set_rx_tx_addr(MProtocol_id);
  if(save)
    prefs.putUInt("txid", MProtocol_id);

  // A new TX identity changes the AFHDS2A hopping table and requires a new
  // receiver bind. Keep the old RX ID bytes for diagnostics only.
  invalidateRfBindState();
  RfRebindRequired = true;
  prefs.putBool("rebind", true);
  RfTelemetryProofPending = false;
  RfLastLinkProofMs = 0;

  if(RadioOk)
  {
    AFHDS2A_init();
    if(RfUseEspTimer)
      rfTimerStart(1000UL);
    else
      NextProtocolUs = micros() + 1000UL;
  }

  return true;
}

static uint8_t rxLqiPercent()
{
  return RX_LQI <= 100 ? (uint8_t)(100U - RX_LQI) : 0;
}

static const char* rfLinkStateText()
{
  if(!RadioOk)
    return "RF ERROR";
  if(IS_BIND_IN_PROGRESS)
    return "BINDING";

  // A recent addressed telemetry frame is the strongest live-link proof.
  if(RfLastLinkProofMs && (uint32_t)(millis() - RfLastLinkProofMs) <= 1000UL)
    return "LINKED";

  if(RfRebindRequired)
    return "REBIND";

  // A valid stored RX ID is sufficient to be ready for normal DATA mode.
  if(RfBindOk || receiverIdLooksValid())
    return "READY";

  return "NO RX";
}

static void processRfLinkValidation()
{
  if(!RfTelemetryProofPending)
    return;

  RfTelemetryProofPending = false;
  RfLastLinkProofMs = millis();

  if(!RfBindOk && receiverIdLooksValid())
  {
    storeRfBindState(true);
    Serial.printf("[RF] stored RX pairing validated by addressed telemetry: %02X %02X %02X %02X\r\n",
                  rx_id[0], rx_id[1], rx_id[2], rx_id[3]);
  }
}


// ============================================================================
// Passive A7105 bind RX diagnostics
// ============================================================================
static void bindDiagReset()
{
  BindRxEventCount = 0;
  BindRxFifoReadCount = 0;
  BindRxBaseCallbackCount = 0;
  BindRxMode0Count = 0;
  BindRxMode1Count = 0;
  BindRxReadyCount = 0;
  BindRxCrcOkCount = 0;
  BindRxGateCount = 0;
  memset(BindRxMode0Hist, 0, sizeof(BindRxMode0Hist));
  memset(BindRxMode1Hist, 0, sizeof(BindRxMode1Hist));

  BindDiagLastSpiWrite = 0xFF;
  BindDiagModeCount = 0;
  BindDiagFifoCount = 0;
}

static void bindDiagBeginCallback()
{
  BindDiagLastSpiWrite = 0xFF;
  BindDiagModeCount = 0;
  BindDiagFifoCount = 0;
}

// SPI.ino calls this after each complete byte written.
// The immediately preceding byte identifies a following 3-wire read:
//   0x40 = A7105 MODE register read
//   0x45 = A7105 FIFO read (0x40 | A7105_05_FIFO_DATA)
void bindDiagSpiWrite(uint8_t value)
{
  if(!BindTimerActive)
    return;

  BindDiagLastSpiWrite = value;
  if(value == 0x45)
    BindDiagFifoCount = 0;
}

// SPI.ino calls this after each complete SDIO byte read.
void bindDiagSpiRead(uint8_t value)
{
  if(!BindTimerActive)
    return;

  if(BindDiagLastSpiWrite == 0x40)
  {
    if(BindDiagModeCount < sizeof(BindDiagMode))
      BindDiagMode[BindDiagModeCount++] = value;

    // A register read contains exactly one returned byte.
    BindDiagLastSpiWrite = 0xFF;
  }
  else if(BindDiagLastSpiWrite == 0x45)
  {
    if(BindDiagFifoCount < BIND_RX_PACKET_SIZE)
      BindDiagFifo[BindDiagFifoCount++] = value;
  }
}

static void bindDiagEndCallback(uint8_t phaseBefore)
{
  if(!BindTimerActive)
    return;

  // Only BIND1/BIND2/BIND3 have the exact two-MODE-read RX test.
  if((phaseBefore & 0x80) || phaseBefore > 0x02)
    return;

  BindRxBaseCallbackCount++;

  uint8_t mode0 = 0xFF;
  uint8_t mode1 = 0xFF;

  if(BindDiagModeCount >= 1)
  {
    mode0 = BindDiagMode[0];
    BindRxMode0Count++;
    if(BindRxMode0Hist[mode0] != 0xFFFF)
      BindRxMode0Hist[mode0]++;
    if(!(mode0 & 0x01))
      BindRxReadyCount++;
  }

  if(BindDiagModeCount >= 2)
  {
    mode1 = BindDiagMode[1];
    BindRxMode1Count++;
    if(BindRxMode1Hist[mode1] != 0xFFFF)
      BindRxMode1Hist[mode1]++;
    if(!(mode1 & 0x20))
      BindRxCrcOkCount++;
  }

  if(BindDiagModeCount >= 2 && !(mode0 & 0x01) && !(mode1 & 0x20))
    BindRxGateCount++;

  if(BindDiagFifoCount)
  {
    BindRxFifoReadCount++;

    if(BindRxEventCount < BIND_RX_EVENT_MAX)
    {
      BindRxEvent &e = BindRxEvents[BindRxEventCount++];
      uint32_t elapsed = (uint32_t)(millis() - BindStartMs);
      if(elapsed > 65535UL) elapsed = 65535UL;
      e.elapsedMs = (uint16_t)elapsed;
      e.phase = phaseBefore;
      e.mode0 = mode0;
      e.mode1 = mode1;
      e.len = BindDiagFifoCount;
      if(e.len > BIND_RX_PACKET_SIZE)
        e.len = BIND_RX_PACKET_SIZE;
      memcpy(e.data, BindDiagFifo, e.len);
      if(e.len < BIND_RX_PACKET_SIZE)
        memset(e.data + e.len, 0, BIND_RX_PACKET_SIZE - e.len);
    }
  }
}

static void printModeHistogram(const char* label, const uint16_t hist[256])
{
  Serial.printf("[BINDRX] %s:", label);
  bool any = false;
  for(uint16_t i = 0; i < 256; i++)
  {
    if(hist[i])
    {
      Serial.printf(" %02X=%u", (unsigned)i, (unsigned)hist[i]);
      any = true;
    }
  }
  if(!any)
    Serial.print(" none");
  Serial.println();
}

static void bindRxDiagDump()
{
  Serial.printf("[BINDRX] baseCB=%lu MODE0=%lu MODE1=%lu RXready=%lu CRCok=%lu gate=%lu FIFOreads=%lu\r\n",
                (unsigned long)BindRxBaseCallbackCount,
                (unsigned long)BindRxMode0Count,
                (unsigned long)BindRxMode1Count,
                (unsigned long)BindRxReadyCount,
                (unsigned long)BindRxCrcOkCount,
                (unsigned long)BindRxGateCount,
                (unsigned long)BindRxFifoReadCount);

  printModeHistogram("MODE0(pre-RX)", BindRxMode0Hist);
  printModeHistogram("MODE1(post-TX)", BindRxMode1Hist);

  if(BindRxFifoReadCount == 0)
  {
    Serial.println("[BINDRX] FIFO was never read by the original MPM bind code.");
    return;
  }

  Serial.printf("[BINDRX] captured FIFO events=%u (total=%lu)\r\n",
                BindRxEventCount, (unsigned long)BindRxFifoReadCount);

  for(uint8_t n = 0; n < BindRxEventCount; n++)
  {
    const BindRxEvent &e = BindRxEvents[n];
    Serial.printf("[BINDRX] #%u t=%u phase=%02X MODE=%02X/%02X len=%u RX:",
                  (unsigned)(n + 1), e.elapsedMs, e.phase,
                  e.mode0, e.mode1, e.len);
    for(uint8_t i = 0; i < e.len; i++)
      Serial.printf(" %02X", e.data[i]);
    Serial.println();
  }
}

// ============================================================================
// Bind protocol logger helpers
// ============================================================================
static const char* bindPhaseName(uint8_t p)
{
  switch(p)
  {
    case 0x00: return "BIND1";
    case 0x01: return "BIND2";
    case 0x02: return "BIND3";
    case 0x03: return "BIND4";
    case 0x04: return "DATA_INIT";
    case 0x05: return "DATA";
    case 0x80: return "BIND1-W";
    case 0x81: return "BIND2-W";
    case 0x82: return "BIND3-W";
    default:   return "?";
  }
}

static void bindLogStore(uint8_t phaseBefore, uint8_t phaseAfter)
{
  if(BindLogCount >= BIND_LOG_MAX)
    return;

  BindLogEntry &e = BindLog[BindLogCount++];
  uint32_t elapsed = (uint32_t)(millis() - BindStartMs);
  if(elapsed > 65535UL) elapsed = 65535UL;
  e.elapsedMs = (uint16_t)elapsed;
  e.phaseBefore = phaseBefore;
  e.phaseAfter = phaseAfter;
  e.packet0 = packet[0];
  e.packet9 = packet[9];
  e.packetCount = packet_count;
  e.bindPhase = bind_phase;
}

static void bindLogReset()
{
  BindLogCount = 0;
  BindLogNextSampleMs = BIND_LOG_SAMPLE_MS;
  BindLogCallbacks = 0;
  memset(BindPhaseCount, 0, sizeof(BindPhaseCount));
  memset(BindWaitCount, 0, sizeof(BindWaitCount));
  BindSawBind4 = false;
  BindLogResult = 1;
  bindDiagReset();

  // Initial MPM state immediately after AFHDS2A_init().
  bindLogStore(phase, phase);
}

static void bindLogCapture(uint8_t phaseBefore, uint8_t phaseAfter)
{
  if(!BindTimerActive)
    return;

  BindLogCallbacks++;

  if(phaseBefore & 0x80)
  {
    const uint8_t base = phaseBefore & 0x7F;
    if(base < 3) BindWaitCount[base]++;
  }
  else if(phaseBefore < 6)
  {
    BindPhaseCount[phaseBefore]++;
  }

  // BIND4 is the important MPM proof that a valid receiver reply was accepted.
  // Force one entry so this short state cannot be missed by the 500 ms sampler.
  if(phaseBefore == 0x03 || phaseAfter == 0x03)
  {
    if(!BindSawBind4)
      bindLogStore(phaseBefore, phaseAfter);
    BindSawBind4 = true;
  }

  const uint32_t elapsed = (uint32_t)(millis() - BindStartMs);
  if(elapsed >= BindLogNextSampleMs)
  {
    bindLogStore(phaseBefore, phaseAfter);
    do {
      BindLogNextSampleMs += BIND_LOG_SAMPLE_MS;
    } while(elapsed >= BindLogNextSampleMs);
  }
}

static const char* bindLogResultName()
{
  switch(BindLogResult)
  {
    case 1: return "RUNNING";
    case 2: return "SUCCESS";
    case 3: return "TIMEOUT";
    default: return "NONE";
  }
}

static void bindLogDump()
{
  if(BindLogCount == 0)
  {
    Serial.println("[BINDLOG] no bind log recorded");
    return;
  }

  Serial.println();
  Serial.println("========== AFHDS2A MPM BIND LOG ==========");
  Serial.printf("[BINDLOG] result=%s  samples=%u  callbacks=%lu  BIND4=%s\r\n",
                bindLogResultName(), BindLogCount,
                (unsigned long)BindLogCallbacks,
                BindSawBind4 ? "SEEN" : "NO");
  Serial.printf("[BINDLOG] TX=%02X %02X %02X %02X  RX=%02X %02X %02X %02X\r\n",
                rx_tx_addr[0], rx_tx_addr[1], rx_tx_addr[2], rx_tx_addr[3],
                rx_id[0], rx_id[1], rx_id[2], rx_id[3]);

  Serial.print("[BINDLOG] HOP:");
  for(uint8_t i = 0; i < 16; i++)
  {
    Serial.print(' ');
    if(hopping_frequency[i] < 0x10) Serial.print('0');
    Serial.print(hopping_frequency[i], HEX);
  }
  Serial.println();

  Serial.printf("[BINDLOG] cb B1=%lu B1W=%lu B2=%lu B2W=%lu B3=%lu B3W=%lu B4=%lu\r\n",
                (unsigned long)BindPhaseCount[0], (unsigned long)BindWaitCount[0],
                (unsigned long)BindPhaseCount[1], (unsigned long)BindWaitCount[1],
                (unsigned long)BindPhaseCount[2], (unsigned long)BindWaitCount[2],
                (unsigned long)BindPhaseCount[3]);

  // Detailed low-level RX side: MODE status and actual FIFO reads.
  bindRxDiagDump();

  for(uint8_t i = 0; i < BindLogCount; i++)
  {
    const BindLogEntry &e = BindLog[i];
    Serial.printf("[BINDLOG] t=%5u  %02X %-7s -> %02X %-7s  pc=%3u bp=%u TX0=%02X TX9=%02X\r\n",
                  e.elapsedMs,
                  e.phaseBefore, bindPhaseName(e.phaseBefore),
                  e.phaseAfter, bindPhaseName(e.phaseAfter),
                  e.packetCount, e.bindPhase, e.packet0, e.packet9);
  }
  Serial.println("==========================================");
}



// Called after PIN_BIND has been configured INPUT_PULLUP.
static void bindInitButtonState()
{
  LastBindButton = digitalRead(PIN_BIND);
}

// Continue a bind that was requested by holding the bind button during boot.
// These statements are the former setup() bind-session block, moved unchanged.
static void bindBeginBootSession()
{
  BindStartMs = millis();
  BindTimerActive = true;
  LastBindLedMs = BindStartMs;
  BindLedState = true;
  bindLogReset();
  Serial.println("[BIND] boot bind (30 s max)");
  Serial.println("[BINDLOG] recording MPM bind activity in RAM; dump at end");
}

// ============================================================================
// Bind / status LED supervision
// ============================================================================
static void startBind()
{
  if(!RadioOk)
  {
    Serial.println("[BIND] A7105 is not ready");
    return;
  }

  Serial.printf("[BIND] start (30 s max) TX ID=%08lX\r\n", (unsigned long)MProtocol_id);

  // The new bind attempt is not considered valid until the original MPM
  // handshake completes by itself. Keep the old RX ID bytes untouched, but
  // clear the validity flag so a timeout can never display BIND OK.
  invalidateRfBindState();
  // Do not program receiver failsafe while the bind state machine is active.
  // Programming resumes automatically as soon as bind completes.
  FAILSAFE_VALUES_off;

  if(RfUseEspTimer)
    rfTimerStop();
  BIND_IN_PROGRESS;
  AFHDS2A_init();
  if(RfUseEspTimer)
    rfTimerStart(1000UL);
  else
    NextProtocolUs = micros() + 1000UL;

  BindStartMs = millis();
  BindTimerActive = true;
  LastBindLedMs = BindStartMs;
  BindLedState = true;
  bindLogReset();
  Serial.println("[BINDLOG] recording MPM bind activity in RAM; dump at end");
  digitalWrite(PIN_LED, HIGH);
}

static void processBindSupervision()
{
  if(!RadioOk)
    return;

  // MPM sets BIND_DONE itself when the AFHDS2A bind handshake succeeds.
  if(BindTimerActive && IS_BIND_DONE)
  {
    const uint32_t elapsed = (uint32_t)(millis() - BindStartMs);
    BindTimerActive = false;
    BindLogResult = 2;
    storeRfBindState(true);
    Serial.printf("[BIND] done in %lu ms\r\n", (unsigned long)elapsed);
    Serial.printf("[BIND] RX ID=%02X %02X %02X %02X -> %s\r\n",
                  rx_id[0], rx_id[1], rx_id[2], rx_id[3],
                  RfBindOk ? "VALID" : "INVALID");
    bindLogDump();
    return;
  }

  if(!BindTimerActive || !IS_BIND_IN_PROGRESS)
    return;

  if((uint32_t)(millis() - BindStartMs) < BIND_TIMEOUT_MS)
    return;

  Serial.println("[BIND] timeout after 30 s - no valid AFHDS2A handshake");

  // Abort only in the ESP32-C3 wrapper. Keep the original MPM AFHDS2A code
  // untouched. BIND_DONE + AFHDS2A_init() returns to normal DATA mode and
  // reloads the previously stored receiver ID, if one exists.
  if(RfUseEspTimer)
    rfTimerStop();
  BIND_DONE;
  AFHDS2A_init();
  invalidateRfBindState();
  if(RfUseEspTimer)
    rfTimerStart(1000UL);
  else
    NextProtocolUs = micros() + 1000UL;
  BindTimerActive = false;
  BindLogResult = 3;

  Serial.printf("[BIND] RF state=%s  RX ID=%02X %02X %02X %02X\r\n",
                rfLinkStateText(),
                rx_id[0], rx_id[1], rx_id[2], rx_id[3]);
  bindLogDump();
}

static void processStatusLed()
{
  if(!RadioOk)
  {
    BindLedState = false;
    digitalWrite(PIN_LED, LOW);
    return;
  }

  if(IS_BIND_IN_PROGRESS)
  {
    const uint32_t now = millis();
    if((uint32_t)(now - LastBindLedMs) >= BIND_LED_BLINK_MS)
    {
      LastBindLedMs = now;
      BindLedState = !BindLedState;
    }
    digitalWrite(PIN_LED, BindLedState ? HIGH : LOW);
    return;
  }

  // Normal RF/data mode: LED steady ON.
  BindLedState = true;
  digitalWrite(PIN_LED, HIGH);
}

static void processBindButton()
{
  const bool now = digitalRead(PIN_BIND);
  if(LastBindButton == HIGH && now == LOW &&
     (uint32_t)(millis() - LastBindButtonMs) > 250UL)
  {
    LastBindButtonMs = millis();
    startBind();
  }
  LastBindButton = now;
}

