#pragma once

// ============================================================================
// CRSF / ELRS TX backend - first integration test
// ============================================================================
// Full-duplex UART intended for an ELRS receiver-class board reflashed as TX
// (RX-as-TX / internal-module style), not an inverted one-wire external bay.
//
// Current firmware GPIO usage leaves GPIO2 and GPIO9 unused. They are chosen
// here so A7105 and ELRS may remain physically connected at the same time.
// Both GPIO2/GPIO9 are ESP32-C3 strapping pins. The proposed wiring keeps the
// normal UART-idle HIGH state compatible with boot:
//   ESP32-C3 GPIO9  TX  ---> ELRS RX
//   ESP32-C3 GPIO2  RX  <--- ELRS TX
//   GND                 --- GND
//
// If GPIO20/GPIO21 are exposed on the final board, they are attractive future
// alternatives because they are not strapping pins.

#include <Arduino.h>
#include <RculCrsfSerial.h>  // Types CRSF visibles avant les prototypes automatiques Arduino

static constexpr int CRSF_TX_PIN = 9;
static constexpr int CRSF_RX_PIN = 2;
static constexpr uint32_t CRSF_HANDSET_BAUD = 400000UL;

// First test at 250 Hz. XANY still generates its legacy RCUL pulse-width
// symbols every 20 ms upstream in Channel_data[]; CRSF simply transports the
// current channel widths more frequently.
static constexpr uint32_t CRSF_CHANNEL_SEND_INTERVAL_US = 4000UL;

static void crsfBegin(void);
static void crsfProcess(void);
static void crsfPrintStatus(void);
