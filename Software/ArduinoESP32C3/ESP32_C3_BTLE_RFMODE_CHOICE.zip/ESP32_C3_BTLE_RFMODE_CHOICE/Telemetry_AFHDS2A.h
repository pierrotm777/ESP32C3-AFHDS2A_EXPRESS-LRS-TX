#pragma once

// ============================================================================
// Passive AFHDS2A telemetry diagnostics API
// ============================================================================
// Implemented in Telemetry_AFHDS2A.ino. Refactoring only: declarations were
// moved out of the main sketch; telemetry behavior is intentionally unchanged.

#include <Arduino.h>

void telemetryAFHDS2AReset();
void telemetryAFHDS2ABeginCallback(uint8_t phaseBefore);
void telemetryAFHDS2AEndCallback(uint8_t phaseBefore, uint8_t phaseAfter);
void telemetryAFHDS2ASpiWrite(uint8_t value);
void telemetryAFHDS2ASpiRead(uint8_t value);
void telemetryAFHDS2APrintStatus();
void telemetryAFHDS2APrintLog();
bool telemetryAFHDS2AHasValidPacket();
uint32_t telemetryAFHDS2AValidPacketCount();
uint32_t telemetryAFHDS2ALastPacketAgeMs();
