#include <ESP32_PPM.h>
#include <Arduino.h>
#include <Wire.h>
#include <U8g2lib.h>
#include <Preferences.h>
#include <elapsedMillis.h>
#include "esp_timer.h"
#include "esp_random.h"

// Enable the original MPM AFHDS2A receiver-failsafe programming path.
// The receiver stores these values and applies them itself after RF loss.
#define FAILSAFE_ENABLE

float VERSION = 1.0f;
static const char* BUILD_TAG = "1.16-FW-REGGPIO-AFHDS2A-FS";

// ============================================================================
// ESP32-C3 Mini pinout
// ============================================================================
// OLED integrated on this ESP32-C3 Mini board.
// Confirmed wiring: SDA=GPIO5, SCL=GPIO6.
static constexpr int SDA_PIN = 5;
static constexpr int SCL_PIN = 6;

// Shared OLED + PCF8574(A) I2C bus. 100 kHz is the conservative PCF8574 rate.
// We can test 400 kHz later by changing this single constant.
static constexpr uint32_t I2C_BUS_HZ = 100000UL;

// A7105 uses a 3-wire SPI bus: one bidirectional SDIO line.
// There is deliberately NO separate MISO pin.
static constexpr int A7105_SDIO_PIN = 8;  // MOSI/SDIO bidirectional
static constexpr int A7105_SCK_PIN  = 4;
static constexpr int A7105_CSN_PIN  = 7;

static constexpr int PPM_IN_PIN = 1;
static constexpr int PIN_BIND   = 10;     // Active LOW
static constexpr int PIN_LED    = 3;
static constexpr int PIN_MOTOR_SAFE = 0;  // Active LOW, forces motor channel to 1000 us

static constexpr uint32_t DEFAULT_BAUD = 115200;

// OLED
static constexpr uint8_t OLED_ADDR = 0x3C;
static constexpr int OLED_W = 128;
static constexpr int OLED_H = 64;

#include "MPM_ESP32C3_Compat.h"

// ============================================================================
// Original MPM globals required by AFHDS2A_a7105.ino / A7105_SPI.ino
// Names are intentionally kept identical for easy comparison/debug.
// ============================================================================
#define NUM_CHN 16

// Original MPM failsafe encoding: 0=no pulses, 2047=hold. AFHDS2A maps
// both special values to 0x0FFF in the receiver programming packet.
#ifndef FAILSAFE_CHANNEL_HOLD
  #define FAILSAFE_CHANNEL_HOLD 2047U
#endif
#ifndef FAILSAFE_CHANNEL_NOPULSES
  #define FAILSAFE_CHANNEL_NOPULSES 0U
#endif
uint16_t Failsafe_data[NUM_CHN];

uint32_t MProtocol_id = 0;
uint16_t Channel_data[NUM_CHN];

uint8_t packet[50];

// Original MPM native AFHDS2A telemetry forwarding buffer.
// Required by AFHDS2A_FW_TELEMETRY (MPM uses 32 bytes).
#define TELEMETRY_BUFFER_SIZE 32
uint8_t packet_in[TELEMETRY_BUFFER_SIZE];

uint8_t rx_tx_addr[5];
uint8_t rx_id[5];
uint8_t phase = 0;
uint8_t bind_phase = 0;
uint8_t packet_count = 0;
uint8_t packet_sent = 0;
uint8_t hopping_frequency[50];
uint8_t hopping_frequency_no = 0;
uint8_t prev_power = 0xFD;

uint8_t protocol = PROTO_AFHDS2A;
uint8_t sub_protocol = PWM_IBUS;
uint8_t RX_num = 0;
uint8_t option = 0x80;              // bit7=FW telemetry ON, low7=0 -> 50 Hz servo setting packet
uint8_t protocol_flags = 0;
uint8_t protocol_flags2 = 0;

// Identity mapping: PPM CH1 remains AFHDS2A CH1, etc.
// Element 16 is intentional: original AFHDS2A code performs one harmless
// lookup before replacing CH17 with RX_LQI.
uint8_t CH_AETR[17] = {
  0, 1, 2, 3, 4, 5, 6, 7,
  8, 9, 10, 11, 12, 13, 14, 15, 0
};

// Original AFHDS2A telemetry variable names.
uint8_t RX_LQI = 0;
uint8_t RX_RSSI = 0;
uint8_t TX_RSSI = 0;
uint8_t v_lipo1 = 0;
uint8_t v_lipo2 = 0;
uint8_t telemetry_link = 0;

// Runtime control: controls only the normal AFHDS2A receive telemetry window.
// The selected ON/OFF state is saved in Preferences. option stays at 0x80 so
// FW telemetry format and the receiver servo setting (50 Hz) remain unchanged.
bool TelemetryRxEnabled = false;

Preferences prefs;

static bool oled_enabled = false;   // Saved in Preferences; defaults OFF on first boot
static bool oled_ok = false;
static uint32_t oled_boot_ms = 0;
U8G2_SSD1306_72X40_ER_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

elapsedMillis oledInfoTimer;
uint8_t oledInfo = 0;

// ============================================================================
// PPM input + SWEEP debug mode
// ============================================================================
enum InputMode : uint8_t {
  INPUT_PPM = 0,
  INPUT_SWEEP = 1
};

// Normal/default source is PPM IN. SWEEP remains a temporary bench/test mode
// selected from the console; every reboot returns to PPM IN so motor failsafe is
// active immediately if the transmitter PPM signal is missing.
static InputMode InputSource = INPUT_PPM;
static constexpr uint8_t ACTIVE_CHANNELS = 14;

// Motor safety. CH3 is the default motor channel. In PPM mode, loss of a valid
// PPM frame forces CH3 to 1000 us. GPIO0 can also force CH3 to 1000 us at any
// time with a switch to GND. Xany_SW8.ino already prevents XANY1 from using
// the selected motor channel.
static uint8_t MotorChannel = 3;
static constexpr uint16_t MOTOR_SAFE_US = 1000;
static constexpr uint32_t PPM_FAILSAFE_MS = 100UL;
static bool PpmFrameSeen = false;
static bool MotorSafetyActive = false;
static bool MotorSafetySwitchActive = false;
static bool MotorSafetyPpmLost = false;

// RCUL XANY bridges + PCF8574(A) input live in separate Arduino tabs.
// XANY1 = SW8 on CH5 by default. XANY2 = SW8+PROP on CH6 by default.
static void xanyBegin(void);
static void xanyProcess(void);
static bool xany1SetChannel(uint8_t Ch);
static bool xany2SetChannel(uint8_t Ch);
static void xany1SetEnabled(bool Enabled);
static void xany2SetEnabled(bool Enabled);
static bool xany1IsEnabled(void);
static bool xany2IsEnabled(void);
static void xany1SetSw8(uint8_t Value);
static void xany2SetSw8(uint8_t Value);
static void xany2SetProp(uint8_t Value);
static uint8_t xany1GetChannel(void);
static uint8_t xany2GetChannel(void);
static uint8_t xany1GetSw8(void);
static uint8_t xany2GetSw8(void);
static uint8_t xany2GetProp(void);
static void xany1PrintStatus(void);
static void xany2PrintStatus(void);
static void pcfSw8Begin(void);
static void pcfSw8Process(void);
static void pcfSw8PrintStatus(void);
static void pcfSw8Scan(void);

// ESP32_PPM v1.0 library supplied with this project.
// The library exposes the global object Cppm32.
// Current library RX implementation is limited to 8 physical PPM channels.
// SWEEP mode still drives all 14 AFHDS2A channels for RF debugging.
static constexpr uint8_t PPM_INPUT_CHANNELS = 8;
static bool PpmPositive = true; // Preferences: true=positive/rising, false=negative/falling
static uint8_t PpmChannelCount = 0;
static uint32_t LastPpmFrameMs = 0;

static uint16_t SweepUs = 1000;
static int16_t SweepStepUs = 5;
static uint32_t LastSweepMs = 0;

static bool DebugIsOn = false;
static bool RadioOk = false;
static uint32_t NextProtocolUs = 0;  // mirror of ESP timer deadline / fallback scheduler

// ============================================================================
// ESP32 high-resolution RF timer
// ============================================================================
// esp_timer is backed by the ESP32-C3 system timer and dispatches this callback
// from the high-priority ESP timer task (NOT from an ISR). The A7105 SPI path
// now uses direct ESP32-C3 GPIO registers, while the callback itself remains in
// task context so the original MPM sources do not need ISR-specific rewriting.
// The original variable 1700/2150 us MPM cadence is kept.
static esp_timer_handle_t RfProtocolTimer = nullptr;
static bool RfUseEspTimer = false;
static volatile bool RfTimerRunning = false;
static int64_t RfExpectedUs = 0;
static portMUX_TYPE RfTimerStatsMux = portMUX_INITIALIZER_UNLOCKED;

struct RfTimerStatsData
{
  uint32_t callbacks;
  uint32_t delay1700;
  uint32_t delay2150;
  uint32_t delayOther;
  uint32_t lateCount;
  uint64_t lateSumUs;
  uint32_t lateMaxUs;
  uint64_t runtimeSumUs;
  uint32_t runtimeMaxUs;
  uint64_t runtime1700SumUs;
  uint32_t runtime1700MaxUs;
  uint32_t runtime1700Samples;
  uint64_t runtime2150SumUs;
  uint32_t runtime2150MaxUs;
  uint32_t runtime2150Samples;
  uint64_t jitterAbsSumUs;
  uint32_t jitterAbsMaxUs;
  uint32_t jitterSamples;
  uint32_t overruns;
  uint32_t resyncs;
  uint32_t armErrors;
  int64_t firstStartUs;
  int64_t lastStartUs;
  int64_t prevStartUs;
  uint16_t prevDelayUs;
};

static RfTimerStatsData RfTimerStats = {};

static bool rfTimerInit();
static void rfTimerStart(uint32_t firstDelayUs);
static void rfTimerStop();
static void rfTimerResetLog();
static void rfTimerPrintLog();
static uint32_t LastDebugMs = 0;
static uint32_t LastBindButtonMs = 0;
static bool LastBindButton = HIGH;

// Bind supervision added around the original MPM protocol logic.
// The MPM AFHDS2A source itself remains unchanged.
static constexpr uint32_t BIND_TIMEOUT_MS = 30000UL;
static constexpr uint32_t BIND_LED_BLINK_MS = 250UL;
static bool BindTimerActive = false;
static uint32_t BindStartMs = 0;
static uint32_t LastBindLedMs = 0;
static bool BindLedState = false;

// True when a receiver ID has been learned/stored by a successful AFHDS2A bind.
// A valid addressed telemetry packet can also prove an existing stored pairing.
static bool RfBindOk = false;

// Set only from the RF timer task after a normal telemetry packet matches both
// the active TX ID and the stored RX ID. Preferences are updated later in loop(),
// never from the high-priority RF timer task.
volatile bool RfTelemetryProofPending = false;
static uint32_t RfLastLinkProofMs = 0;
static bool RfRebindRequired = false;

// ============================================================================
// Bind protocol logger
// ============================================================================
// Do not print continuously while binding: Serial output could disturb the
// original MPM 3850 us scheduler. Instead we sample the MPM state in RAM and
// dump the trace only after bind success/timeout. This keeps AFHDS2A_a7105.ino
// completely unchanged.
static constexpr uint32_t BIND_LOG_SAMPLE_MS = 500UL;
static constexpr uint8_t BIND_LOG_MAX = 72;   // 30 s / 500 ms + margin

struct BindLogEntry
{
  uint16_t elapsedMs;
  uint8_t phaseBefore;
  uint8_t phaseAfter;
  uint8_t packet0;
  uint8_t packet9;
  uint8_t packetCount;
  uint8_t bindPhase;
};

static BindLogEntry BindLog[BIND_LOG_MAX];
static uint8_t BindLogCount = 0;
static uint32_t BindLogNextSampleMs = 0;
static uint32_t BindLogCallbacks = 0;
static uint32_t BindPhaseCount[6] = {0,0,0,0,0,0};
static uint32_t BindWaitCount[3] = {0,0,0};
static bool BindSawBind4 = false;
// 0=none, 1=running, 2=success, 3=timeout
static uint8_t BindLogResult = 0;

// --------------------------------------------------------------------------
// Passive A7105 RX diagnostics for bind.
// These hooks live in the ESP32-C3 software-SPI adaptation only. They do not
// change AFHDS2A_a7105.ino or A7105_SPI.ino protocol behaviour and never print
// while the bind is running.
//
// During AFHDS2A_BIND1/2/3 the original MPM callback reads MODE twice:
//   MODE#0 = data_rx, sampled before the next bind packet is transmitted
//   MODE#1 = CRC/status test immediately after A7105_WriteData()
// If the original MPM condition passes, A7105_ReadData() then reads 38 bytes
// from FIFO.  We reconstruct those low-level reads here for the post-bind log.
// --------------------------------------------------------------------------
static constexpr uint8_t BIND_RX_PACKET_SIZE = 38;
static constexpr uint8_t BIND_RX_EVENT_MAX = 16;

struct BindRxEvent
{
  uint16_t elapsedMs;
  uint8_t phase;
  uint8_t mode0;
  uint8_t mode1;
  uint8_t len;
  uint8_t data[BIND_RX_PACKET_SIZE];
};

static BindRxEvent BindRxEvents[BIND_RX_EVENT_MAX];
static uint8_t BindRxEventCount = 0;
static uint32_t BindRxFifoReadCount = 0;
static uint32_t BindRxBaseCallbackCount = 0;
static uint32_t BindRxMode0Count = 0;
static uint32_t BindRxMode1Count = 0;
static uint32_t BindRxReadyCount = 0;       // !(MODE#0 & 0x01)
static uint32_t BindRxCrcOkCount = 0;       // !(MODE#1 & 0x20)
static uint32_t BindRxGateCount = 0;        // both original MPM tests true
static uint16_t BindRxMode0Hist[256];
static uint16_t BindRxMode1Hist[256];

// Per-callback low-level SPI capture.
static uint8_t BindDiagLastSpiWrite = 0xFF;
static uint8_t BindDiagMode[8];
static uint8_t BindDiagModeCount = 0;
static uint8_t BindDiagFifo[BIND_RX_PACKET_SIZE];
static uint8_t BindDiagFifoCount = 0;

// Forward declarations: original names are implemented in MPM tabs.
uint16_t AFHDS2A_callback();
void AFHDS2A_init();
uint8_t A7105_Reset();

// Called only by the ESP32-C3 SPI adaptation for passive bind diagnostics.
void bindDiagSpiWrite(uint8_t value);
void bindDiagSpiRead(uint8_t value);

// Passive AFHDS2A telemetry diagnostics implemented in Telemetry_AFHDS2A.ino.
void telemetryAFHDS2AReset();
void telemetryAFHDS2ABeginCallback(uint8_t phaseBefore);
void telemetryAFHDS2AEndCallback(uint8_t phaseBefore, uint8_t phaseAfter);
void telemetryAFHDS2ASpiWrite(uint8_t value);
void telemetryAFHDS2ASpiRead(uint8_t value);
void telemetryAFHDS2APrintStatus();
void telemetryAFHDS2APrintLog();
bool telemetryAFHDS2AHasValidPacket();
uint32_t telemetryAFHDS2AValidPacketCount();
uint32_t telemetryAFHDS2ALastPacketAgeMs();

// ============================================================================
// MPM EEPROM compatibility backed by ESP32 Preferences
// ============================================================================
uint8_t eeprom_read_byte(EE_ADDR address)
{
  char key[9];
  snprintf(key, sizeof(key), "e%03u", (unsigned)address);
  return prefs.getUChar(key, 0xFF);
}

void eeprom_write_byte(EE_ADDR address, uint8_t value)
{
  char key[9];
  snprintf(key, sizeof(key), "e%03u", (unsigned)address);
  prefs.putUChar(key, value);
}

static bool receiverIdLooksValid()
{
  bool allFF = true;
  bool all00 = true;

  for(uint8_t i = 0; i < 4; i++)
  {
    if(rx_id[i] != 0xFF) allFF = false;
    if(rx_id[i] != 0x00) all00 = false;
  }

  return !allFF && !all00;
}

static void refreshRfBindState()
{
  // A stored RX ID is enough for READY display, while bindok/rebind keep track
  // of whether the currently selected TX identity has been positively proven.
  RfRebindRequired = prefs.getBool("rebind", false);
  RfBindOk = !RfRebindRequired && prefs.getBool("bindok", false) && receiverIdLooksValid();
}

static void storeRfBindState(bool ok)
{
  RfBindOk = ok && receiverIdLooksValid();
  prefs.putBool("bindok", RfBindOk);
  if(RfBindOk)
  {
    RfRebindRequired = false;
    prefs.putBool("rebind", false);
  }
}

static void invalidateRfBindState()
{
  RfBindOk = false;
  prefs.putBool("bindok", false);
}

// Exact MPM helper: Convert 32-bit ID to rx_tx_addr.
static void set_rx_tx_addr(uint32_t id)
{
  rx_tx_addr[0] = (id >> 24) & 0xFF;
  rx_tx_addr[1] = (id >> 16) & 0xFF;
  rx_tx_addr[2] = (id >>  8) & 0xFF;
  rx_tx_addr[3] = (id >>  0) & 0xFF;
  rx_tx_addr[4] = (rx_tx_addr[2] & 0xF0) | (rx_tx_addr[3] & 0x0F);
}

static uint32_t makeBoardTxId()
{
  // Deterministic per ESP32-C3: two boards naturally get different IDs.
  const uint64_t mac = ESP.getEfuseMac();
  uint32_t id = (uint32_t)(mac ^ (mac >> 32) ^ 0x0A7105C3UL);
  if(id == 0 || id == 0xFFFFFFFFUL)
    id = 0x13572468UL;
  return id;
}

static uint32_t makeRandomTxId(uint32_t previous)
{
  uint32_t id;
  do
  {
    // esp_random() is hardware-backed on ESP32-C3. Mix in the board identity so
    // copied firmware images do not make different transmitters share an ID.
    id = esp_random() ^ makeBoardTxId();
  } while(id == 0 || id == 0xFFFFFFFFUL || id == previous);
  return id;
}

static uint32_t loadOrCreateTxId()
{
  uint32_t id = prefs.getUInt("txid", 0);
  if(id == 0 || id == 0xFFFFFFFFUL)
  {
    id = makeBoardTxId();
    prefs.putUInt("txid", id);
  }
  return id;
}

static bool applyTxId(uint32_t id, bool save)
{
  if(id == 0 || id == 0xFFFFFFFFUL)
    return false;

  if(id == MProtocol_id)
  {
    if(save)
      prefs.putUInt("txid", MProtocol_id);
    return false;
  }

  if(RfUseEspTimer)
    rfTimerStop();

  // Changing identity while a bind is active aborts that attempt. It must not
  // be mistaken for a successful MPM BIND_DONE transition.
  BindTimerActive = false;
  BIND_DONE;

  MProtocol_id = id;
  set_rx_tx_addr(MProtocol_id);
  if(save)
    prefs.putUInt("txid", MProtocol_id);

  // A new TX identity changes the AFHDS2A hopping table and requires a new
  // receiver bind. Keep the old RX ID bytes for diagnostics only.
  invalidateRfBindState();
  RfRebindRequired = true;
  prefs.putBool("rebind", true);
  RfTelemetryProofPending = false;
  RfLastLinkProofMs = 0;

  if(RadioOk)
  {
    AFHDS2A_init();
    if(RfUseEspTimer)
      rfTimerStart(1000UL);
    else
      NextProtocolUs = micros() + 1000UL;
  }

  return true;
}

static uint8_t rxLqiPercent()
{
  return RX_LQI <= 100 ? (uint8_t)(100U - RX_LQI) : 0;
}

static const char* rfLinkStateText()
{
  if(!RadioOk)
    return "RF ERROR";
  if(IS_BIND_IN_PROGRESS)
    return "BINDING";

  // A recent addressed telemetry frame is the strongest live-link proof.
  if(RfLastLinkProofMs && (uint32_t)(millis() - RfLastLinkProofMs) <= 1000UL)
    return "LINKED";

  if(RfRebindRequired)
    return "REBIND";

  // A valid stored RX ID is sufficient to be ready for normal DATA mode.
  if(RfBindOk || receiverIdLooksValid())
    return "READY";

  return "NO RX";
}

static void processRfLinkValidation()
{
  if(!RfTelemetryProofPending)
    return;

  RfTelemetryProofPending = false;
  RfLastLinkProofMs = millis();

  if(!RfBindOk && receiverIdLooksValid())
  {
    storeRfBindState(true);
    Serial.printf("[RF] stored RX pairing validated by addressed telemetry: %02X %02X %02X %02X\r\n",
                  rx_id[0], rx_id[1], rx_id[2], rx_id[3]);
  }
}

// ============================================================================
// Channel conversion: PPM microseconds -> original MPM Channel_data 0..2047
// This is the inverse of MPM convert_channel_ppm().
// ============================================================================
static uint16_t ppmUsToMpmChannel(int us)
{
  if(us < 860) us = 860;
  if(us > 2140) us = 2140;

  uint32_t value = ((uint32_t)(us - 860) * 8U + 2U) / 5U;
  if(value > 2047U) value = 2047U;
  return (uint16_t)value;
}

// ============================================================================
// AFHDS2A receiver failsafe programming
// ============================================================================
// The original MPM AFHDS2A code sends packet 0x56 when FAILSAFE_VALUES_on is
// set. It checks the flag every 1569 packets (~6.04 s with the proven RF
// scheduler). Re-arming after each send makes the programming robust even when
// the receiver is powered after the transmitter.
static constexpr uint32_t AFHDS2A_FAILSAFE_REARM_MS = 3000UL;
static uint32_t LastFailsafeArmMs = 0;

static void initAfhds2aFailsafeValues()
{
  for(uint8_t ch = 0; ch < NUM_CHN; ch++)
    Failsafe_data[ch] = FAILSAFE_CHANNEL_HOLD;

  // Boat safety default: motor CH3 -> minimum/stop.
  if(MotorChannel >= 1 && MotorChannel <= NUM_CHN)
    Failsafe_data[MotorChannel - 1] = ppmUsToMpmChannel(MOTOR_SAFE_US);

  FAILSAFE_VALUES_off;
  LastFailsafeArmMs = millis();
}

static void armAfhds2aFailsafeProgramming()
{
  if(!RadioOk || IS_BIND_IN_PROGRESS)
    return;

  FAILSAFE_VALUES_on;
  LastFailsafeArmMs = millis();
}

static void processAfhds2aFailsafeProgramming()
{
  if(!RadioOk || IS_BIND_IN_PROGRESS)
    return;

  if(!IS_FAILSAFE_VALUES_on &&
     (uint32_t)(millis() - LastFailsafeArmMs) >= AFHDS2A_FAILSAFE_REARM_MS)
  {
    armAfhds2aFailsafeProgramming();
  }
}

static void printAfhds2aFailsafeStatus()
{
  Serial.printf("[FAILSAFE] MPM=FAILSAFE_ENABLE  AFHDS2A RX programming=ON  pending=%s\r\n",
                IS_FAILSAFE_VALUES_on ? "YES" : "NO");
  Serial.printf("[FAILSAFE] CH%u=%u us; all other channels=HOLD\r\n",
                MotorChannel, MOTOR_SAFE_US);
  Serial.println("[FAILSAFE] Packet 0x56 is re-armed automatically; RX applies stored values after RF loss.");
}

static void centerAllChannels()
{
  for(uint8_t ch = 0; ch < NUM_CHN; ch++)
    Channel_data[ch] = CHANNEL_MID;
}

static void updateSweep()
{
  if((uint32_t)(millis() - LastSweepMs) < 20UL)
    return;

  LastSweepMs = millis();

  int next = (int)SweepUs + SweepStepUs;
  if(next >= 2000)
  {
    next = 2000;
    SweepStepUs = -abs(SweepStepUs);
  }
  else if(next <= 1000)
  {
    next = 1000;
    SweepStepUs = abs(SweepStepUs);
  }
  SweepUs = (uint16_t)next;

  const uint16_t mpm = ppmUsToMpmChannel(SweepUs);
  for(uint8_t ch = 0; ch < ACTIVE_CHANNELS; ch++)
    Channel_data[ch] = mpm;

  // CH15 and CH16 remain centered. AFHDS2A directly transports CH1..CH14.
  Channel_data[CH15] = CHANNEL_MID;
  Channel_data[CH16] = CHANNEL_MID;
}

static void updatePpm()
{
  // ESP32_PPM::rxAvailable() returns true once for each complete PPM frame.
  if(!Cppm32.rxAvailable())
    return;

  LastPpmFrameMs = millis();
  PpmFrameSeen = true;
  PpmChannelCount = Cppm32.rxChannels();
  if(PpmChannelCount > ACTIVE_CHANNELS)
    PpmChannelCount = ACTIVE_CHANNELS;

  for(uint8_t ch = 0; ch < ACTIVE_CHANNELS; ch++)
  {
    uint16_t us = 1500;
    if(ch < PpmChannelCount)
      us = Cppm32.rxRead(ch + 1);   // ESP32_PPM channels are numbered 1..N

    Channel_data[ch] = ppmUsToMpmChannel(us);
  }

  // ESP32_PPM v1.0 currently supports 8 physical RX channels.
  // Therefore CH9..CH14 remain centered in PPM mode, while SWEEP exercises
  // all 14 AFHDS2A channels.
  Channel_data[CH15] = CHANNEL_MID;
  Channel_data[CH16] = CHANNEL_MID;
}

static void applyMotorSafety()
{
  if(MotorChannel < 1 || MotorChannel > ACTIVE_CHANNELS)
    return;

  const bool switchActive = (digitalRead(PIN_MOTOR_SAFE) == LOW);

  bool ppmLost = false;
  if(InputSource == INPUT_PPM)
  {
    const bool channelPresent = PpmFrameSeen && (PpmChannelCount >= MotorChannel);
    const bool frameFresh = PpmFrameSeen && ((uint32_t)(millis() - LastPpmFrameMs) <= PPM_FAILSAFE_MS);
    ppmLost = !(channelPresent && frameFresh);
  }

  const bool safe = switchActive || ppmLost;
  const bool changed = (safe != MotorSafetyActive) ||
                       (switchActive != MotorSafetySwitchActive) ||
                       (ppmLost != MotorSafetyPpmLost);

  MotorSafetyActive = safe;
  MotorSafetySwitchActive = switchActive;
  MotorSafetyPpmLost = ppmLost;

  if(safe)
    Channel_data[MotorChannel - 1] = ppmUsToMpmChannel(MOTOR_SAFE_US);

  if(changed)
  {
    if(safe)
      Serial.printf("[MOTOR] CH%u SAFE=%u us%s%s\r\n",
                    MotorChannel, MOTOR_SAFE_US,
                    switchActive ? " GPIO0" : "",
                    ppmLost ? " PPM_LOST" : "");
    else
      Serial.printf("[MOTOR] CH%u RUN - PPM signal valid, safety switch released\r\n", MotorChannel);
  }
}

// ============================================================================
// Passive A7105 bind RX diagnostics
// ============================================================================
static void bindDiagReset()
{
  BindRxEventCount = 0;
  BindRxFifoReadCount = 0;
  BindRxBaseCallbackCount = 0;
  BindRxMode0Count = 0;
  BindRxMode1Count = 0;
  BindRxReadyCount = 0;
  BindRxCrcOkCount = 0;
  BindRxGateCount = 0;
  memset(BindRxMode0Hist, 0, sizeof(BindRxMode0Hist));
  memset(BindRxMode1Hist, 0, sizeof(BindRxMode1Hist));

  BindDiagLastSpiWrite = 0xFF;
  BindDiagModeCount = 0;
  BindDiagFifoCount = 0;
}

static void bindDiagBeginCallback()
{
  BindDiagLastSpiWrite = 0xFF;
  BindDiagModeCount = 0;
  BindDiagFifoCount = 0;
}

// SPI.ino calls this after each complete byte written.
// The immediately preceding byte identifies a following 3-wire read:
//   0x40 = A7105 MODE register read
//   0x45 = A7105 FIFO read (0x40 | A7105_05_FIFO_DATA)
void bindDiagSpiWrite(uint8_t value)
{
  if(!BindTimerActive)
    return;

  BindDiagLastSpiWrite = value;
  if(value == 0x45)
    BindDiagFifoCount = 0;
}

// SPI.ino calls this after each complete SDIO byte read.
void bindDiagSpiRead(uint8_t value)
{
  if(!BindTimerActive)
    return;

  if(BindDiagLastSpiWrite == 0x40)
  {
    if(BindDiagModeCount < sizeof(BindDiagMode))
      BindDiagMode[BindDiagModeCount++] = value;

    // A register read contains exactly one returned byte.
    BindDiagLastSpiWrite = 0xFF;
  }
  else if(BindDiagLastSpiWrite == 0x45)
  {
    if(BindDiagFifoCount < BIND_RX_PACKET_SIZE)
      BindDiagFifo[BindDiagFifoCount++] = value;
  }
}

static void bindDiagEndCallback(uint8_t phaseBefore)
{
  if(!BindTimerActive)
    return;

  // Only BIND1/BIND2/BIND3 have the exact two-MODE-read RX test.
  if((phaseBefore & 0x80) || phaseBefore > 0x02)
    return;

  BindRxBaseCallbackCount++;

  uint8_t mode0 = 0xFF;
  uint8_t mode1 = 0xFF;

  if(BindDiagModeCount >= 1)
  {
    mode0 = BindDiagMode[0];
    BindRxMode0Count++;
    if(BindRxMode0Hist[mode0] != 0xFFFF)
      BindRxMode0Hist[mode0]++;
    if(!(mode0 & 0x01))
      BindRxReadyCount++;
  }

  if(BindDiagModeCount >= 2)
  {
    mode1 = BindDiagMode[1];
    BindRxMode1Count++;
    if(BindRxMode1Hist[mode1] != 0xFFFF)
      BindRxMode1Hist[mode1]++;
    if(!(mode1 & 0x20))
      BindRxCrcOkCount++;
  }

  if(BindDiagModeCount >= 2 && !(mode0 & 0x01) && !(mode1 & 0x20))
    BindRxGateCount++;

  if(BindDiagFifoCount)
  {
    BindRxFifoReadCount++;

    if(BindRxEventCount < BIND_RX_EVENT_MAX)
    {
      BindRxEvent &e = BindRxEvents[BindRxEventCount++];
      uint32_t elapsed = (uint32_t)(millis() - BindStartMs);
      if(elapsed > 65535UL) elapsed = 65535UL;
      e.elapsedMs = (uint16_t)elapsed;
      e.phase = phaseBefore;
      e.mode0 = mode0;
      e.mode1 = mode1;
      e.len = BindDiagFifoCount;
      if(e.len > BIND_RX_PACKET_SIZE)
        e.len = BIND_RX_PACKET_SIZE;
      memcpy(e.data, BindDiagFifo, e.len);
      if(e.len < BIND_RX_PACKET_SIZE)
        memset(e.data + e.len, 0, BIND_RX_PACKET_SIZE - e.len);
    }
  }
}

static void printModeHistogram(const char* label, const uint16_t hist[256])
{
  Serial.printf("[BINDRX] %s:", label);
  bool any = false;
  for(uint16_t i = 0; i < 256; i++)
  {
    if(hist[i])
    {
      Serial.printf(" %02X=%u", (unsigned)i, (unsigned)hist[i]);
      any = true;
    }
  }
  if(!any)
    Serial.print(" none");
  Serial.println();
}

static void bindRxDiagDump()
{
  Serial.printf("[BINDRX] baseCB=%lu MODE0=%lu MODE1=%lu RXready=%lu CRCok=%lu gate=%lu FIFOreads=%lu\r\n",
                (unsigned long)BindRxBaseCallbackCount,
                (unsigned long)BindRxMode0Count,
                (unsigned long)BindRxMode1Count,
                (unsigned long)BindRxReadyCount,
                (unsigned long)BindRxCrcOkCount,
                (unsigned long)BindRxGateCount,
                (unsigned long)BindRxFifoReadCount);

  printModeHistogram("MODE0(pre-RX)", BindRxMode0Hist);
  printModeHistogram("MODE1(post-TX)", BindRxMode1Hist);

  if(BindRxFifoReadCount == 0)
  {
    Serial.println("[BINDRX] FIFO was never read by the original MPM bind code.");
    return;
  }

  Serial.printf("[BINDRX] captured FIFO events=%u (total=%lu)\r\n",
                BindRxEventCount, (unsigned long)BindRxFifoReadCount);

  for(uint8_t n = 0; n < BindRxEventCount; n++)
  {
    const BindRxEvent &e = BindRxEvents[n];
    Serial.printf("[BINDRX] #%u t=%u phase=%02X MODE=%02X/%02X len=%u RX:",
                  (unsigned)(n + 1), e.elapsedMs, e.phase,
                  e.mode0, e.mode1, e.len);
    for(uint8_t i = 0; i < e.len; i++)
      Serial.printf(" %02X", e.data[i]);
    Serial.println();
  }
}

// ============================================================================
// Bind protocol logger helpers
// ============================================================================
static const char* bindPhaseName(uint8_t p)
{
  switch(p)
  {
    case 0x00: return "BIND1";
    case 0x01: return "BIND2";
    case 0x02: return "BIND3";
    case 0x03: return "BIND4";
    case 0x04: return "DATA_INIT";
    case 0x05: return "DATA";
    case 0x80: return "BIND1-W";
    case 0x81: return "BIND2-W";
    case 0x82: return "BIND3-W";
    default:   return "?";
  }
}

static void bindLogStore(uint8_t phaseBefore, uint8_t phaseAfter)
{
  if(BindLogCount >= BIND_LOG_MAX)
    return;

  BindLogEntry &e = BindLog[BindLogCount++];
  uint32_t elapsed = (uint32_t)(millis() - BindStartMs);
  if(elapsed > 65535UL) elapsed = 65535UL;
  e.elapsedMs = (uint16_t)elapsed;
  e.phaseBefore = phaseBefore;
  e.phaseAfter = phaseAfter;
  e.packet0 = packet[0];
  e.packet9 = packet[9];
  e.packetCount = packet_count;
  e.bindPhase = bind_phase;
}

static void bindLogReset()
{
  BindLogCount = 0;
  BindLogNextSampleMs = BIND_LOG_SAMPLE_MS;
  BindLogCallbacks = 0;
  memset(BindPhaseCount, 0, sizeof(BindPhaseCount));
  memset(BindWaitCount, 0, sizeof(BindWaitCount));
  BindSawBind4 = false;
  BindLogResult = 1;
  bindDiagReset();

  // Initial MPM state immediately after AFHDS2A_init().
  bindLogStore(phase, phase);
}

static void bindLogCapture(uint8_t phaseBefore, uint8_t phaseAfter)
{
  if(!BindTimerActive)
    return;

  BindLogCallbacks++;

  if(phaseBefore & 0x80)
  {
    const uint8_t base = phaseBefore & 0x7F;
    if(base < 3) BindWaitCount[base]++;
  }
  else if(phaseBefore < 6)
  {
    BindPhaseCount[phaseBefore]++;
  }

  // BIND4 is the important MPM proof that a valid receiver reply was accepted.
  // Force one entry so this short state cannot be missed by the 500 ms sampler.
  if(phaseBefore == 0x03 || phaseAfter == 0x03)
  {
    if(!BindSawBind4)
      bindLogStore(phaseBefore, phaseAfter);
    BindSawBind4 = true;
  }

  const uint32_t elapsed = (uint32_t)(millis() - BindStartMs);
  if(elapsed >= BindLogNextSampleMs)
  {
    bindLogStore(phaseBefore, phaseAfter);
    do {
      BindLogNextSampleMs += BIND_LOG_SAMPLE_MS;
    } while(elapsed >= BindLogNextSampleMs);
  }
}

static const char* bindLogResultName()
{
  switch(BindLogResult)
  {
    case 1: return "RUNNING";
    case 2: return "SUCCESS";
    case 3: return "TIMEOUT";
    default: return "NONE";
  }
}

static void bindLogDump()
{
  if(BindLogCount == 0)
  {
    Serial.println("[BINDLOG] no bind log recorded");
    return;
  }

  Serial.println();
  Serial.println("========== AFHDS2A MPM BIND LOG ==========");
  Serial.printf("[BINDLOG] result=%s  samples=%u  callbacks=%lu  BIND4=%s\r\n",
                bindLogResultName(), BindLogCount,
                (unsigned long)BindLogCallbacks,
                BindSawBind4 ? "SEEN" : "NO");
  Serial.printf("[BINDLOG] TX=%02X %02X %02X %02X  RX=%02X %02X %02X %02X\r\n",
                rx_tx_addr[0], rx_tx_addr[1], rx_tx_addr[2], rx_tx_addr[3],
                rx_id[0], rx_id[1], rx_id[2], rx_id[3]);

  Serial.print("[BINDLOG] HOP:");
  for(uint8_t i = 0; i < 16; i++)
  {
    Serial.print(' ');
    if(hopping_frequency[i] < 0x10) Serial.print('0');
    Serial.print(hopping_frequency[i], HEX);
  }
  Serial.println();

  Serial.printf("[BINDLOG] cb B1=%lu B1W=%lu B2=%lu B2W=%lu B3=%lu B3W=%lu B4=%lu\r\n",
                (unsigned long)BindPhaseCount[0], (unsigned long)BindWaitCount[0],
                (unsigned long)BindPhaseCount[1], (unsigned long)BindWaitCount[1],
                (unsigned long)BindPhaseCount[2], (unsigned long)BindWaitCount[2],
                (unsigned long)BindPhaseCount[3]);

  // Detailed low-level RX side: MODE status and actual FIFO reads.
  bindRxDiagDump();

  for(uint8_t i = 0; i < BindLogCount; i++)
  {
    const BindLogEntry &e = BindLog[i];
    Serial.printf("[BINDLOG] t=%5u  %02X %-7s -> %02X %-7s  pc=%3u bp=%u TX0=%02X TX9=%02X\r\n",
                  e.elapsedMs,
                  e.phaseBefore, bindPhaseName(e.phaseBefore),
                  e.phaseAfter, bindPhaseName(e.phaseAfter),
                  e.packetCount, e.bindPhase, e.packet0, e.packet9);
  }
  Serial.println("==========================================");
}

// ============================================================================
// OLED
// ============================================================================
static uint8_t oledProbeAddress()
{
  const uint8_t candidates[] = { 0x3C, 0x3D };

  for(uint8_t i = 0; i < sizeof(candidates); i++)
  {
    Wire.beginTransmission(candidates[i]);
    if(Wire.endTransmission() == 0)
      return candidates[i];
  }

  return 0;
}

static void oledInit()
{
  if(!oled_enabled)
  {
    oled_ok = false;
    Serial.println("[OLED] OFF (saved preference) - type 'oled on' to enable");
    return;
  }

  // Shared C3 I2C bus: SDA=GPIO5, SCL=GPIO6.
  // The bus is already started in setup() for OLED + PCF8574(A).
  // Keep the common clock at I2C_BUS_HZ (100 kHz for the first PCF test).
  Wire.setClock(I2C_BUS_HZ);
  delay(20);

  const uint8_t DetectedAddr = oledProbeAddress();
  if(DetectedAddr == 0)
  {
    oled_ok = false;
    Serial.printf("[OLED] NO I2C device on SDA=%d SCL=%d (tried 0x3C/0x3D)\r\n",
                  SDA_PIN, SCL_PIN);
    return;
  }

  Serial.printf("[OLED] I2C device found at 0x%02X on SDA=%d SCL=%d\r\n",
                DetectedAddr, SDA_PIN, SCL_PIN);

  u8g2.setI2CAddress(DetectedAddr << 1);
  u8g2.setBusClock(I2C_BUS_HZ);
  oled_ok = u8g2.begin();

  if(!oled_ok)
  {
    Serial.println("[OLED] init FAILED");
    return;
  }

  oled_boot_ms = millis();
  Serial.println("[OLED] init OK (SSD1306 72x40 / U8g2)");

  // Immediate startup test, before A7105 initialization. If this appears,
  // OLED wiring/driver are confirmed independently of the RF code.
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_5x7_tf);
  u8g2.setCursor(0, 8);
  u8g2.print("AFHDS2A");
  u8g2.setCursor(0, 18);
  u8g2.print("ESP32-C3");
  u8g2.setCursor(0, 28);
  u8g2.print("OLED OK");
  u8g2.sendBuffer();
  delay(700);
}

static void oledDisable()
{
  oled_enabled = false;
  if(oled_ok)
    u8g2.setPowerSave(1);
  oled_ok = false;
  Serial.println("[OLED] OFF");
}

static void oledDraw()
{
  if(!oled_enabled || !oled_ok || oledInfoTimer < 500)
    return;
  oledInfoTimer = 0;

  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_5x7_tf);

  u8g2.setCursor(0, 7);
  u8g2.print("AFHDS2A MPM");

  u8g2.setCursor(0, 16);
  if(!RadioOk)
    u8g2.print("A7105 ERROR");
  else if(IS_BIND_IN_PROGRESS)
    u8g2.print("RF BIND...");
  else
    u8g2.print(rfLinkStateText());

  u8g2.setCursor(0, 25);
  if(IS_BIND_IN_PROGRESS)
  {
    // Hide SWEEP/PPM values while the original MPM bind is running.
    // Channel_data still updates exactly as before; bind packets do not use it.
    const uint32_t sec = BindTimerActive ? ((uint32_t)(millis() - BindStartMs) / 1000UL) : 0UL;
    u8g2.print("BIND ");
    u8g2.print(sec);
    u8g2.print("/30s");
  }
  else if(InputSource == INPUT_SWEEP)
  {
    u8g2.print("SWP ");
    u8g2.print(SweepUs);
    u8g2.print("us");
  }
  else
  {
    u8g2.print("PPM ");
    u8g2.print(PpmChannelCount);
    if((uint32_t)(millis() - LastPpmFrameMs) > 500UL)
      u8g2.print(" LOST");
  }

  u8g2.setCursor(0, 34);
  if(!telemetryAFHDS2AHasValidPacket())
  {
    u8g2.print("TLM WAIT");
  }
  else
  {
    u8g2.print("T");
    uint32_t cnt = telemetryAFHDS2AValidPacketCount();
    if(cnt > 999) cnt = 999;
    u8g2.print(cnt);
    u8g2.print(" L");
    u8g2.print(rxLqiPercent());
    u8g2.print(" R");
    u8g2.print((int8_t)RX_RSSI);
  }

  u8g2.sendBuffer();
}

// ============================================================================
// Debug / console
// ============================================================================
static void printChannels()
{
  if(IS_BIND_IN_PROGRESS)
  {
    Serial.println("CH us: hidden during BIND");
    return;
  }

  Serial.print("CH us:");
  for(uint8_t ch = 0; ch < ACTIVE_CHANNELS; ch++)
  {
    Serial.print(' ');
    Serial.print(convert_channel_ppm(ch));
  }
  Serial.println();
}

static void printStatus()
{
  Serial.println();
  Serial.println("--- TX MPM AFHDS2A ESP32-C3 ---");
  Serial.printf("Build       : %s\r\n", BUILD_TAG);
  Serial.printf("TX ID       : %08lX\r\n", (unsigned long)MProtocol_id);
  Serial.printf("RX num      : %u\r\n", RX_num);
  Serial.printf("Input       : %s\r\n", InputSource == INPUT_SWEEP ? "SWEEP" : "PPM");
  Serial.printf("PPM chans   : %u (library max %u)\r\n", PpmChannelCount, PPM_INPUT_CHANNELS);
  Serial.printf("PPM polarity: %s (%s edge)\r\n",
                PpmPositive ? "POS" : "NEG",
                PpmPositive ? "RISING" : "FALLING");
  Serial.printf("PPM ISR     : %lu  last dt=%lu us\r\n",
                (unsigned long)Cppm32.rxIsrCount(),
                (unsigned long)Cppm32.rxLastDtUs());
  if(InputSource == INPUT_PPM)
  {
    if(PpmFrameSeen)
      Serial.printf("PPM signal  : %s age=%lu ms\r\n",
                    ((uint32_t)(millis() - LastPpmFrameMs) <= PPM_FAILSAFE_MS) ? "OK" : "LOST",
                    (unsigned long)(millis() - LastPpmFrameMs));
    else
      Serial.println("PPM signal  : LOST (no frame yet)");
  }
  else
    Serial.println("PPM signal  : N/A (SWEEP mode)");
  Serial.printf("Motor       : CH%u safe=%u us GPIO%d=%s state=%s%s%s\r\n",
                MotorChannel, MOTOR_SAFE_US, PIN_MOTOR_SAFE,
                MotorSafetySwitchActive ? "ACTIVE" : "released",
                MotorSafetyActive ? "SAFE" : "RUN",
                MotorSafetySwitchActive ? " GPIO" : "",
                MotorSafetyPpmLost ? " PPM_LOST" : "");
  Serial.printf("RF failsafe : CH%u=%u us, others=HOLD, program=%s\r\n",
                MotorChannel, MOTOR_SAFE_US, IS_FAILSAFE_VALUES_on ? "PENDING" : "WAIT SLOT");
  Serial.printf("Bind        : %s\r\n", IS_BIND_IN_PROGRESS ? "YES" : "NO");
  Serial.printf("RF state    : %s  RX_ID=%s\r\n", rfLinkStateText(), receiverIdLooksValid() ? "stored" : "none");
  Serial.printf("A7105       : %s\r\n", RadioOk ? "OK" : "ERROR");
  Serial.printf("RF scheduler: %s  CPU=%u MHz\r\n", RfUseEspTimer ? "ESP_TIMER" : "LOOP fallback", getCpuFrequencyMhz());
  Serial.printf("OLED        : %s\r\n", oled_enabled ? (oled_ok ? "ON" : "ON/ERROR") : "OFF");
  xany1PrintStatus();
  xany2PrintStatus();
  pcfSw8PrintStatus();
  Serial.printf("TLM RX      : %s (option=0x%02X, FW telemetry bit kept ON)\r\n",
                TelemetryRxEnabled ? "ON" : "OFF", option);
  Serial.printf("Hop index   : %u\r\n", hopping_frequency_no);
  Serial.printf("Telemetry   : %s (FW) LQI=%u%% ERR=%u%% RX_RSSI=%d TX_RSSI=%u V1=%u V2=%u\r\n",
                TelemetryRxEnabled ? "ON" : "OFF",
                rxLqiPercent(), RX_LQI, (int8_t)RX_RSSI, TX_RSSI, v_lipo1, v_lipo2);
  telemetryAFHDS2APrintStatus();
  printChannels();
}

static void helpPause()
{
  // Let the serial driver empty its TX buffer between help sections.
  // The RF scheduler continues independently through esp_timer.
  Serial.flush();
  delay(1);
}

static void printHelpMini()
{
  Serial.println();
  Serial.println("Configuration commands:");
  Serial.println("  ?             Status");
  Serial.println("  h             Configuration help");
  Serial.println("  hf            Full help (+ diagnostics/debug)");
  Serial.println("  id            Display TX/RX IDs");
  Serial.println("  txid          Display saved TX ID");
  Serial.println("  txid new      Create/save a new random TX ID (rebind required)");
  Serial.println("  txid auto     Restore/save board eFuse-based TX ID");
  Serial.println("  txid 1234ABCD Set/save a manual 32-bit hexadecimal TX ID");
  helpPause();

  Serial.println("  bind          Start AFHDS2A bind (30 s max)");
  Serial.println("  ppm           Return to PPM input");
  Serial.println("  ppm pol       Display saved PPM polarity");
  Serial.println("  ppm pos/+     Save positive PPM (rising edge), then reboot");
  Serial.println("  ppm neg/-     Save negative PPM (falling edge), then reboot");
  Serial.println("  fs            Display AFHDS2A receiver failsafe programming");
  Serial.println("  fs send       Re-arm failsafe programming packet");
  Serial.println("  tlm on/off    Enable/disable telemetry RX + save preference");
  Serial.println("  tlm           Display telemetry RX state");
  Serial.println("  oled on/off   Enable/disable OLED + save preference");
  Serial.println("  oled          Display OLED state");
  helpPause();

  Serial.println("  xany1          Display XANY1 SW8 status");
  Serial.println("  xany1 on/off   Enable/disable XANY1 + save preference");
  Serial.println("  xany1 ch5      Set/save XANY1 AFHDS2A output channel");
  Serial.println("  xany1 sw 5A    Manual XANY1 SW8 test byte 00..FF");
  Serial.println("  xany2          Display XANY2 SW8+PROP status");
  Serial.println("  xany2 on/off   Enable/disable XANY2 + save preference");
  Serial.println("  xany2 ch6      Set/save XANY2 AFHDS2A output channel");
  Serial.println("  xany2 sw 5A    Manual XANY2 SW8 test byte 00..FF");
  Serial.println("  xany2 prop 128 Manual XANY2 PROP byte 0..255");
  helpPause();

  Serial.println("  pcf            Display PCF8574(A) SW8 input status (XANY1)");
  Serial.println("  pcf scan       Re-scan PCF8574A 0x38..3F / PCF8574 0x20..27");
  helpPause();
}

static void printHelpFull()
{
  printHelpMini();

  Serial.println();
  Serial.println("Diagnostics / debug commands:");
  Serial.println("  sweep     Temporary internal CH1..CH14 sweep (test only)");
  Serial.println("  blog      Display last captured bind log");
  Serial.println("  tlog      Display AFHDS2A telemetry log");
  Serial.println("  tclear    Clear AFHDS2A telemetry log");
  Serial.println("  d         Debug On/Off");
  helpPause();

  Serial.println("  ch        Display CH1..CH14 in us");
  Serial.println("  hop       Display 16 hopping channels");
  Serial.println("  rflog     Display ESP RF timer speed/jitter/runtime log");
  Serial.println("  rfclear   Clear ESP RF timer log");
  helpPause();
}

static void setPpmPolarityAndRestart(bool Positive)
{
  if(PpmPositive == Positive)
  {
    Serial.printf("[PPM] polarity already %s (%s edge), preference unchanged\r\n",
                  PpmPositive ? "POS" : "NEG",
                  PpmPositive ? "RISING" : "FALLING");
    return;
  }

  PpmPositive = Positive;
  prefs.putBool("ppmpos", PpmPositive);

  // ESP32_PPM is initialized once at boot. Avoid re-attaching/changing the RX
  // edge while the RF stack is live: save the setting and restart cleanly.
  Serial.printf("[PPM] polarity saved: %s (%s edge) - rebooting...\r\n",
                PpmPositive ? "POS" : "NEG",
                PpmPositive ? "RISING" : "FALLING");
  Serial.flush();
  delay(100);
  ESP.restart();
}

static void startBind()
{
  if(!RadioOk)
  {
    Serial.println("[BIND] A7105 is not ready");
    return;
  }

  Serial.printf("[BIND] start (30 s max) TX ID=%08lX\r\n", (unsigned long)MProtocol_id);

  // The new bind attempt is not considered valid until the original MPM
  // handshake completes by itself. Keep the old RX ID bytes untouched, but
  // clear the validity flag so a timeout can never display BIND OK.
  invalidateRfBindState();
  // Do not program receiver failsafe while the bind state machine is active.
  // Programming resumes automatically as soon as bind completes.
  FAILSAFE_VALUES_off;

  if(RfUseEspTimer)
    rfTimerStop();
  BIND_IN_PROGRESS;
  AFHDS2A_init();
  if(RfUseEspTimer)
    rfTimerStart(1000UL);
  else
    NextProtocolUs = micros() + 1000UL;

  BindStartMs = millis();
  BindTimerActive = true;
  LastBindLedMs = BindStartMs;
  BindLedState = true;
  bindLogReset();
  Serial.println("[BINDLOG] recording MPM bind activity in RAM; dump at end");
  digitalWrite(PIN_LED, HIGH);
}

static void processBindSupervision()
{
  if(!RadioOk)
    return;

  // MPM sets BIND_DONE itself when the AFHDS2A bind handshake succeeds.
  if(BindTimerActive && IS_BIND_DONE)
  {
    const uint32_t elapsed = (uint32_t)(millis() - BindStartMs);
    BindTimerActive = false;
    BindLogResult = 2;
    storeRfBindState(true);
    Serial.printf("[BIND] done in %lu ms\r\n", (unsigned long)elapsed);
    Serial.printf("[BIND] RX ID=%02X %02X %02X %02X -> %s\r\n",
                  rx_id[0], rx_id[1], rx_id[2], rx_id[3],
                  RfBindOk ? "VALID" : "INVALID");
    bindLogDump();
    return;
  }

  if(!BindTimerActive || !IS_BIND_IN_PROGRESS)
    return;

  if((uint32_t)(millis() - BindStartMs) < BIND_TIMEOUT_MS)
    return;

  Serial.println("[BIND] timeout after 30 s - no valid AFHDS2A handshake");

  // Abort only in the ESP32-C3 wrapper. Keep the original MPM AFHDS2A code
  // untouched. BIND_DONE + AFHDS2A_init() returns to normal DATA mode and
  // reloads the previously stored receiver ID, if one exists.
  if(RfUseEspTimer)
    rfTimerStop();
  BIND_DONE;
  AFHDS2A_init();
  invalidateRfBindState();
  if(RfUseEspTimer)
    rfTimerStart(1000UL);
  else
    NextProtocolUs = micros() + 1000UL;
  BindTimerActive = false;
  BindLogResult = 3;

  Serial.printf("[BIND] RF state=%s  RX ID=%02X %02X %02X %02X\r\n",
                rfLinkStateText(),
                rx_id[0], rx_id[1], rx_id[2], rx_id[3]);
  bindLogDump();
}

static void processStatusLed()
{
  if(!RadioOk)
  {
    BindLedState = false;
    digitalWrite(PIN_LED, LOW);
    return;
  }

  if(IS_BIND_IN_PROGRESS)
  {
    const uint32_t now = millis();
    if((uint32_t)(now - LastBindLedMs) >= BIND_LED_BLINK_MS)
    {
      LastBindLedMs = now;
      BindLedState = !BindLedState;
    }
    digitalWrite(PIN_LED, BindLedState ? HIGH : LOW);
    return;
  }

  // Normal RF/data mode: LED steady ON.
  BindLedState = true;
  digitalWrite(PIN_LED, HIGH);
}

static void processConsole()
{
  static String line;

  while(Serial.available())
  {
    const char c = (char)Serial.read();
    if(c == '\r')
      continue;

    if(c != '\n')
    {
      if(line.length() < 60)
        line += c;
      continue;
    }

    line.trim();
    line.toLowerCase();

    if(line == "?" )
      printStatus();
    else if(line == "h" || line == "help")
      printHelpMini();
    else if(line == "hf" || line == "help full" || line == "helpfull" || line == "hfull")
      printHelpFull();
    else if(line == "sweep")
    {
      InputSource = INPUT_SWEEP;
      Serial.println("Input=SWEEP (14 channels)");
    }
    else if(line == "ppm")
    {
      InputSource = INPUT_PPM;
      PpmFrameSeen = false;
      PpmChannelCount = 0;
      LastPpmFrameMs = 0;
      centerAllChannels();
      applyMotorSafety();
      Serial.printf("Input=PPM (%s) - CH%u failsafe active until valid PPM\r\n",
                    PpmPositive ? "POS" : "NEG", MotorChannel);
    }
    else if(line == "ppm pol" || line == "ppm polarity")
    {
      Serial.printf("[PPM] polarity=%s (%s edge), saved in Preferences\r\n",
                    PpmPositive ? "POS" : "NEG",
                    PpmPositive ? "RISING" : "FALLING");
    }
    else if(line == "ppm pos" || line == "ppm +" || line == "ppm positive")
      setPpmPolarityAndRestart(true);
    else if(line == "ppm neg" || line == "ppm -" || line == "ppm negative")
      setPpmPolarityAndRestart(false);
    else if(line == "bind")
      startBind();
    else if(line == "fs" || line == "failsafe")
      printAfhds2aFailsafeStatus();
    else if(line == "fs send" || line == "failsafe send")
    {
      if(IS_BIND_IN_PROGRESS)
        Serial.println("[FAILSAFE] bind in progress - programming will resume after bind");
      else
      {
        armAfhds2aFailsafeProgramming();
        Serial.println("[FAILSAFE] armed - packet 0x56 will be sent at the next AFHDS2A failsafe slot (<= about 6 s)");
      }
    }
    else if(line == "blog")
    {
      if(BindTimerActive)
        Serial.println("[BINDLOG] bind still running; log will be dumped at the end");
      else
        bindLogDump();
    }
    else if(line == "tlog")
      telemetryAFHDS2APrintLog();
    else if(line == "tclear")
    {
      telemetryAFHDS2AReset();
      Serial.println("[TLM] log cleared");
    }
    else if(line == "tlm on")
    {
      TelemetryRxEnabled = true;
      prefs.putBool("tlmrx", TelemetryRxEnabled);
      Serial.println("[TLM] ON saved - AFHDS2A RX telemetry windows enabled (option remains 0x80 / 50 Hz)");
    }
    else if(line == "tlm off")
    {
      TelemetryRxEnabled = false;
      prefs.putBool("tlmrx", TelemetryRxEnabled);
      Serial.println("[TLM] OFF saved - AFHDS2A RX telemetry windows disabled; TX/sticks continue (option remains 0x80 / 50 Hz)");
    }
    else if(line == "tlm")
    {
      Serial.printf("[TLM] %s - option=0x%02X\r\n", TelemetryRxEnabled ? "ON" : "OFF", option);
    }
    else if(line == "rflog")
      rfTimerPrintLog();
    else if(line == "rfclear")
    {
      rfTimerResetLog();
      Serial.println("[RF-TIMER] log cleared");
    }
    else if(line == "d")
    {
      DebugIsOn = !DebugIsOn;
      Serial.printf("Debug=%s\r\n", DebugIsOn ? "ON" : "OFF");
    }
    else if(line == "ch")
      printChannels();
    else if(line == "hop")
    {
      Serial.print("HOP:");
      for(uint8_t i = 0; i < 16; i++)
      {
        Serial.print(' ');
        if(hopping_frequency[i] < 0x10) Serial.print('0');
        Serial.print(hopping_frequency[i], HEX);
      }
      Serial.println();
    }
    else if(line == "oled on")
    {
      oled_enabled = true;
      prefs.putBool("oled", oled_enabled);
      oledInit();
    }
    else if(line == "oled off")
    {
      oledDisable();
      prefs.putBool("oled", oled_enabled);
    }
    else if(line == "oled")
    {
      Serial.printf("[OLED] %s\r\n", oled_enabled ? (oled_ok ? "ON" : "ON/ERROR") : "OFF");
    }
    else if(line == "xany1")
    {
      xany1PrintStatus();
    }
    else if(line == "xany1 on")
    {
      xany1SetEnabled(true);
      Serial.printf("XANY1=ON saved (CH%u)\r\n", xany1GetChannel());
    }
    else if(line == "xany1 off")
    {
      xany1SetEnabled(false);
      Serial.printf("XANY1=OFF saved (CH%u released to PPM/SWEEP)\r\n", xany1GetChannel());
    }
    else if(line.startsWith("xany1 ch"))
    {
      const int ch = line.substring(8).toInt();
      if(ch < 1 || ch > ACTIVE_CHANNELS)
        Serial.printf("Usage: xany1 ch1..ch%u\r\n", ACTIVE_CHANNELS);
      else if(xany1SetChannel((uint8_t)ch))
        Serial.printf("XANY1 SW8 channel=CH%u saved; repeat=2\r\n", xany1GetChannel());
      else
        Serial.printf("XANY1 channel rejected (motor CH%u or XANY2 CH%u conflict)\r\n",
                      MotorChannel, xany2GetChannel());
    }
    else if(line.startsWith("xany1 sw "))
    {
      String hex = line.substring(9);
      hex.trim();
      if(hex.length() == 0 || hex.length() > 2)
        Serial.println("Usage: xany1 sw 00..FF");
      else
      {
        char *endp = nullptr;
        const unsigned long v = strtoul(hex.c_str(), &endp, 16);
        if(endp == hex.c_str() || *endp != '\0' || v > 0xFF)
          Serial.println("Usage: xany1 sw 00..FF");
        else
        {
          xany1SetSw8((uint8_t)v);
          Serial.printf("XANY1 SW8=0x%02X (manual; PCF may overwrite when present)\r\n",
                        xany1GetSw8());
        }
      }
    }
    else if(line == "xany2")
    {
      xany2PrintStatus();
    }
    else if(line == "xany2 on")
    {
      xany2SetEnabled(true);
      Serial.printf("XANY2=ON saved (SW8+PROP CH%u)\r\n", xany2GetChannel());
    }
    else if(line == "xany2 off")
    {
      xany2SetEnabled(false);
      Serial.printf("XANY2=OFF saved (CH%u released to PPM/SWEEP)\r\n", xany2GetChannel());
    }
    else if(line.startsWith("xany2 ch"))
    {
      const int ch = line.substring(8).toInt();
      if(ch < 1 || ch > ACTIVE_CHANNELS)
        Serial.printf("Usage: xany2 ch1..ch%u\r\n", ACTIVE_CHANNELS);
      else if(xany2SetChannel((uint8_t)ch))
        Serial.printf("XANY2 SW8+PROP channel=CH%u saved; repeat=2\r\n", xany2GetChannel());
      else
        Serial.printf("XANY2 channel rejected (motor CH%u or XANY1 CH%u conflict)\r\n",
                      MotorChannel, xany1GetChannel());
    }
    else if(line.startsWith("xany2 sw "))
    {
      String hex = line.substring(9);
      hex.trim();
      if(hex.length() == 0 || hex.length() > 2)
        Serial.println("Usage: xany2 sw 00..FF");
      else
      {
        char *endp = nullptr;
        const unsigned long v = strtoul(hex.c_str(), &endp, 16);
        if(endp == hex.c_str() || *endp != '\0' || v > 0xFF)
          Serial.println("Usage: xany2 sw 00..FF");
        else
        {
          xany2SetSw8((uint8_t)v);
          Serial.printf("XANY2 SW8=0x%02X\r\n", xany2GetSw8());
        }
      }
    }
    else if(line.startsWith("xany2 prop "))
    {
      String val = line.substring(11);
      val.trim();
      char *endp = nullptr;
      const unsigned long v = strtoul(val.c_str(), &endp, 0);
      if(endp == val.c_str() || *endp != '\0' || v > 255)
        Serial.println("Usage: xany2 prop 0..255 (or 0x00..0xFF)");
      else
      {
        xany2SetProp((uint8_t)v);
        Serial.printf("XANY2 PROP=%u (0x%02X)\r\n", xany2GetProp(), xany2GetProp());
      }
    }
    else if(line == "pcf")
      pcfSw8PrintStatus();
    else if(line == "pcf scan")
      pcfSw8Scan();
    else if(line == "txid")
    {
      Serial.printf("TX ID=%08lX (saved)  board-auto=%08lX\r\n",
                    (unsigned long)MProtocol_id,
                    (unsigned long)makeBoardTxId());
    }
    else if(line == "txid new")
    {
      const uint32_t id = makeRandomTxId(MProtocol_id);
      applyTxId(id, true);
      Serial.printf("[TXID] NEW=%08lX saved - REBIND REQUIRED\r\n", (unsigned long)MProtocol_id);
    }
    else if(line == "txid auto")
    {
      if(applyTxId(makeBoardTxId(), true))
        Serial.printf("[TXID] AUTO=%08lX saved - REBIND REQUIRED\r\n", (unsigned long)MProtocol_id);
      else
        Serial.printf("[TXID] AUTO=%08lX already active\r\n", (unsigned long)MProtocol_id);
    }
    else if(line.startsWith("txid "))
    {
      String hex = line.substring(5);
      hex.trim();
      if(hex.startsWith("0x"))
        hex.remove(0, 2);

      if(hex.length() == 0 || hex.length() > 8)
      {
        Serial.println("Usage: txid new | txid auto | txid 1234ABCD");
      }
      else
      {
        char *endp = nullptr;
        const unsigned long v = strtoul(hex.c_str(), &endp, 16);
        if(endp == hex.c_str() || *endp != '\0' || v == 0 || v == 0xFFFFFFFFUL)
          Serial.println("Usage: txid new | txid auto | txid 1234ABCD");
        else
        {
          if(applyTxId((uint32_t)v, true))
            Serial.printf("[TXID] SET=%08lX saved - REBIND REQUIRED\r\n", (unsigned long)MProtocol_id);
          else
            Serial.printf("[TXID] SET=%08lX already active\r\n", (unsigned long)MProtocol_id);
        }
      }
    }
    else if(line == "id")
    {
      Serial.printf("TX=%02X %02X %02X %02X  RX=%02X %02X %02X %02X\r\n",
                    rx_tx_addr[0], rx_tx_addr[1], rx_tx_addr[2], rx_tx_addr[3],
                    rx_id[0], rx_id[1], rx_id[2], rx_id[3]);
    }
    else if(line.length())
      Serial.println("Unknown command. Type h (config) or hf (full)");

    line = "";
  }
}

static void processBindButton()
{
  const bool now = digitalRead(PIN_BIND);
  if(LastBindButton == HIGH && now == LOW &&
     (uint32_t)(millis() - LastBindButtonMs) > 250UL)
  {
    LastBindButtonMs = millis();
    startBind();
  }
  LastBindButton = now;
}

static void debugTask()
{
  // During BIND, suppress the normal SWEEP/PPM debug stream. The dedicated
  // bind logger records the MPM protocol in RAM without disturbing timing.
  if(IS_BIND_IN_PROGRESS)
    return;

  if(!DebugIsOn || (uint32_t)(millis() - LastDebugMs) < 500UL)
    return;

  LastDebugMs = millis();
  Serial.printf("DBG phase=%02X hop=%u mode=%s sweep=%u LQI=%u%% ERR=%u%% RX=%d TX=%u PPMisr=%lu dt=%lu\r\n",
                phase,
                hopping_frequency_no,
                InputSource == INPUT_SWEEP ? "SWEEP" : "PPM",
                SweepUs,
                rxLqiPercent(),
                RX_LQI,
                (int8_t)RX_RSSI,
                TX_RSSI,
                (unsigned long)Cppm32.rxIsrCount(),
                (unsigned long)Cppm32.rxLastDtUs());
  printChannels();
}

// ============================================================================
// MPM callback scheduler - ESP32 high-resolution timer
// ============================================================================
static void rfTimerResetLog()
{
  portENTER_CRITICAL(&RfTimerStatsMux);
  RfTimerStats = {};
  portEXIT_CRITICAL(&RfTimerStatsMux);
}

static void rfTimerPrintLog()
{
  RfTimerStatsData s;
  portENTER_CRITICAL(&RfTimerStatsMux);
  s = RfTimerStats;
  portEXIT_CRITICAL(&RfTimerStatsMux);

  Serial.println();
  Serial.println("========== ESP32 RF TIMER LOG ==========");
  Serial.printf("[RF-TIMER] mode=%s SPI=REGGPIO CPU=%uMHz TLM=%s callbacks=%lu\r\n",
                RfUseEspTimer ? "ESP_TIMER" : "LOOP_FALLBACK",
                getCpuFrequencyMhz(),
                TelemetryRxEnabled ? "ON" : "OFF",
                (unsigned long)s.callbacks);

  if(s.callbacks > 1 && s.lastStartUs > s.firstStartUs)
  {
    const double elapsedSec = (double)(s.lastStartUs - s.firstStartUs) / 1000000.0;
    const double rate = elapsedSec > 0.0 ? (double)(s.callbacks - 1) / elapsedSec : 0.0;
    Serial.printf("[RF-TIMER] elapsed=%.3fs rate=%.2f callbacks/s target~519.48\r\n",
                  elapsedSec, rate);
  }

  Serial.printf("[RF-TIMER] delays: 1700=%lu 2150=%lu other=%lu\r\n",
                (unsigned long)s.delay1700,
                (unsigned long)s.delay2150,
                (unsigned long)s.delayOther);

  const double avgLate = s.lateCount ? (double)s.lateSumUs / (double)s.lateCount : 0.0;
  const double avgRun = s.callbacks ? (double)s.runtimeSumUs / (double)s.callbacks : 0.0;
  const double avgJitter = s.jitterSamples ? (double)s.jitterAbsSumUs / (double)s.jitterSamples : 0.0;
  Serial.printf("[RF-TIMER] lateness avg=%.1fus max=%luus samples=%lu\r\n",
                avgLate, (unsigned long)s.lateMaxUs, (unsigned long)s.lateCount);
  Serial.printf("[RF-TIMER] callback runtime avg=%.1fus max=%luus\r\n",
                avgRun, (unsigned long)s.runtimeMaxUs);
  const double avgRun1700 = s.runtime1700Samples ? (double)s.runtime1700SumUs / (double)s.runtime1700Samples : 0.0;
  const double avgRun2150 = s.runtime2150Samples ? (double)s.runtime2150SumUs / (double)s.runtime2150Samples : 0.0;
  Serial.printf("[RF-TIMER] runtime->1700 avg=%.1fus max=%luus samples=%lu\r\n",
                avgRun1700, (unsigned long)s.runtime1700MaxUs, (unsigned long)s.runtime1700Samples);
  Serial.printf("[RF-TIMER] runtime->2150 avg=%.1fus max=%luus samples=%lu\r\n",
                avgRun2150, (unsigned long)s.runtime2150MaxUs, (unsigned long)s.runtime2150Samples);
  Serial.printf("[RF-TIMER] interval jitter |err| avg=%.1fus max=%luus samples=%lu\r\n",
                avgJitter, (unsigned long)s.jitterAbsMaxUs, (unsigned long)s.jitterSamples);
  Serial.printf("[RF-TIMER] overruns=%lu resyncs=%lu armErrors=%lu\r\n",
                (unsigned long)s.overruns,
                (unsigned long)s.resyncs,
                (unsigned long)s.armErrors);
  Serial.println("========================================");
}

static void rfProtocolTimerCallback(void* arg)
{
  (void)arg;
  if(!RadioOk || !RfTimerRunning)
    return;

  const int64_t cbStartUs = esp_timer_get_time();
  const int64_t expectedUs = RfExpectedUs;
  int64_t lateUs64 = cbStartUs - expectedUs;
  if(lateUs64 < 0) lateUs64 = 0;
  const uint32_t lateUs = (uint32_t)lateUs64;

  const uint8_t phaseBefore = phase;
  bindDiagBeginCallback();
  telemetryAFHDS2ABeginCallback(phaseBefore);
  const uint16_t delayUs = AFHDS2A_callback();
  const uint8_t phaseAfter = phase;
  bindDiagEndCallback(phaseBefore);
  telemetryAFHDS2AEndCallback(phaseBefore, phaseAfter);
  bindLogCapture(phaseBefore, phaseAfter);

  const int64_t cbEndUs = esp_timer_get_time();
  const uint32_t runtimeUs = (uint32_t)(cbEndUs - cbStartUs);

  portENTER_CRITICAL(&RfTimerStatsMux);
  if(RfTimerStats.callbacks == 0)
    RfTimerStats.firstStartUs = cbStartUs;
  else if(RfTimerStats.prevStartUs != 0 && RfTimerStats.prevDelayUs != 0)
  {
    const int64_t actualInterval = cbStartUs - RfTimerStats.prevStartUs;
    int64_t jitter = actualInterval - (int64_t)RfTimerStats.prevDelayUs;
    if(jitter < 0) jitter = -jitter;
    RfTimerStats.jitterAbsSumUs += (uint64_t)jitter;
    if((uint64_t)jitter > RfTimerStats.jitterAbsMaxUs)
      RfTimerStats.jitterAbsMaxUs = (uint32_t)jitter;
    RfTimerStats.jitterSamples++;
  }
  RfTimerStats.callbacks++;
  RfTimerStats.lastStartUs = cbStartUs;
  RfTimerStats.prevStartUs = cbStartUs;
  RfTimerStats.prevDelayUs = delayUs;
  if(delayUs == 1700) RfTimerStats.delay1700++;
  else if(delayUs == 2150) RfTimerStats.delay2150++;
  else RfTimerStats.delayOther++;
  RfTimerStats.lateCount++;
  RfTimerStats.lateSumUs += lateUs;
  if(lateUs > RfTimerStats.lateMaxUs) RfTimerStats.lateMaxUs = lateUs;
  RfTimerStats.runtimeSumUs += runtimeUs;
  if(runtimeUs > RfTimerStats.runtimeMaxUs) RfTimerStats.runtimeMaxUs = runtimeUs;
  if(delayUs == 1700)
  {
    RfTimerStats.runtime1700SumUs += runtimeUs;
    RfTimerStats.runtime1700Samples++;
    if(runtimeUs > RfTimerStats.runtime1700MaxUs) RfTimerStats.runtime1700MaxUs = runtimeUs;
  }
  else if(delayUs == 2150)
  {
    RfTimerStats.runtime2150SumUs += runtimeUs;
    RfTimerStats.runtime2150Samples++;
    if(runtimeUs > RfTimerStats.runtime2150MaxUs) RfTimerStats.runtime2150MaxUs = runtimeUs;
  }
  portEXIT_CRITICAL(&RfTimerStatsMux);

  // Keep the next deadline tied to the previous scheduled deadline, like the
  // original MPM timer scheduler. Callback execution time is therefore not
  // added to the requested 1700/2150 us period.
  int64_t nextExpectedUs = expectedUs + (int64_t)delayUs;

  // Same spirit as the old loop scheduler recovery: only resync after a large
  // (>20 ms) disturbance instead of accumulating an impossible backlog.
  if((cbEndUs - nextExpectedUs) > 20000)
  {
    nextExpectedUs = cbEndUs + (int64_t)delayUs;
    portENTER_CRITICAL(&RfTimerStatsMux);
    RfTimerStats.resyncs++;
    portEXIT_CRITICAL(&RfTimerStatsMux);
  }

  RfExpectedUs = nextExpectedUs;
  NextProtocolUs = (uint32_t)nextExpectedUs;

  int64_t waitUs64 = nextExpectedUs - cbEndUs;
  if(waitUs64 < 1)
  {
    waitUs64 = 1;
    portENTER_CRITICAL(&RfTimerStatsMux);
    RfTimerStats.overruns++;
    portEXIT_CRITICAL(&RfTimerStatsMux);
  }

  const esp_err_t err = esp_timer_start_once(RfProtocolTimer, (uint64_t)waitUs64);
  if(err != ESP_OK)
  {
    portENTER_CRITICAL(&RfTimerStatsMux);
    RfTimerStats.armErrors++;
    portEXIT_CRITICAL(&RfTimerStatsMux);
    RfTimerRunning = false;
  }
}

static bool rfTimerInit()
{
  if(RfProtocolTimer != nullptr)
    return true;

  esp_timer_create_args_t timerArgs = {};
  timerArgs.callback = &rfProtocolTimerCallback;
  timerArgs.arg = nullptr;
  timerArgs.dispatch_method = ESP_TIMER_TASK;
  timerArgs.name = "afhds2a_rf";

  const esp_err_t err = esp_timer_create(&timerArgs, &RfProtocolTimer);
  if(err != ESP_OK)
  {
    Serial.printf("[RF-TIMER] esp_timer_create FAILED err=%d -> loop fallback\r\n", (int)err);
    RfProtocolTimer = nullptr;
    return false;
  }

  Serial.println("[RF-TIMER] ESP32 high-resolution timer ready (ESP_TIMER_TASK)");
  return true;
}

static void rfTimerStop()
{
  RfTimerRunning = false;
  if(RfProtocolTimer != nullptr)
    esp_timer_stop(RfProtocolTimer);  // ESP_ERR_INVALID_STATE is harmless if already stopped
}

static void rfTimerStart(uint32_t firstDelayUs)
{
  if(RfProtocolTimer == nullptr)
    return;

  esp_timer_stop(RfProtocolTimer);
  const int64_t nowUs = esp_timer_get_time();
  RfExpectedUs = nowUs + (int64_t)firstDelayUs;
  NextProtocolUs = (uint32_t)RfExpectedUs;
  RfTimerRunning = true;

  const esp_err_t err = esp_timer_start_once(RfProtocolTimer, firstDelayUs);
  if(err != ESP_OK)
  {
    RfTimerRunning = false;
    portENTER_CRITICAL(&RfTimerStatsMux);
    RfTimerStats.armErrors++;
    portEXIT_CRITICAL(&RfTimerStatsMux);
    Serial.printf("[RF-TIMER] start FAILED err=%d\r\n", (int)err);
  }
}

// Cooperative scheduler retained only as an automatic fallback if esp_timer
// creation fails. In normal operation RfUseEspTimer=true and this is a no-op.
static void processProtocol()
{
  if(RfUseEspTimer || !RadioOk)
    return;

  const uint32_t now = micros();
  if((int32_t)(now - NextProtocolUs) < 0)
    return;

  const uint8_t phaseBefore = phase;
  bindDiagBeginCallback();
  telemetryAFHDS2ABeginCallback(phaseBefore);
  const uint16_t delayUs = AFHDS2A_callback();
  const uint8_t phaseAfter = phase;
  bindDiagEndCallback(phaseBefore);
  telemetryAFHDS2AEndCallback(phaseBefore, phaseAfter);
  bindLogCapture(phaseBefore, phaseAfter);
  NextProtocolUs += delayUs;

  if((int32_t)(micros() - NextProtocolUs) > 20000)
    NextProtocolUs = micros() + delayUs;
}

void setup()
{
  Serial.begin(DEFAULT_BAUD); // Use Serial

  // Timeout USB Serial (does not block forever without USB)
  uint32_t t0 = millis();
  while(!Serial && (millis() - t0 < 1500UL))
    delay(1);

  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, LOW);

  pinMode(PIN_BIND, INPUT_PULLUP);
  LastBindButton = digitalRead(PIN_BIND);

  // Independent motor safety switch: connect GPIO0 to GND to force CH3=1000 us.
  pinMode(PIN_MOTOR_SAFE, INPUT_PULLUP);

  // A7105 / MPM software SPI pins.
  pinMode(A7105_CSN_PIN, OUTPUT);
  pinMode(A7105_SCK_PIN, OUTPUT);
  pinMode(A7105_SDIO_PIN, OUTPUT);
  A7105_CSN_on;
  SCLK_off;
  SDI_on;

  // Shared I2C bus is always started, even with OLED OFF, because PCF8574(A)
  // provides the eight physical SW8 inputs.
  Wire.begin(SDA_PIN, SCL_PIN, I2C_BUS_HZ);
  Wire.setClock(I2C_BUS_HZ);
  Serial.printf("[I2C] SDA=%d SCL=%d clock=%lu Hz\r\n",
                SDA_PIN, SCL_PIN, (unsigned long)I2C_BUS_HZ);

  prefs.begin("mpm_afh", false);
  oled_enabled = prefs.getBool("oled", false);
  TelemetryRxEnabled = prefs.getBool("tlmrx", false);
  RfRebindRequired = prefs.getBool("rebind", false);
  PpmPositive = prefs.getBool("ppmpos", true);
  Serial.printf("[PREFS] OLED=%s TLM_RX=%s REBIND=%s PPM=%s\r\n",
                oled_enabled ? "ON" : "OFF",
                TelemetryRxEnabled ? "ON" : "OFF",
                RfRebindRequired ? "YES" : "NO",
                PpmPositive ? "POS" : "NEG");

  oledInit();

  telemetryAFHDS2AReset();
  xanyBegin();
  pcfSw8Begin();

  centerAllChannels();
  initAfhds2aFailsafeValues();

  // PPM is initialized even when SWEEP is selected so we can switch modes
  // from the console without rebooting.
  // ESP32_PPM v1.0 API: beginRx(pin, channels, risingEdge, syncMin, min, max).
  Cppm32.beginRx(PPM_IN_PIN,
                 PPM_INPUT_CHANNELS,
                 PpmPositive, // true=positive/rising, false=negative/falling
                 3500,        // sync gap
                 800,
                 2200);
  Serial.printf("[PPM] ESP32_PPM RX on GPIO%d, %u channels max, %s (%s edge)\r\n",
                PPM_IN_PIN, PPM_INPUT_CHANNELS,
                PpmPositive ? "POS" : "NEG",
                PpmPositive ? "RISING" : "FALLING");

  protocol = PROTO_AFHDS2A;
  sub_protocol = PWM_IBUS;
  RX_num = 0;
  option = 0x80;  // FW telemetry format bit kept ON; low7=0 -> 50 Hz servo setting
  // TelemetryRxEnabled was loaded from Preferences above (first-boot default OFF).

  MProtocol_id = loadOrCreateTxId();
  set_rx_tx_addr(MProtocol_id);

  POWER_FLAG_on;
  RANGE_FLAG_off;

  // Hold BIND button during boot to start binding immediately.
  if(digitalRead(PIN_BIND) == LOW)
    BIND_IN_PROGRESS;
  else
    BIND_DONE;

  Serial.println();
  Serial.println("***********************************");
  Serial.println("TX MPM AFHDS2A - ESP32-C3 reference");
  Serial.println("Original MPM AFHDS2A/A7105 logic");
  Serial.println("***********************************");
  Serial.printf("OLED SDA=%d SCL=%d\r\n", SDA_PIN, SCL_PIN);
  Serial.printf("A7105 SCK=%d SDIO=%d(3-wire) CSN=%d\r\n",
                A7105_SCK_PIN, A7105_SDIO_PIN, A7105_CSN_PIN);
  Serial.printf("PPM=%d BIND=%d LED=%d MOTOR_SAFE=%d\r\n",
                PPM_IN_PIN, PIN_BIND, PIN_LED, PIN_MOTOR_SAFE);
  Serial.printf("TX ID=%08lX\r\n", (unsigned long)MProtocol_id);
  Serial.printf("Default input mode: PPM IN (%s); SWEEP is temporary test mode\r\n", PpmPositive ? "POS" : "NEG");
  Serial.println("AFHDS2A CH17: RX_LQI (original MPM mapping)");
  Serial.println("Telemetry format: FW native (option=0x80)");
  Serial.printf("Telemetry RX windows saved: %s\r\n", TelemetryRxEnabled ? "ON" : "OFF");
  Serial.printf("OLED saved: %s\r\n", oled_enabled ? "ON" : "OFF");
  Serial.printf("Motor safety: CH%u -> %u us on PPM loss >%lu ms or GPIO%d LOW\r\n",
                MotorChannel, MOTOR_SAFE_US, (unsigned long)PPM_FAILSAFE_MS, PIN_MOTOR_SAFE);
  Serial.printf("AFHDS2A RX failsafe: FAILSAFE_ENABLE, CH%u=%u us, others=HOLD\r\n",
                MotorChannel, MOTOR_SAFE_US);
  Serial.printf("I2C shared OLED/PCF: %lu Hz\r\n", (unsigned long)I2C_BUS_HZ);
  Serial.printf("XANY1 SW8: %s CH%u repeat=2, PCF8574(A) active-low inputs\r\n",
                xany1IsEnabled() ? "ON" : "OFF", xany1GetChannel());
  Serial.printf("XANY2 SW8+PROP: %s CH%u repeat=2, manual PROP/SW8 for now\r\n",
                xany2IsEnabled() ? "ON" : "OFF", xany2GetChannel());

  // Original MPM A7105 reset test before starting AFHDS2A.
  RadioOk = A7105_Reset();
  if(!RadioOk)
  {
    Serial.println("[A7105] RESET/ID test FAILED");
  }
  else
  {
    Serial.println("[A7105] OK");
    AFHDS2A_init();
    if(IS_BIND_IN_PROGRESS)
      invalidateRfBindState();
    else
    {
      refreshRfBindState();
      armAfhds2aFailsafeProgramming();
    }

    // Prefer the ESP32 high-resolution timer. The old loop scheduler remains
    // available automatically if timer creation should fail.
    RfUseEspTimer = rfTimerInit();
    rfTimerResetLog();
    if(RfUseEspTimer)
      rfTimerStart(2000UL);
    else
      NextProtocolUs = micros() + 2000UL;

    Serial.printf("[RF] state=%s  RX ID=%02X %02X %02X %02X\r\n",
                  rfLinkStateText(),
                  rx_id[0], rx_id[1], rx_id[2], rx_id[3]);

    if(IS_BIND_IN_PROGRESS)
    {
      BindStartMs = millis();
      BindTimerActive = true;
      LastBindLedMs = BindStartMs;
      BindLedState = true;
      bindLogReset();
      Serial.println("[BIND] boot bind (30 s max)");
      Serial.println("[BINDLOG] recording MPM bind activity in RAM; dump at end");
    }
  }

  Serial.println("Type h for config help, hf for full/debug help.");
}

void loop()
{
  processConsole();
  processBindButton();
  processBindSupervision();
  processRfLinkValidation();
  processAfhds2aFailsafeProgramming();

  if(InputSource == INPUT_SWEEP)
    updateSweep();
  else
    updatePpm();

  // Motor safety has priority over the selected input source. In PPM mode,
  // missing/stale PPM forces CH3 to 1000 us. GPIO0 LOW always forces safe.
  applyMotorSafety();

  // Read the 8 physical switches first (currently assigned to XANY1), then
  // let the two RcTxSerial instances reserve/overwrite their enabled AFHDS2A
  // channels. XANY2 carries SW8+PROP on CH6 by default.
  pcfSw8Process();
  xanyProcess();

  // With ESP_TIMER enabled the RF callback runs from the high-priority ESP
  // timer task. processProtocol() is kept only for automatic loop fallback.
  processProtocol();

  oledDraw();
  debugTask();

  processStatusLed();
}
