*PADS-LIBRARY-PART-TYPES-V9*

TLP2361_TPL_E 11-4L1S(5-PIN-SOIC) I ANA 6 1 0 0 0
TIMESTAMP 2026.09.11.16.50.36
"Mouser Part Number" 757-TLP2361(TPLE
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Toshiba/TLP2361TPLE?qs=HVbQlW5zcXUn%252BfokbzIatg%3D%3D
"Manufacturer_Name" Toshiba
"Manufacturer_Part_Number" TLP2361(TPL,E
"Description" High Speed Optocouplers X36 PB Photocoupler Lo I/P cur 125 degC
"Datasheet Link" https://toshiba.semicon-storage.com/info/docget.jsp?did=14229&prodName=TLP2361
GATE 1 5 0
TLP2361_TPL_E
1 0 U ANODE
3 0 U CATHODE
4 0 U GND
5 0 U VO_(OUTPUT)
6 0 U VCC

*END*
*REMARK* SamacSys ECAD Model
792450/248188/2.50/5/4/Integrated Circuit
